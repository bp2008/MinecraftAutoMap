package com.minecraftam.automap;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class AMW_Item extends AMW_Entity
{
	public static final Class<EntityItem> wrappedClass = EntityItem.class;
	public EntityItem inst;

	public AMW_Item(EntityItem param)
	{
		super(param);
		inst = param;
	}

	public int getID()
	{
		return Item.getIdFromItem(inst.getEntityItem().getItem());
	}

	public int getCount()
	{
		return inst.getEntityItem().stackSize;
	}

	@Override
	public String getName()
	{
		// IGNORE WHEN UPDATING <-- Verified: Ignore this entire function
		int itemID = getID();
		int numberOfItems = getCount();
		if (itemID >= 256)
		{
			// Add item tag, graphic index, name, and count
			String itemName = AMW_ItemList.getName(inst.getEntityItem());
			// if (itemName.length() > 5) // Remove "item." from name
			// itemName = itemName.substring(5);
			itemName = "Item|" + itemID + "|" + itemName + "|" + numberOfItems;
			return itemName;
		} else if (itemID >= 0)
		{
			String blockName = AMW_BlockList.getName(inst.getEntityItem());
			// if (blockName.length() > 5) // Remove "tile." from name
			// blockName = blockName.substring(5);
			blockName = "Block|" + itemID + "|" + blockName + "|"
					+ numberOfItems;
			return blockName;
		} else
		{
			return "";
		}
	}

	public static String getTextureName(int id)
	{
		Block block = Block.getBlockById(id);
		String itemName = Minecraft.getMinecraft().getBlockRendererDispatcher().getBlockModelShapes().getTexture(block.getDefaultState()).getIconName();
		if(itemName.equals("missingno"))
		{
			Item item = Item.getItemById(id);
			ItemStack stack = new ItemStack(item);
			EntityPlayer player = Minecraft.getMinecraft().thePlayer;
			IBakedModel model = Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getItemModel(stack);
			itemName = model.getTexture().getIconName();
		}
		
//		String s = Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getModelManager().getTextureMap().getTextureExtry(block.getUnlocalizedName()).getIconName();
//		return s;
		if(block != null)
		{
			if(itemName.startsWith("minecraft:blocks/"))
				return "tile." + itemName.substring(17) + "|" + (block.isOpaqueCube() ? "1" : "0");
			if(itemName.startsWith("minecraft:items/"))
				return "item." + itemName.substring(16) + "|" + (block.isOpaqueCube() ? "1" : "0");
			return block.getUnlocalizedName() + "|" + (block.isOpaqueCube() ? "1" : "0");
		}
//		Item item = Item.getItemById(id);
//		if(item != null)
//			return "item." + item.getUnlocalizedName() + "1";
		return null;
		
//		Item item = Item.getItemById(id);
//		Block block = Block.getBlockFromItem(item);
//		if (block != null)
//		{
//			icon = block.getBlockTextureFromSide(1);
//			if (icon != null)
//			{
//				String iconName = icon.getIconName();
//				boolean isOpaque = block.isOpaqueCube();
//				return "tile." + iconName + "|" + (isOpaque ? "1" : "0");
//			}
//		}
//		icon = item.getIconFromDamage(0);
//		if (icon != null)
//			return "item." + item.getIconFromDamage(0).getIconName() + "|1";
//		return null;
	}
}
