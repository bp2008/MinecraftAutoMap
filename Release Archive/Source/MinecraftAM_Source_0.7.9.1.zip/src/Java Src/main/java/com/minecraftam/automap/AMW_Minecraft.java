package com.minecraftam.automap;
import java.net.InetSocketAddress;

import akka.io.TcpConnection;

import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;


public class AMW_Minecraft
{
	Minecraft inst;

	public AMW_Minecraft(Minecraft mc)
	{
		inst = mc;
	}

	public AMW_World getWorld()
	{
		return new AMW_World(inst.theWorld);
	}

	public AMW_Player getPlayer()
	{
		return new AMW_Player(inst.thePlayer);
	}

	public String getSMPHost()
	{
		return inst.getCurrentServerData().serverIP;
//		InetSocketAddress sockAddress = (InetSocketAddress)inst.getNetHandler().getNetworkManager().getRemoteAddress();
//		String serverName = sockAddress.getHostName();
//		int serverPort = sockAddress.getPort();
//		return serverName + ":" + serverPort;
	}

	public boolean checkWorldChanged(Object inst2)
	{
		// Same object as in getWorld above
		return inst2 != inst.theWorld;
	}

	public boolean isMultiplayer()
	{
		return !MinecraftServer.getServer().isSinglePlayer();
	}
}
