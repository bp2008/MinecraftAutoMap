package com.minecraftam.automap;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class AMW_World
{
	World inst;

	public AMW_World(World world)
	{
		inst = world;
	}

	public String getName()
	{
		return inst.getWorldInfo().getWorldName();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Minecraft's Z
		return inst.getWorldInfo().getSpawnZ() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Minecraft's X
		return inst.getWorldInfo().getSpawnX();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Minecraft's Y
		return inst.getWorldInfo().getSpawnY();
	}

	public String getDimension()
	{
		return String.valueOf(inst.provider.getDimensionId());
	}

	public short getBlockId(int x, int y, int z)
	{
		return (short)Block.getIdFromBlock(inst.getBlockState(new BlockPos(x, z, y)).getBlock());
	}

	public byte getBlockMeta(int x, int y, int z)
	{
		IBlockState bs = inst.getBlockState(new BlockPos(x, z, y));
		return (byte) bs.getBlock().getMetaFromState(bs);
	}

	public byte getBlockLight(int x, int y, int z)
	{
		IBlockState bs = inst.getBlockState(new BlockPos(x, z, y));
		
		return (byte) bs.getBlock().getLightValue();
	}

	/**
	 * The NPC list also has players in it.
	 */
	public List<?> GetPlayerList()
	{
		return inst.playerEntities;
	}

	/**
	 * Also contains players.
	 */
	public List<?> GetNPCList()
	{
		return inst.loadedEntityList;
	}
	public void CreateExplosion(double x, double y, double z, float power)
	{
		inst.createExplosion(null, x, y, z, power, false);
	}

	public boolean isLoaded()
	{
		return inst != null;
	}
}