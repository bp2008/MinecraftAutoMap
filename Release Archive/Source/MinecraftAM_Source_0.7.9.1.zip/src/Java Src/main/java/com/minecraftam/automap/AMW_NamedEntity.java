package com.minecraftam.automap;

import net.minecraft.entity.EntityLivingBase;

public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 17
	public static final Class<EntityLivingBase> wrappedClass = EntityLivingBase.class;
	// Fixed 17
	public EntityLivingBase inst;

	// Fixed 17
	public AMW_NamedEntity(EntityLivingBase param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity" || name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
