package com.minecraftam.automap;

import net.minecraft.item.ItemStack;


public class AMW_ItemList
{
	public static String getName(ItemStack entityItem)
	{
		String name = entityItem.getDisplayName();
		if(name == null || name.equals(""))
			name = "unknown_item";
		return name;
	}
}
