package com.minecraftam.eventtcp;

import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Brian
 */
public class EventTcpReader extends Thread
{
    PacketPacker packer;
    Vector<Packet> packetVector;
    InputStream is;
    public boolean isRunning = false;
    //Logger logger = Logger.getLogger("EventTcp");
    EventTcpClientListener listener;
    EventTcpClient client;

    public EventTcpReader(InputStream is, EventTcpClient client, EventTcpClientListener listener)
    {
        packer = new PacketPacker();
        packetVector = new Vector<Packet>();
        this.client = client;
        this.listener = listener;
        this.is = is;
    }

    public void abort()
    {
        isRunning = false;
    }

    @Override
    public void run()
    {
        isRunning = true;
        try
        {
            byte[] bytes;
            int read = 0;
            while (isRunning)
            {
                bytes = new byte[32768];
                read = is.read(bytes, 0, bytes.length);
                //if (read == 0)
                //    continue;
                if (read <= 0)
                {
                    //EventTcpServer.ReportException("Message of size " + read + " was received.");
                    isRunning = false;
                    continue;
                }
                EventTcpServer.receivedChars += read;
                packer.Unpack(bytes, read, packetVector);
                for (int i = 0; i < packetVector.size(); i++)
                {
                    // EventTcpServer.ReportException("Recvd Size: " + packetVector.elementAt(i).bytes.length);
                    EventTcpServer.receivedCnt++;
                    listener.messageReceived(packetVector.elementAt(i).bytes, client);
                }
                packetVector.clear();
            }
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
            //  if (ex.getMessage().contains("Connection reset"))
            //       logger.log(Level.INFO, "EventTcpReader: Client Connection Disconnected");
            //   else
            //     logger.log(Level.WARNING, "EventTcpReader: " + ex.getMessage(), ex);
        }
        try
        {
            client.Disconnect();
            is.close();
        } catch (IOException ex)
        {
            EventTcpServer.ReportException(ex);
            //     logger.log(Level.WARNING, "EventTcpReader: " + ex.getMessage(), ex);
        }
        isRunning = false;
    }
}

