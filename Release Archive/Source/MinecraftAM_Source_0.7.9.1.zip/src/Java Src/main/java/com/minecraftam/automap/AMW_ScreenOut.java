package com.minecraftam.automap;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class AMW_ScreenOut
{
	public static void DisplayMessage(String message)
	{
		Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(message));
	}
}
