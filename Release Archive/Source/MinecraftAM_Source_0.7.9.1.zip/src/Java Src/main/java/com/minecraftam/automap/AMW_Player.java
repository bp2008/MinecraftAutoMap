package com.minecraftam.automap;

import net.minecraft.entity.player.EntityPlayer;

public class AMW_Player extends AMW_NamedEntity
{
	public static final Class<EntityPlayer> wrappedClass = EntityPlayer.class;
	public EntityPlayer inst;

	public AMW_Player(EntityPlayer param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		return inst.getDisplayNameString();
	}
}
