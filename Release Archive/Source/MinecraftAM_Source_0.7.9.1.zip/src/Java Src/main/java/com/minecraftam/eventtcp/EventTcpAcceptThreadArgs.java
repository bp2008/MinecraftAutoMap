package com.minecraftam.eventtcp;

import java.net.ServerSocket;
import java.util.Vector;

/**
 *
 * @author Brian
 */
public class EventTcpAcceptThreadArgs
{
    public boolean isListening;
    public ServerSocket sockServer;
    public Object clientLock;
    public Vector<EventTcpClient> clients;
    public EventTcpClientListener listener;

    public EventTcpAcceptThreadArgs(boolean isListening, ServerSocket sockServer, Object clientLock, Vector<EventTcpClient> clients, EventTcpClientListener listener)
    {
        this.isListening = isListening;
        this.sockServer = sockServer;
        this.clientLock = clientLock;
        this.clients = clients;
        this.listener = listener;
    }
}
