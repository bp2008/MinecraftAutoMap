package com.minecraftam.automap;

import net.minecraft.item.ItemStack;


public class AMW_BlockList
{
	public static String getName(ItemStack itemStack)
	{
		String name = itemStack.getDisplayName();
		if(name == null || name.equals(""))
			name = "unknown_block";
		return name;
	}
}
