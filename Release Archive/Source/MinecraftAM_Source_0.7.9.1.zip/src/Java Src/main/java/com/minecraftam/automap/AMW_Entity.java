package com.minecraftam.automap;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;

public class AMW_Entity
{
	public static final Class<Entity> wrappedClass = Entity.class;
	public Entity inst;
	public AMW_Entity(Entity param)
	{
		inst = param;
	}
	
	public String getName()
	{
		String name = EntityList.getEntityString(inst);
		if (name == null || name.equals(""))
			name = "unknown_entity";
		return name;
	}
	
	public double getX()
	{
		// Third double. (Minecraft's Z)
		return inst.posZ;
	}

	public double getY()
	{
		// First double. (Minecraft's X)
		return inst.posX;
	}

	public double getZ()
	{
		// Second double. (Minecraft's Y)
		return inst.posY;
	}
	
	public void setPosition(double x, double y, double z)
	{
		inst.setPosition(y,z,x);
	}

	public float getRotation(boolean useAlternateRotationValue)
	{
		return useAlternateRotationValue ? inst.prevRotationYaw : inst.rotationYaw;
	}

	public float getPitch(boolean useAlternateRotationValue)
	{
		return useAlternateRotationValue ? inst.prevRotationPitch : inst.rotationPitch;
	}
}
