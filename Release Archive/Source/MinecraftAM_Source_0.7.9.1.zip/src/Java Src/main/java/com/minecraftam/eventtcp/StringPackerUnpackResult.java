package com.minecraftam.eventtcp;



import java.util.Vector;

/**
 *
 * @author Brian
 */
public class StringPackerUnpackResult
{
    public Vector<String> strings;
    public String s;
    public StringPackerUnpackResult()
    {
        s = "";
    }
}
