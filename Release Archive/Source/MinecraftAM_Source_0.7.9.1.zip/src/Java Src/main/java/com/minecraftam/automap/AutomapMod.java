package com.minecraftam.automap;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = "minecraftautomap", name = "Minecraft AutoMap", version = AutomapMod.MCAM_VERSION)
public class AutomapMod
{
	public static final String MCAM_VERSION = "29";
	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent event)
	{

	}

	@Mod.EventHandler
	public void init(FMLInitializationEvent event)
	{

	}

	@Mod.EventHandler
	public void postInit(FMLPostInitializationEvent event) throws Exception
	{
			Minecraft mc = Minecraft.getMinecraft();
			AutomapServer.initialize(new AM_MCWorld(new AMW_Minecraft(mc)));
	}
}
