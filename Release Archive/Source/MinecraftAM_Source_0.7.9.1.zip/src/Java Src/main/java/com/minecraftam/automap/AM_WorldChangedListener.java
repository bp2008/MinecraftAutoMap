package com.minecraftam.automap;


public interface AM_WorldChangedListener
{
	public void WorldChanged(boolean isMultiplayer);
}
