import net.minecraft.client.Minecraft;

public class AMW_ScreenOut
{
	private static Minecraft mc;
	public static void DisplayMessage(String message)
	{
		// Scroll to bottom to find this function
		// Fixed 14
		mc.w.a("�E" + message);
	}
	public static void Initialize(Minecraft parammc)
	{
		mc = parammc;
	}
}
