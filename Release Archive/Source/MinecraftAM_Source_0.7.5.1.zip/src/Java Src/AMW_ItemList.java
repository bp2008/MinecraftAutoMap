
public class AMW_ItemList
{
	// Find class with "shovelIron"
	public static int getImageIndex(int itemID)
	{
		// Last int before 2 bools -- this int is uninitialized
		// Fixed 14
		return ww.e[itemID].bO;
	}
	public static String getName(int itemID)
	{
		// Near the bottom (sort of)
		// Fixed 14
		return ww.e[itemID].e();
	}
}
