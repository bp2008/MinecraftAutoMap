public class AMW_WorldInfo
{
	// Find this class with "SizeOnDisk"
	// Fixed 14
	ve inst;
	// Fixed 14
	public AMW_WorldInfo(ve param)
	{
		inst = param;
	}
	public String getName()
	{
		// Fixed 14
		return inst.j();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Fixed 14
		return inst.e() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Fixed 14
		return inst.c();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Fixed 14
		return inst.d();
	}
}
