public class AMW_Player extends AMW_NamedEntity
{
	// Find with "http://s3.amazonaws.com/MinecraftCloaks/"
	// Fixed 14
	public static final Class<xb> wrappedClass = xb.class;
	// Fixed 14
	public xb inst;

	// Fixed 14
	public AMW_Player(xb param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		// first String, not far at all down the page, should be 2 strings
		// total, close together
		// Fixed 14
		return inst.aA;
	}
}
