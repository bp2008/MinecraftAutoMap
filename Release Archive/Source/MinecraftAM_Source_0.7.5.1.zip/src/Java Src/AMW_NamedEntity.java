public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 14
	public static final Class<aar> wrappedClass = aar.class;
	// Fixed 14
	public aar inst;

	// Fixed 14
	public AMW_NamedEntity(aar param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity")
			name = null;
		if (name == null || name.equals(""))
			// Fixed 14
			name = inst.o(); // fully qualified name? Or perhaps sound file ID
		if (name == null || name.equals(""))
			// Fixed 14
			name = inst.bm; // entity texture? (String literal at the top of the
							// file)
		if (name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
