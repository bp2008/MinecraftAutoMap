

public interface AM_WorldChangedListener
{
	public void WorldChanged();
}
