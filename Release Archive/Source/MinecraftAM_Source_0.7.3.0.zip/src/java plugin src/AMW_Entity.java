public class AMW_Entity
{
	// Fixed 11
	public static final Class<sn> wrappedClass = sn.class;
	// Fixed 11
	public sn inst;
	// Fixed 11
	public AMW_Entity(sn param)
	{
		inst = param;
	}

	public String getName()
	{
		// Find the class by searching for "Creeper"
		// Fixed 11
		String name = jc.b(inst);
		if (name == null || name.equals(""))
			name = "unknown_entity";
		return name;
	}
	
	public double getX()
	{
		// These 3 are down below in the SetPosition Function in decompiled source.
		// Third double.
		// Fixed 11
		return inst.aO;
	}

	public double getY()
	{
		// First double.
		// Fixed 11
		return inst.aM;
	}

	public double getZ()
	{
		// Second double.
		// Fixed 11
		return inst.aN;
	}
	
	public void setPosition(double x, double y, double z)
	{
		// Fixed 11a
		inst.e(y,z,x);
		/*
	public void d(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.aM = paramDouble1;
    this.aN = paramDouble2;
    this.aO = paramDouble3;
    float f1 = this.bg / 2.0F;
    float f2 = this.bh;
    this.aW.c(paramDouble1 - f1, paramDouble2 - this.bf + this.bo, paramDouble3 - f1, paramDouble1 + f1, paramDouble2 - this.bf + this.bo + f2, paramDouble3 + f1);
  }
		 */
	}

	public float getRotation(boolean useAlternateRotationValue)
	{
		// Fixed 11
		return useAlternateRotationValue ? inst.aU : inst.aS;
	}

	public float getPitch(boolean useAlternateRotationValue)
	{
		// Fixed 11
		return useAlternateRotationValue ? inst.aV : inst.aT;
	}
}
