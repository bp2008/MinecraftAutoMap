//public class Z_AMLOADER
//{
//  private int d;
//  private int e;
//  public double a;
//  public double b;
//  public int c;
//
//  public Z_AMLOADER(jz paramjz, int paramInt1, int paramInt2)
//  {
//    this.d = paramInt1;
//    this.e = paramInt2;
//    this.c = 1;
//
//    int i = paramjz.I;
//    if (i == 0) i = 1000;
//    while ((this.c < i) && (this.d / (this.c + 1) >= 320) && (this.e / (this.c + 1) >= 240)) {
//      this.c += 1;
//    }
//    this.a = (this.d / this.c);
//    this.b = (this.e / this.c);
//    this.d = (int)Math.ceil(this.a);
//    this.e = (int)Math.ceil(this.b);
//	AutomapLoader.LoadAM(paramjz.x);
//  }
//
//  public int a() {
//    return this.d;
//  }
//
//  public int b() {
//    return this.e;
//  }
//}