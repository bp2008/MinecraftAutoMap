//package org.brian.eventtcp;
//
//
//
//import java.util.Vector;
//
///**
// *
// * @author Brian
// */
///// <summary>
///// Marks the end of a string by duplicating all existing '$' in the string and adding a single '$' to the end.
///// </summary>
//public class StringPacker
//{
//    /// <summary>
//    /// Duplicates all '$' and adds one '$' to the end of the string to mark its end.  Also adds a ' ' to the beginning to mark the beginning.
//    /// </summary>
//    /// <param name="s">The string to "pack"</param>
//    /// <returns>The packed string</returns>
//    public static String Pack(String s)
//    {
//        if (s == null || s.length() == 0)
//            return "";
//        return " " + s.replace("$", "$$") + "$";
//    }
//    /// <summary>
//    /// Adds to [strings] all unpacked strings from [s].  The returned strings will be in the original form that they were sent in.  The return value is any remaining unmatched string.  The return value should be appended to the next string to be unpacked from this source.
//    /// </summary>
//    /// <param name="s">The string to unpack.</param>
//    /// <param name="strings">The list which will be populated with unpacked strings.</param>
//    /// <returns>The return value is any remaining unmatched string remaining in s after the valid strings are unpacked.</returns>
//
//    public static void Unpack(StringPackerUnpackResult r)
//    {
//        //Regex rx = new Regex("((\\$\\$)|[^$])+?\\$(?!\\$)", RegexOptions.Singleline);
//        StringBuffer sb = new StringBuffer();
//        r.strings = new Vector<String>();
//        r.s = stringTrim(r.s, "\0");
//        //Match m = rx.Match(s);
//
//        // Here I am trusting that only "Packed" strings are sent to the server
//        // If a string does not begin correctly, or if it exceeds the maximum string
//        // size, the entirety of [s] will be cleared and parsing of s will end.
//        //
//        // Individual strings which loop from one buffer into the next will be returned
//        // and will be appended to the beginning of the next data received.
//        if (r.s.length() < 1 || r.s.charAt(0) != ' ' || r.s.length() > 25000000)
//        {
//            parseerrors++;
//            r.s = "";
//            return;
//        }
//
//        int i = 1;
//
//        while (i < r.s.length())
//        {
//            // Append characters onto [sb] until [s] is empty or we find a $.
//            for (; i < r.s.length() && r.s.charAt(i) != '$'; i++)
//                sb.append(r.s.charAt(i));
//
//            // I could have gotten here because I have already appended the last character
//            // onto [sb] (and it was not a $), or because s[i] is a $.
//            if (i < r.s.length())
//            {
//                // I must have found a $. Either the $ I read was the end of [s] or not.
//                i++;
//                if (i < r.s.length())
//                {
//                    // There is more text. See if this is a legit $ or the end of a string
//                    if (r.s.charAt(i) == '$')
//                    {
//                        // Go on.
//                        sb.append('$');
//                    } else if (r.s.charAt(i) == ' ')
//                    {
//                        // The $ was the end of a string.
//                        r.strings.add(sb.toString());
//                        sb = new StringBuffer();
//                    } else
//                    {
//                        // There was a single $ not followed by a $ or space!
//                        parseerrorsType2++;
//                        System.out.println("StringPacker.Unpack error: Single $ found not followed by a $ or a space.");
//                        r.s = "";
//                        return;
//                    }
//                } else
//                {
//                    // That $ was the end of [s]. Yay!
//                    r.strings.add(sb.toString());
//                    sb = new StringBuffer();
//                    r.s = "";
//                }
//            } else
//            {
//                // That was the end.  I have leftovers to return.
//                r.s = sb.toString();
//                return;
//            }
//            // Increment i so that on the next loop iteration we start on a fresh character.
//            i++;
//        }
//        r.s = "";
//    }
//public static int parseerrors = 0;
//public static int parseerrorsType2 = 0;
//    private static String stringTrim(String s, String c)
//    {
//        while (s.endsWith(c))
//            s = s.substring(0, s.length() - 1);
//        return s;
//    }
//}
package org.brian.eventtcp;

import java.util.Vector;

/**
 *
 * @author Brian
 */
/// <summary>
/// Marks the end of a string by duplicating all existing '$' in the string and adding a single '$' to the end.
/// </summary>
public class StringPacker
{
    public static int parseerrors = 0;
    public static int parseerrorsType2 = 0;
    public static int existing255s = 0;
    private static char endMark = (char) 255;
    /// <summary>
    /// Adds char 255 to the end of the string.
    /// </summary>
    /// <param name="s">The string to "pack"</param>
    /// <returns>The packed string</returns>

    public static String Pack(String s)
    {
        if (s == null || s.length() == 0)
            return "";
        //existing255s += count(s, endMark);
        return s + endMark;
    }

    @SuppressWarnings("unused")
	private static int count(String s, char c)
    {
        int cnt = 0;
        for (int i = 0; i < s.length(); i++)
        {
            if (s.charAt(i) == c)
                cnt++;
        }
        return cnt;
    }
    /// <summary>
    /// Adds to [strings] all unpacked strings from [s].  The returned strings will be in the original form that they were sent in.  The return value is any remaining unmatched string.  The return value should be appended to the next string to be unpacked from this source.
    /// </summary>
    /// <param name="s">The string to unpack.</param>
    /// <param name="strings">The list which will be populated with unpacked strings.</param>
    /// <returns>The return value is any remaining unmatched string remaining in s after the valid strings are unpacked.</returns>

    public static void Unpack(StringPackerUnpackResult r)
    {
        StringBuffer sb = new StringBuffer();
        r.strings = new Vector<String>();
        //String f = stringTrim(r.s, String.valueOf((char)0), 0); //<-- This SOB has given us hell.  Strings with Legit (char)0 in them were getting axed.

        if (r.s.length() < 1)
        {
            parseerrors++;
            r.s = "";
            return;
        }

        for (int i = 0; i < r.s.length(); i++)
        {
            char next = r.s.charAt(i);
            if (next == endMark)
            {
                r.strings.add(sb.toString());
                sb = new StringBuffer();
            } else
                sb.append(next);
        }
        r.s = sb.toString();
    }

    /**
     * Removes all occurrences of c in s up to max times.  A value of 0 or less in max will cause all occurrences of c to be removed.
     * @param s
     * @param c
     * @param max
     * @return
     */
    @SuppressWarnings("unused")
	private static String stringTrim(String s, String c, int max)
    {
        if (max <= 0)
        {
            while (s.endsWith(c))
                s = s.substring(0, s.length() - 1);
        } else
        {
            int i = 0;
            while (s.endsWith(c))
            {
                if (i < max)
                    s = s.substring(0, s.length() - 1);
                else
                    break;
                i++;
            }
        }
        return s;
    }
}
