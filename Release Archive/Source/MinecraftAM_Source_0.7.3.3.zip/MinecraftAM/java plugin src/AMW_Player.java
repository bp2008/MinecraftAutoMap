public class AMW_Player extends AMW_NamedEntity
{
	// Find with "http://s3.amazonaws.com/MinecraftCloaks/"
	// Fixed 12
	public static final Class<sz> wrappedClass = sz.class;
	// Fixed 12
	public sz inst;
	// Fixed 12
	public AMW_Player(sz param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		// first String, not far at all down the page, should be 2 strings total, close together
		// Fixed 12
		return inst.aD;
	}
}
