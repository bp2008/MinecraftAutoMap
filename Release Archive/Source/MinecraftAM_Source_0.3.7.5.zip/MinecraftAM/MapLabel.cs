﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MinecraftAM
{
    internal class MapLabel
    {
        private Vector2 posVector = new Vector2();
        private Vector2 originVect1 = new Vector2();
        private Vector2 originVect2 = new Vector2();
        private Vector2 originVect3 = new Vector2();
        private Vector2 originVect4 = new Vector2();
        private Vector2 originVect = new Vector2();
        internal void Draw(SpriteBatch spriteBatch, string text, int x, int y, float scale, float rotation, SpriteFont toolTipFont)
        {
            posVector.X = x;
            posVector.Y = y;
            Vector2 textSize = toolTipFont.MeasureString(text);
            originVect.X = textSize.X / 2;
            originVect.Y = (float)(textSize.Y * 1.5);
            originVect1.X = originVect.X + 1;
            originVect1.Y = originVect.Y - 1;
            originVect2.X = originVect.X + 1;
            originVect2.Y = originVect.Y + 1;
            originVect3.X = originVect.X - 1;
            originVect3.Y = originVect.Y + 1;
            originVect4.X = originVect.X - 1;
            originVect4.Y = originVect.Y - 1;

            spriteBatch.DrawString(toolTipFont, text, posVector, Color.White, rotation, originVect1, scale, SpriteEffects.None, 0);
            spriteBatch.DrawString(toolTipFont, text, posVector, Color.White, rotation, originVect2, scale, SpriteEffects.None, 0);
            spriteBatch.DrawString(toolTipFont, text, posVector, Color.White, rotation, originVect3, scale, SpriteEffects.None, 0);
            spriteBatch.DrawString(toolTipFont, text, posVector, Color.White, rotation, originVect4, scale, SpriteEffects.None, 0);
            spriteBatch.DrawString(toolTipFont, text, posVector, Color.Black, rotation, originVect, scale, SpriteEffects.None, 0);
        }
    }
}
