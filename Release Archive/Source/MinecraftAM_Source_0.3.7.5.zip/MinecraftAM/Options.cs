﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MinecraftAM
{
    public partial class Options : Form
    {
        public Options()
        {
            InitializeComponent();
        }

        private void Options_Load(object sender, EventArgs e)
        {
            ApplyToUI();
        }

        public void ApplyToUI()
        {
            nudProcessPriority.Value = (int)AMSettings.ProcessPriority;
            if (AMSettings.iDynamicMapMaxX > nudDynamicMapMaxWidth.Maximum)
                AMSettings.iDynamicMapMaxX = (int)nudDynamicMapMaxWidth.Maximum;
            if (AMSettings.iDynamicMapMinX < nudDynamicMapMinWidth.Minimum)
                AMSettings.iDynamicMapMinX = (int)nudDynamicMapMinWidth.Minimum;
            nudDynamicMapMaxWidth.Value = (int)AMSettings.iDynamicMapMaxX;
            nudDynamicMapMinWidth.Value = (int)AMSettings.iDynamicMapMinX;
            cbLava.Checked = AMSettings.bLavaDetection;
            cbWater.Checked = AMSettings.bWaterDetection;
            cbOreDetection.Checked = AMSettings.bOreDetection;
            cbStatusText.Checked = AMSettings.bShowStatusText;
            cbHotkeys.Checked = AMSettings.bShowHotkeys;
            cbShowRealtimeMap.Checked = AMSettings.bDynamicMapEnabled;
            cbHideMapZoomed.Checked = AMSettings.bDynamicMapHiddenZoomedOut;
            txtLava.Text = AMSettings.sLavaDetection;
            txtWater.Text = AMSettings.sWaterDetection;
            txtOre.Text = AMSettings.sOreDetection;
            txtStatusText.Text = AMSettings.sShowStatusText;
            txtHotkeys.Text = AMSettings.sShowHotkeys;
            txtShowRealtimeMap.Text = AMSettings.sDynamicMapEnabled;
            txtShowOptions.Text = AMSettings.sShowOptions;
            txtCI.Text = AMSettings.sCI;
            txtCD.Text = AMSettings.sCD;
            txtCR.Text = AMSettings.sCR;
            txtRotate.Text = AMSettings.sRotate;
            txtShowCompass.Text = AMSettings.sCompass;
            txtStick.Text = AMSettings.sStick;
            nudIDD.Value = AMSettings.iIndoorDepth;
            nudOCH.Value = AMSettings.iOutdoorCeiling;
            nudODD.Value = AMSettings.iOutdoorDepth;
            cbRotate.Checked = AMSettings.bRotate;
            cbShowCompass.Checked = AMSettings.bCompass;
            cbGlowingPath.Checked = AMSettings.bGlowingPath;
            txtGlowingPath.Text = AMSettings.sGlowingPath;
            nudGlowingIntensity.Value = AMSettings.iGlowingIntensity;
            txtUpdateStaticTerrain.Text = AMSettings.sUpdateStaticTerrain;
            txtClearGlowingPath.Text = AMSettings.sClearGlowingPath;
            txtResetRealtimeMap.Text = AMSettings.sResetRealtimeMap;
            txtMultiplayerMap.Text = AMSettings.sMultiplayerMap;
            nudMapWidth.Value = AMSettings.iMapWidth;
            nudMapHeight.Value = AMSettings.iMapHeight;
            nudMapX.Value = AMSettings.iMapOffsetX;
            nudMapY.Value = AMSettings.iMapOffsetY;
            txtCBG.Text = AMSettings.FromColor(AMSettings.cBackgroundColor);
            txtCGC.Text = AMSettings.FromColor(AMSettings.cNotDrawnBlockColor);
            nudDegMapRot.Value = AMSettings.iDefaultMapRotation;
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void nudProcessPriority_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.ProcessPriority = (AMSettings.Priority)((int)nudProcessPriority.Value);
            Globals.SetPriority();
        }

        private void nudDynamicMapMaxWidth_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iDynamicMapMaxX = (int)nudDynamicMapMaxWidth.Value;
            nudDynamicMapMinWidth.Maximum = AMSettings.iDynamicMapMaxX;
        }
        
        private void nudDynamicMapMinWidth_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iDynamicMapMinX = (int)nudDynamicMapMinWidth.Value;
            nudDynamicMapMaxWidth.Minimum = AMSettings.iDynamicMapMinX;
        }

        private void cbLava_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bLavaDetection = cbLava.Checked;
        }

        private void cbWater_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bWaterDetection = cbWater.Checked;
        }

        private void cbOreDetection_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bOreDetection = cbOreDetection.Checked;
        }

        private void cbStatusText_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bShowStatusText = cbStatusText.Checked;
        }

        private void cbHotkeys_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bShowHotkeys = cbHotkeys.Checked;
        }

        private void cbShowRealtimeMap_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bDynamicMapEnabled = cbShowRealtimeMap.Checked;
        }

        private void txtLava_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sLavaDetection = txtLava.Text.ToUpper();
        }

        private void txtWater_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sWaterDetection = txtWater.Text.ToUpper();
        }

        private void txtOre_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sOreDetection = txtOre.Text.ToUpper();
        }

        private void txtStatusText_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sShowStatusText = txtStatusText.Text.ToUpper();
        }

        private void txtHotkeys_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sShowHotkeys = txtHotkeys.Text.ToUpper();
        }

        private void txtShowRealtimeMap_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sDynamicMapEnabled = txtShowRealtimeMap.Text.ToUpper();
        }

        private void txtShowOptions_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sShowOptions = txtShowOptions.Text.ToUpper();
        }

        private void txtCI_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sCI = txtCI.Text.ToUpper();
        }

        private void txtCD_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sCD = txtCD.Text.ToUpper();
        }

        private void txtCR_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sCR = txtCR.Text.ToUpper();
        }

        private void txtStick_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sStick = txtStick.Text.ToUpper();
        }

        private void cbRotate_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bRotate = cbRotate.Checked;
        }

        private void cbShowCompass_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bCompass = cbShowCompass.Checked;
        }

        private void txtRotate_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sRotate = txtRotate.Text.ToUpper();
        }

        private void txtShowCompass_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sCompass = txtShowCompass.Text.ToUpper();
        }

        private void nudOCH_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iOutdoorCeiling = (int)nudOCH.Value;
        }

        private void nudODD_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iOutdoorDepth = (int)nudODD.Value;
        }

        private void nudIDD_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iIndoorDepth = (int)nudIDD.Value;
        }

        private void cbGlowingPath_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bGlowingPath = cbGlowingPath.Checked;
        }

        private void txtGlowingPath_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sGlowingPath = txtGlowingPath.Text.ToUpper();
        }

        private void nudGlowingIntensity_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iGlowingIntensity = (int)nudGlowingIntensity.Value;
        }

        private void txtUpdateStaticTerrain_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sUpdateStaticTerrain = txtUpdateStaticTerrain.Text.ToUpper();
        }

        private void cbHideMapZoomed_CheckedChanged(object sender, EventArgs e)
        {
            AMSettings.bDynamicMapHiddenZoomedOut = cbHideMapZoomed.Checked;
        }

        private void txtClearGlowingPath_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sClearGlowingPath = txtClearGlowingPath.Text.ToUpper();
        }

        private void btnBrowseForMap_Click(object sender, EventArgs e)
        {
            openFileDialogSMPMap.Title = "Select a map image to use in SMP";
            DialogResult dr = openFileDialogSMPMap.ShowDialog();
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                txtMultiplayerMap.Text = openFileDialogSMPMap.FileName;
            }
        }

        private void txtMultiplayerMap_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sMultiplayerMap = txtMultiplayerMap.Text;
        }

        private void txtResetRealtimeMap_TextChanged(object sender, EventArgs e)
        {
            AMSettings.sResetRealtimeMap = txtResetRealtimeMap.Text;
        }

        private void nudMapWidth_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iMapWidth = (int)nudMapWidth.Value;
        }

        private void nudMapHeight_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iMapHeight = (int)nudMapHeight.Value;
        }

        private void nudMapX_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iMapOffsetX = (int)nudMapX.Value;
        }

        private void nudMapY_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iMapOffsetY = (int)nudMapY.Value;
        }

        private void Options_FormClosed(object sender, FormClosedEventArgs e)
        {
            Globals.optionsOpen = false;
            Globals.bCheckMultiplayerMap = true;
            AMSettings.Save();
        }

        private void txtCBG_TextChanged(object sender, EventArgs e)
        {
            AMSettings.cBackgroundColor = AMSettings.GetColor(txtCBG.Text, AMSettings.cBackgroundColor);
        }

        private void txtCGC_TextChanged(object sender, EventArgs e)
        {
            AMSettings.cNotDrawnBlockColor = AMSettings.GetColor(txtCGC.Text, AMSettings.cNotDrawnBlockColor);
        }

        private void nudDegMapRot_ValueChanged(object sender, EventArgs e)
        {
            AMSettings.iDefaultMapRotation = (int)nudDegMapRot.Value;
        }
    }
}
