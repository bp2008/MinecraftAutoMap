﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace MinecraftAM
{
    public static class AMSettings
    {
        private static FileInfo fiSettings = new FileInfo("MinecraftAMSettings.txt");
        public enum Priority
        {
            Low, BelowNormal, Normal
        }
        // Configurable Settings
        public static int iDrawingOffsetZ = 0;
        public static Priority ProcessPriority = Priority.BelowNormal;
        public static bool bLavaDetection = true;
        public static bool bWaterDetection = true;
        public static bool bOreDetection = false;
        public static bool bShowStatusText = true;
        public static bool bShowHotkeys = false;
        public static bool bDynamicMapEnabled = true;
        public static bool bDynamicMapHiddenZoomedOut = true;
        public static string sLavaDetection = "L";
        public static string sWaterDetection = "W";
        public static string sOreDetection = "M";
        public static string sShowStatusText = "S";
        public static string sShowHotkeys = "H";
        public static string sDynamicMapEnabled = "D";
        public static string sShowOptions = "O";
        public static string sCI = "=";
        public static string sCD = "-";
        public static string sCR = "0";
        public static string sRotate = "R";
        public static string sCompass = "C";
        public static string sStick = "F";
        private static int iDynamicMapMaxPrivateX = 220;
        private static int iDynamicMapMinPrivateX = 40;
        public static int iIndoorDepth = 30;
        public static int iOutdoorCeiling = 40;
        public static int iOutdoorDepth = 70;
        public static bool bRotate = false;
        public static bool bCompass = true;
        public static bool bGlowingPath = false;
        public static string sGlowingPath = "G";
        public static string sClearGlowingPath = "P";
        public static int iGlowingIntensity = 75; // amount of red color to add to visited squares.
        public static string sUpdateStaticTerrain = "U";
        public static string sMultiplayerMap = "C:\\Multiplayer.png";
        public static int iMapWidth = 1000;
        public static int iMapHeight = 1000;
        public static int iMapOffsetX = 500;
        public static int iMapOffsetY = 500;
        public static string sResetRealtimeMap = "X";
        public static Microsoft.Xna.Framework.Color cBackgroundColor = GetColor("79,79,79,255", Microsoft.Xna.Framework.Color.Gray);
        public static Microsoft.Xna.Framework.Color cNotDrawnBlockColor = GetColor("47,47,47,255", Microsoft.Xna.Framework.Color.Gray);
        public static int iDefaultMapRotation = 0;
        public static string sHostName = "localhost";
        public static int iDynamicMapMaxX
        {
            get
            {
                return iDynamicMapMaxPrivateX;
            }
            set
            {
                if (value > 254)
                    iDynamicMapMaxPrivateX = 254;
                else if (value < 10)
                    iDynamicMapMaxPrivateX = 10;
                else if (value < iDynamicMapMinPrivateX)
                    value = iDynamicMapMinPrivateX;
                else
                    iDynamicMapMaxPrivateX = value;
            }
        }
        public static int iDynamicMapMinX
        {
            get
            {
                return iDynamicMapMinPrivateX;
            }
            set
            {
                if (value > 254)
                    iDynamicMapMinPrivateX = 254;
                else if (value < 10)
                    iDynamicMapMinPrivateX = 10;
                else if (value > iDynamicMapMaxPrivateX)
                    value = iDynamicMapMaxPrivateX;
                else
                    iDynamicMapMinPrivateX = value;
            }
        }
        public static void Load()
        {
            StreamReader sr = null;
            try
            {
                if (fiSettings.Exists)
                {
                    sr = new StreamReader(fiSettings.FullName);
                    string sFull = sr.ReadToEnd();
                    sr.Close();
                    string[] parts = sFull.Split(new char[] { '\r', '\n' });
                    for (int i = 0; i < parts.Length; i++)
                    {
                        try
                        {
                            String[] keyAndValue = parts[i].Split('=');
                            if (keyAndValue.Length >= 2)
                            {
                                if (keyAndValue.Length > 2)
                                    if (keyAndValue[1].Length == 0 && keyAndValue[2].Length == 0)
                                        keyAndValue[1] = "=";
                                if (keyAndValue[0] == "iDrawingOffsetZ")
                                    iDrawingOffsetZ = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "ProcessPriority")
                                    ProcessPriority = (Priority)int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "bLavaDetection")
                                    bLavaDetection = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bWaterDetection")
                                    bWaterDetection = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bOreDetection")
                                    bOreDetection = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bShowStatusText")
                                    bShowStatusText = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bShowHotkeys")
                                    bShowHotkeys = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bDynamicMapEnabled")
                                    bDynamicMapEnabled = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bDynamicMapHiddenZoomedOut")
                                    bDynamicMapHiddenZoomedOut = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "iDynamicMapMaxX")
                                    iDynamicMapMaxX = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "iDynamicMapMinX")
                                    iDynamicMapMinX = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "sLavaDetection")
                                    sLavaDetection = keyAndValue[1];
                                else if (keyAndValue[0] == "sWaterDetection")
                                    sWaterDetection = keyAndValue[1];
                                else if (keyAndValue[0] == "sOreDetection")
                                    sOreDetection = keyAndValue[1];
                                else if (keyAndValue[0] == "sShowStatusText")
                                    sShowStatusText = keyAndValue[1];
                                else if (keyAndValue[0] == "sShowHotkeys")
                                    sShowHotkeys = keyAndValue[1];
                                else if (keyAndValue[0] == "sDynamicMapEnabled")
                                    sDynamicMapEnabled = keyAndValue[1];
                                else if (keyAndValue[0] == "sShowOptions")
                                    sShowOptions = keyAndValue[1];
                                else if (keyAndValue[0] == "sCI")
                                    sCI = keyAndValue[1];
                                else if (keyAndValue[0] == "sCD")
                                    sCD = keyAndValue[1];
                                else if (keyAndValue[0] == "sCR")
                                    sCR = keyAndValue[1];
                                else if (keyAndValue[0] == "sRotate")
                                    sRotate = keyAndValue[1];
                                else if (keyAndValue[0] == "sCompass")
                                    sCompass = keyAndValue[1];
                                else if (keyAndValue[0] == "sStick")
                                    sStick = keyAndValue[1];
                                else if (keyAndValue[0] == "iIndoorDepth")
                                    iIndoorDepth = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "iOutdoorCeiling")
                                    iOutdoorCeiling = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "iOutdoorDepth")
                                    iOutdoorDepth = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "bRotate")
                                    bRotate = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bCompass")
                                    bCompass = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "bGlowingPath")
                                    bGlowingPath = ParseBool(keyAndValue[1]);
                                else if (keyAndValue[0] == "sGlowingPath")
                                    sGlowingPath = keyAndValue[1];
                                else if (keyAndValue[0] == "sClearGlowingPath")
                                    sClearGlowingPath = keyAndValue[1];
                                else if (keyAndValue[0] == "iGlowingIntensity")
                                    iGlowingIntensity = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "sUpdateStaticTerrain")
                                    sUpdateStaticTerrain = keyAndValue[1];
                                else if (keyAndValue[0] == "sMultiplayerMap")
                                    sMultiplayerMap = keyAndValue[1];
                                else if (keyAndValue[0] == "iMapWidth")
                                    iMapWidth = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "iMapHeight")
                                    iMapHeight = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "iMapOffsetX")
                                    iMapOffsetX = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "iMapOffsetY")
                                    iMapOffsetY = int.Parse(keyAndValue[1]);
                                else if (keyAndValue[0] == "sResetRealtimeMap")
                                    sResetRealtimeMap = keyAndValue[1];
                                else if (keyAndValue[0] == "sHostName")
                                    sHostName = keyAndValue[1];
                                else if (keyAndValue[0] == "cBackgroundColor")
                                    cBackgroundColor = GetColor(keyAndValue[1], cBackgroundColor);
                                else if (keyAndValue[0] == "cNotDrawnBlockColor")
                                    cNotDrawnBlockColor = GetColor(keyAndValue[1], cNotDrawnBlockColor);
                                else if(keyAndValue[0] == "iDefaultMapRotation")
                                    iDefaultMapRotation = int.Parse(keyAndValue[1]);
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message + " " + ex.StackTrace);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                try
                {
                    if (sr != null)
                        sr.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + " " + ex.StackTrace);
                }
            }
        }

        public static void Save()
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(fiSettings.FullName, false);
                sw.WriteLine("iDrawingOffsetZ=" + iDrawingOffsetZ);
                sw.WriteLine("ProcessPriority=" + (int)ProcessPriority);
                sw.WriteLine("bLavaDetection=" + bLavaDetection);
                sw.WriteLine("bWaterDetection=" + bWaterDetection);
                sw.WriteLine("bOreDetection=" + bOreDetection);
                sw.WriteLine("bShowStatusText=" + bShowStatusText);
                sw.WriteLine("bShowHotkeys=" + bShowHotkeys);
                sw.WriteLine("bDynamicMapEnabled=" + bDynamicMapEnabled);
                sw.WriteLine("bDynamicMapHiddenZoomedOut=" + bDynamicMapHiddenZoomedOut);
                sw.WriteLine("iDynamicMapMaxX=" + iDynamicMapMaxX);
                sw.WriteLine("iDynamicMapMinX=" + iDynamicMapMinX);
                sw.WriteLine("sLavaDetection=" + sLavaDetection);
                sw.WriteLine("sWaterDetection=" + sWaterDetection);
                sw.WriteLine("sOreDetection=" + sOreDetection);
                sw.WriteLine("sShowStatusText=" + sShowStatusText);
                sw.WriteLine("sShowHotkeys=" + sShowHotkeys);
                sw.WriteLine("sDynamicMapEnabled=" + sDynamicMapEnabled);
                sw.WriteLine("sShowOptions=" + sShowOptions);
                sw.WriteLine("sCI=" + sCI);
                sw.WriteLine("sCD=" + sCD);
                sw.WriteLine("sRotate=" + sRotate);
                sw.WriteLine("sCompass=" + sCompass);
                sw.WriteLine("sStick=" + sStick);
                sw.WriteLine("iIndoorDepth=" + iIndoorDepth);
                sw.WriteLine("iOutdoorCeiling=" + iOutdoorCeiling);
                sw.WriteLine("iOutdoorDepth=" + iOutdoorDepth);
                sw.WriteLine("bRotate=" + bRotate);
                sw.WriteLine("bCompass=" + bCompass);
                sw.WriteLine("bGlowingPath=" + bGlowingPath);
                sw.WriteLine("sGlowingPath=" + sGlowingPath);
                sw.WriteLine("sClearGlowingPath=" + sClearGlowingPath);
                sw.WriteLine("iGlowingIntensity=" + iGlowingIntensity);
                sw.WriteLine("sUpdateStaticTerrain=" + sUpdateStaticTerrain);
                sw.WriteLine("sMultiplayerMap=" + sMultiplayerMap);
                sw.WriteLine("iMapWidth=" + iMapWidth);
                sw.WriteLine("iMapHeight=" + iMapHeight);
                sw.WriteLine("iMapOffsetX=" + iMapOffsetX);
                sw.WriteLine("iMapOffsetY=" + iMapOffsetY);
                sw.WriteLine("sResetRealtimeMap=" + sResetRealtimeMap);
                sw.WriteLine("sHostName=" + sHostName);
                sw.WriteLine("cBackgroundColor=" + FromColor(cBackgroundColor));
                sw.WriteLine("cNotDrawnBlockColor=" + FromColor(cNotDrawnBlockColor));
                sw.WriteLine("iDefaultMapRotation=" + iDefaultMapRotation);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                try
                {
                    if (sw != null)
                        sw.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + " " + ex.StackTrace);
                }
            }
        }

        private static bool ParseBool(string str)
        {
            return str == "1" || str.ToLower() == "true";
        }
        internal static Microsoft.Xna.Framework.Color GetColor(string str, Microsoft.Xna.Framework.Color defaultColor)
        {
            try
            {
                // Lets check for a wide variety of separators in case people do what people do.
                string[] strs = str.Split(new char[] { ',', ' ', '.', '/', '\\', '\'', '"', ';', ':', '<', '>' });
                return new Microsoft.Xna.Framework.Color(int.Parse(strs[0]), int.Parse(strs[1]), int.Parse(strs[2]), int.Parse(strs[3]));
            }
            catch (Exception)
            {
                return defaultColor;
            }
        }
        internal static string FromColor(Microsoft.Xna.Framework.Color col)
        {
            return col.R.ToString() + ',' + col.G.ToString() + ',' + col.B.ToString() + ',' + col.A.ToString();
        }
    }
}
