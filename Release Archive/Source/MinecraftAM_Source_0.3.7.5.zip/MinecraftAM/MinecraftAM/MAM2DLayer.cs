﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.Threading;

namespace MinecraftAM
{
    class MAM2DLayer : DataSource.DSHandlerPlayerLocation, DataSource.DSHandlerWorldPath
    {
        DateTime startedAt = DateTime.Now;
        DateTime lastUpdate = DateTime.Now;
        DateTime lastRedraw = DateTime.Now;
        DateTime lastChunkUpdate = DateTime.Now + new TimeSpan(0, 0, 10);
        DateTime canUpdateBlocks = DateTime.Now;
        TimeSpan timeTillUpdateBlocks = new TimeSpan(0, 0, 0, 10, 0);
        TimeSpan timeTillUpdate = new TimeSpan(0, 0, 0, 0, 100);
        int msBetweenPositionUpdates = 33;
        int msBetweenChunkUpdates = 2000;
        TimeSpan timeTillForcedRedraw = new TimeSpan(0, 0, 0, 1, 0);
        TimeSpan timeTillStop = new TimeSpan(0, 0, 0, 10, 0);
        IntVector3 vLastPlayerLoc = null;

        private bool bThreadAbort = false;

        SpriteBatch spriteBatch;
        GraphicsDevice gd;
        Texture2D blockBlack;
        Texture2D fire;
        Texture2D arrowPlayer;
        Texture2D arrowOtherPlayer;
        Texture2D blockTiles;
        Texture2D itemTiles;
        Texture2D worldMap = null;
        SpriteFont toolTipFont;

        Thread positionRequesterThread = null;
        Thread chunkRequesterThread = null;

        MapLabel playerLabel = new MapLabel();


        public MAM2DLayer(GraphicsDevice gDevice)
        {
            DataSource.DS.InitializePlayerLocation(this, Globals.TileWidth, Globals.TileHeight, Chunk.chunkSize);
            DataSource.DS.InitializeWorldPath(this);
            gd = gDevice;
            spriteBatch = new SpriteBatch(gd);
            positionRequesterThread = new Thread(PositionRequester);
            positionRequesterThread.Name = "Position Update Requester";
            positionRequesterThread.Start();
            chunkRequesterThread = new Thread(ChunkUpdateRequester);
            chunkRequesterThread.Name = "Chunk Update Requester";
            chunkRequesterThread.Start();
        }
        public void LoadContent(ContentManager Content)
        {
            fire = Content.Load<Texture2D>("Graphics\\MCBlocks\\Fire");
            //FileStream fiFire = new FileStream("Fire.png", FileMode.Open, FileAccess.Read);
            //fire = Texture2D.FromStream(gd, fiFire);
            //fiFire.Close();
            blockBlack = Content.Load<Texture2D>("Graphics\\MCBlocks\\BlockBlack");
            FileStream fiBlocks = new FileStream("terrain.png", FileMode.Open, FileAccess.Read);
            blockTiles = Texture2D.FromStream(gd, fiBlocks);
            Globals.textureSize = blockTiles.Width / 16;
            fiBlocks.Close();
            FileStream fiItems = new FileStream("items.png", FileMode.Open, FileAccess.Read);
            itemTiles = Texture2D.FromStream(gd, fiItems);
            fiItems.Close();
            arrowPlayer = Content.Load<Texture2D>("PlayerArrow");
            arrowOtherPlayer = Content.Load<Texture2D>("OtherPlayerArrow");
            toolTipFont = Content.Load<SpriteFont>("tooltip");
            Globals.pixel = Content.Load<Texture2D>("pixel");
            //PresentationParameters pp = gd.PresentationParameters;
            //renderTarget = new RenderTarget2D(gd, pp.BackBufferWidth, pp.BackBufferHeight);

        }
        public void WorldPathReceived(string worldPath)
        {
            Globals.bCanUpdateBlocks = true;
            canUpdateBlocks = DateTime.Now;
            //if (worldPath != Globals.worldPath || worldPath == "multiplayer")
            //{
            worldMap = null;
            Globals.chunks.ClearCache();
            Globals.loadingWorld = true;
            Globals.bCheckMultiplayerMap = true;
            //}
            Globals.worldPath = worldPath;
            if (worldPath == "multiplayer")
            {
                Globals.worldName = worldPath;
                Globals.multiplayer = true;
                return;
            }
            else
                Globals.multiplayer = false;
            Globals.worldName = worldPath.Substring(worldPath.LastIndexOf("\\") + 1);
            LoadWorldMap();
            BuildWorldMap();
        }

        private void BuildWorldMap()
        {
            if (Globals.multiplayer)
                return;
            lock (Globals.render)
            {
                if (worldMap == null && !File.Exists(Globals.worldName + Globals.worldMapImageExtension) && !Globals.rendering)
                {
                    Globals.rendering = true;
                    Globals.render.Render();
                }
            }
        }
        private void LoadWorldMap()
        {
            if (Globals.multiplayer)
            {
                Globals.worldMapOriginX = AMSettings.iMapOffsetX;
                Globals.worldMapOriginY = AMSettings.iMapOffsetY;
                Globals.worldMapWidth = AMSettings.iMapWidth;
                Globals.worldMapHeight = AMSettings.iMapHeight;
                if (!Globals.bCheckMultiplayerMap)
                    return;
                if (string.IsNullOrEmpty(AMSettings.sMultiplayerMap))
                    return;
                try
                {
                    FileInfo fiMap = new FileInfo(AMSettings.sMultiplayerMap);
                    if (!fiMap.Exists)
                    {
                        Globals.bCheckMultiplayerMap = false;
                        return;
                    }
                    if (!LoadMapImageFile(fiMap))
                        return;

                    Globals.worldName = fiMap.Name;
                    Globals.bCheckMultiplayerMap = false;
                }
                catch (Exception)
                {
                    Globals.bCheckMultiplayerMap = false;
                }
                return;
            }
            if ((worldMap == null || Globals.refreshWorldMap) && !Globals.rendering)
            {
                Globals.refreshWorldMap = false;
                FileInfo fiMap = new FileInfo(Globals.worldName + Globals.worldMapImageExtension);
                if (!fiMap.Exists)
                    return;

                if (!LoadMapImageFile(fiMap))
                    return;
                try
                {
                    string mapInfo = File.ReadAllText(Globals.worldName + "origin.txt");
                    string[] split = mapInfo.Split('\r');
                    string[] splitLoc = split[0].Split(',');
                    string[] splitSize = split[1].Split('x');
                    Globals.worldMapOriginX = Convert.ToInt32(splitLoc[0]);
                    Globals.worldMapOriginY = Convert.ToInt32(splitLoc[1]);
                    Globals.worldMapWidth = Convert.ToInt32(splitSize[0]);
                    Globals.worldMapHeight = Convert.ToInt32(splitSize[1]);
                }
                catch (Exception)
                {
                    File.Delete(Globals.worldName + Globals.worldMapImageExtension);
                    worldMap = null;
                }
            }
        }

        private bool LoadMapImageFile(FileInfo fiMap)
        {
            FileStream fiWorld = new FileStream(fiMap.FullName, FileMode.Open, FileAccess.Read);
            try
            {
                worldMap = Texture2D.FromStream(gd, fiWorld);
            }
            catch (Exception)
            {
                fiWorld.Close();
                if (Globals.multiplayer)
                    Globals.bCheckMultiplayerMap = false;
                else
                    File.Delete(Globals.worldName + Globals.worldMapImageExtension);
                System.Windows.Forms.MessageBox.Show("XNA Failed to load the world map image file " + fiMap.FullName);
                return false;
            }
            fiWorld.Close();
            return true;
        }

        public void StopThreads()
        {
            bThreadAbort = true;
        }

        public void PlayerLocationReceived(SortedList<string, DataSource.Player> players, string userPlayerName)
        {
            Globals.players = players;
            if (players.Count > 0)
            {
                if (players.ContainsKey(userPlayerName))
                    Globals.userPlayer = players[userPlayerName];
                else
                {
                    Globals.userPlayer = null;
                    Console.WriteLine("Player did not exist in player list");
                }
            }
            else
                Globals.userPlayer = null;

            // Detect warp / portal / teleporter use and stop requesting blocks temporarily, giving Minecraft time to load.
            if (Globals.userPlayer != null)
            {
                if (Globals.lastUserPlayer != null)
                {
                    double changeAmount = Globals.userPlayer.ChangeAmount(Globals.lastUserPlayer);
                    // if player moved a lot.
                    if (changeAmount > 10)
                    {
                        canUpdateBlocks = DateTime.Now + timeTillUpdateBlocks;
                        Globals.bCanUpdateBlocks = false;
                        Console.WriteLine(changeAmount);
                    }
                    // if player moved at all
                    else if (changeAmount > 0)
                    {
                        Globals.bCanUpdateBlocks = true;
                        Console.WriteLine(changeAmount);
                    }
                }
                Globals.lastUserPlayer = Globals.userPlayer;

            }

            if (Globals.lockToPlayer)
            {
                if (Globals.userPlayer != null)
                {
                    Globals.camX = Globals.round(Globals.userPlayer.pixelx);
                    Globals.camY = Globals.round(Globals.userPlayer.pixely);
                }
            }
            Block b = Globals.chunks.GetBlock(Globals.userPlayer.ix + 9, Globals.userPlayer.iy, Globals.userPlayer.iz - 1);
            if (b != null && b.blockType == BlockType.Snow)
                b.t = Globals.currentTrail;
            else
            {
                b = Globals.chunks.GetBlock(Globals.userPlayer.ix + 9, Globals.userPlayer.iy, Globals.userPlayer.iz - 2);
                if (b != null && !Block.transTextures[(int)b.blockType])
                    b.t = Globals.currentTrail;
            }
        }

        private void PositionRequester()
        {
            while (!bThreadAbort)
            {
                try
                {
                    DataSource.DS.GetPlayerLocation();
                }
                catch (Exception err)
                {
                    Globals.errMsg = err.Message;
                }
                Thread.Sleep(msBetweenPositionUpdates);
            }
        }
        private void ChunkUpdateRequester()
        {
            while (!bThreadAbort)
            {
                try
                {
                    IntVector3 vPlayerLoc = vLastPlayerLoc;
                    if (vPlayerLoc != null)
                        Globals.chunks.UpdateChunksAround(vPlayerLoc.X, vPlayerLoc.Y);
                }
                catch (Exception err)
                {
                    Globals.errMsg = err.Message;
                }
                Thread.Sleep(msBetweenChunkUpdates);
            }
        }

        DateTime requestedWorldPathAt = DateTime.Now - new TimeSpan(24, 0, 0);
        TimeSpan retryWorldPathTimer = new TimeSpan(0, 0, 5);
        public void Update(GameTime gameTime)
        {
            if (DateTime.Now - timeTillUpdate > lastUpdate)
            {
                if (string.IsNullOrEmpty(Globals.worldPath) && DateTime.Now - retryWorldPathTimer > requestedWorldPathAt)
                {
                    DataSource.DS.GetWorldPath();
                }
                lastUpdate = DateTime.Now;

                if (Globals.players != null && Globals.players.Count > 0 && Globals.userPlayer != null)
                {
                    IntVector3 vPlayerLoc = new IntVector3(Globals.round(Globals.userPlayer.x), Globals.round(Globals.userPlayer.y), Globals.round(Globals.userPlayer.z));
                    if (DateTime.Now - timeTillForcedRedraw > lastRedraw
                        || (vLastPlayerLoc == null || vPlayerLoc.X != vLastPlayerLoc.X || vPlayerLoc.Y != vLastPlayerLoc.Y || vPlayerLoc.Z != vLastPlayerLoc.Z))
                    { // player moved, redraw the map    
                        if (!string.IsNullOrEmpty(Globals.worldPath))
                        {
                            if (Globals.refreshWorldMap)
                            {
                                worldMap = null;
                                BuildWorldMap();
                            }
                            LoadWorldMap();
                        }

                        IntVector2 topLeft, bottomRight;
                        int halfWidth = (Globals.screenWidth / 2) / Globals.TileWidth;
                        int halfHeight = (Globals.screenHeight / 2) / Globals.TileHeight;
                        int tlx, tly, brx, bry;
                        float scale = 1f / Globals.camZoom;
                        float scaledHalfWidth = (halfWidth * scale);
                        float scaledHalfHeight = (halfHeight * scale);
                        if (AMSettings.bRotate || AMSettings.iDefaultMapRotation % 180 != 0)
                        {
                            float fullWidth = (scaledHalfWidth * 2);
                            float fullHeight = (scaledHalfHeight * 2);
                            float corner2corner = (float)Math.Sqrt((fullWidth * fullWidth) + (fullHeight * fullHeight));
                            if (halfWidth > halfHeight)
                            {
                                scaledHalfWidth *= corner2corner / fullWidth;
                                scaledHalfHeight = scaledHalfWidth;
                            }
                            else
                            { // I expect this code to never run... but hey, someone might have a rotatable monitor.
                                scaledHalfHeight *= corner2corner / fullWidth;
                                scaledHalfWidth = scaledHalfHeight;
                            }
                        }

                        tlx = ((vPlayerLoc.X + Chunk.chunkSizeM1) - (int)scaledHalfWidth) - 6;
                        tly = (vPlayerLoc.Y - (int)scaledHalfHeight) - 5;
                        brx = ((vPlayerLoc.X + Chunk.chunkSizeM1) + (int)scaledHalfWidth) + 6;
                        bry = (vPlayerLoc.Y + (int)scaledHalfHeight) + 6;
                        if (brx - tlx > AMSettings.iDynamicMapMaxX || (Math.Abs(Globals.panX) > 2500) || (Math.Abs(Globals.panY) > 2500))
                        {
                            Globals.zoomedOut = true;

                            Globals.locationTopLeft = new IntVector2(tlx, tly);
                            Globals.locationBottomRight = new IntVector2(brx, bry);
                            vLastPlayerLoc = vPlayerLoc;
                            Globals.vLastPlayerLoc = vLastPlayerLoc;

                            int overage = ((brx - tlx) - AMSettings.iDynamicMapMaxX) / 2;
                            float overagePrcnt = ((float)overage * 2f) / (float)(brx - tlx);
                            tlx += overage;
                            brx -= overage;
                            int yOverage = (int)(overagePrcnt * (float)(bry - tly)) / 2;
                            tly += yOverage;
                            bry -= yOverage;
                        }
                        else
                        {
                            Globals.zoomedOut = false;
                            if (brx - tlx < AMSettings.iDynamicMapMinX)
                            {
                                int overage = (AMSettings.iDynamicMapMinX - (brx - tlx)) / 2;
                                float overagePrcnt = ((float)overage * 2f) / (float)(brx - tlx);
                                tlx -= overage;
                                brx += overage;
                                int yOverage = (int)(overagePrcnt * (float)(bry - tly)) / 2;
                                tly -= yOverage;
                                bry += yOverage;

                            }
                        }
                        topLeft = new IntVector2(tlx, tly);
                        bottomRight = new IntVector2(brx, bry);

                        if (AMSettings.bDynamicMapEnabled && (!Globals.zoomedOut || !AMSettings.bDynamicMapHiddenZoomedOut))
                        {
                            lock (Globals.flattener.nextJob)
                            {
                                Globals.flattener.nextJob = new MapFlattener.JobSpec();
                                Globals.flattener.nextJob.topLeft = topLeft.Copy();
                                Globals.flattener.nextJob.bottomRight = bottomRight.Copy();
                                Globals.flattener.nextJob.player = vPlayerLoc.Copy();
                                Globals.flattener.newData = true;
                            }
                            Globals.flattener.trigger.Set();
                        }
                        lastRedraw = DateTime.Now;
                        vLastPlayerLoc = vPlayerLoc;
                        Globals.vLastPlayerLoc = vLastPlayerLoc;
                    }
                }

            }
        }

        //RenderTarget2D renderTarget;
        //bool scenecached = false;
        public void Draw(GameTime gameTime)
        {
            Matrix m = CreateMatrix();
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, DepthStencilState.Default, RasterizerState.CullCounterClockwise, null, m);
            tilebuffer tbuffer = Globals.flattener.frontBuffer;

            if (worldMap != null)
            {
                // world map mode
                DrawWorldMap();
            }
            // live mode
            if (tbuffer.buffer != null && AMSettings.bDynamicMapEnabled && (!Globals.zoomedOut || !AMSettings.bDynamicMapHiddenZoomedOut) && !Globals.loadingWorld && DateTime.Now >= canUpdateBlocks && Globals.bCanUpdateBlocks)
            {
                //if (!scenecached)
                //{
                //    gd.SetRenderTarget(renderTarget);
                //    DrawRealtimeScene(tbuffer);
                //    gd.SetRenderTarget(null);
                //    scenecached = true;
                //}
                //DrawBufferedScene(renderTarget);
                DrawRealtimeScene(tbuffer);
            }
            float scale = (Globals.camZoom < 1 ? (1f / Globals.camZoom) : 1);
            DrawPlayer(arrowPlayer, Globals.userPlayer);
            foreach (DataSource.Player pl in Globals.players.Values)
                if (pl != Globals.userPlayer)
                {
                    DrawPlayer(arrowOtherPlayer, pl);
                    playerLabel.Draw(spriteBatch,
                        pl.name + " (" + pl.iz + ")",
                        (int)pl.pixelx,
                        (int)pl.pixely,
                        scale,
                        AMSettings.bRotate ? (float)Globals.userPlayer.rotation : Globals.DegreeToRadian(AMSettings.iDefaultMapRotation), toolTipFont);
                }
            spriteBatch.End();
        }

        private void DrawBufferedScene(Texture2D renderTarget)
        {
            Matrix m = Matrix.Identity;

            spriteBatch.Draw(renderTarget, new Vector2(0, 0), Color.White);

        }

        private void DrawPlayer(Texture2D texture, DataSource.Player player)
        {
            if (Globals.userPlayer != null)
                spriteBatch.Draw(texture, Globals.getPlayerWorldLocation(player), null, Color.White, (float)player.rotation, Globals.TileOrigin, SpriteEffects.None, 0.0f);

        }

        private void DrawWorldMap()
        {
            if (worldMap == null)
                return;
            float widthDif = (float)worldMap.Width / (float)Globals.worldMapWidth;
            float heightDif = (float)worldMap.Height / (float)Globals.worldMapHeight;
            float widthDifG = (float)Globals.worldMapWidth / (float)worldMap.Width;
            float heightDifG = (float)Globals.worldMapHeight / (float)worldMap.Height;
            float originX = ((float)Globals.worldMapOriginX * widthDif);
            float originY = ((float)Globals.worldMapOriginY * heightDif);

            float bpp = (worldMap.Width > worldMap.Height ? widthDifG : heightDifG);

            int blockOriginX = (int)(originX * bpp);
            int blockOriginY = (int)(originY * bpp);
            spriteBatch.Draw(worldMap, new Rectangle(-(blockOriginX * Globals.TileWidth), -(blockOriginY * Globals.TileHeight), (int)(worldMap.Width * bpp * Globals.TileWidth), (int)(worldMap.Height * bpp * Globals.TileWidth)), Color.White);

        }

        private void DrawRealtimeScene(tilebuffer tbuffer)
        {

            MCTile[,] buffer = tbuffer.buffer;
            IntVector2 locationTopLeft = tbuffer.topLeft;

            for (int x = 0; x < buffer.GetLength(0); x++)
                for (int y = 0; y < buffer.GetLength(1); y++)
                {
                    MCTile theTile = buffer[x, y];

                    while (theTile != null)
                    {
                        if (theTile.solidColor)
                            spriteBatch.Draw(blockBlack, new Rectangle(Globals.BTP(locationTopLeft.X + x), Globals.BTP(locationTopLeft.Y + y), Globals.TileWidth, Globals.TileHeight), theTile.c);
                        else if (theTile.blockType == BlockType.Fire)
                            spriteBatch.Draw(fire, new Rectangle(Globals.BTP(locationTopLeft.X + x), Globals.BTP(locationTopLeft.Y + y), Globals.TileWidth, Globals.TileHeight), theTile.c);
                        else if (!theTile.isItem)
                            spriteBatch.Draw(blockTiles, new Rectangle(Globals.BTP(locationTopLeft.X + x), Globals.BTP(locationTopLeft.Y + y), Globals.TileWidth, Globals.TileHeight), theTile.sourceRect, DetermineColor(theTile));
                        else
                            spriteBatch.Draw(itemTiles, new Rectangle(Globals.BTP(locationTopLeft.X + x), Globals.BTP(locationTopLeft.Y + y), Globals.TileWidth, Globals.TileHeight), theTile.sourceRect, theTile.c);
                        theTile = theTile.nextTile;
                    }
                }
        }

        private Color DetermineColor(MCTile theTile)
        {
            if (theTile.blockType == BlockType.Grass || theTile.blockType == BlockType.Leaves)
                return new Color(theTile.c.R / 3, theTile.c.G, theTile.c.B / 3);
            else
                return theTile.c;
        }

        private static Matrix CreateMatrix()
        {
            Matrix m = Matrix.Identity;

            m = Matrix.Multiply(Matrix.CreateTranslation((Globals.screenWidth / 2), (Globals.screenHeight / 2), 0), m); // center on origin
            m = Matrix.Multiply(Matrix.CreateScale(Globals.camZoom), m); // zoom

            if (!Globals.lockToPlayer)
            {
                m = Matrix.Multiply(Matrix.CreateTranslation(-Globals.panX, -Globals.panY, 0), m); // pan
            }

            if (AMSettings.bRotate && Globals.userPlayer != null)
                m = Matrix.Multiply(Matrix.CreateRotationZ((float)-Globals.userPlayer.rotation), m); //rotate
            else
                m = Matrix.Multiply(Matrix.CreateRotationZ((float)0.00065 + Globals.DegreeToRadian(AMSettings.iDefaultMapRotation)), m);

            m = Matrix.Multiply(Matrix.CreateTranslation(-((Globals.screenWidth / 2)), -((Globals.screenHeight / 2)), 0), m); // uncenter on origin
            m = Matrix.Multiply(Matrix.CreateTranslation(Globals.screenWidth / 2 - Globals.camX, Globals.screenHeight / 2 - Globals.camY, 0), m); // move to camera
            return m;
        }


    }
}
