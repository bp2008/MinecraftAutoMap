﻿// Some of this code and the MTS library was created for Minecraft Topographical Survey 
// by the Minecraft Topographical Survey team and released under the Microsoft Public License.
//
// This code has been modified by the MinecraftAM team.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using MTS;
using System.Windows.Media.Imaging;
using System.Windows.Forms;
using System.IO;

namespace MinecraftAM
{
    public class FullMapRender
    {
        WorldRenderer main;
        BackgroundWorker renderWorker;
        DateTime startTime;
        bool failed = false;

        public void Render()
        {
            pass = 1;
            nonZeroProgressReached = false;
            Globals.renderProgress = 0;
            main = new WorldRenderer();
            renderWorker = new BackgroundWorker();
            renderWorker.WorkerSupportsCancellation = false;
            renderWorker.WorkerReportsProgress = true;
            renderWorker.DoWork += new DoWorkEventHandler(RendererWork);
            renderWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(RendererComplete);
            renderWorker.ProgressChanged += new ProgressChangedEventHandler(RendererProgress);
            try
            {
                renderWorker.RunWorkerAsync(new RenderSettings { LightingLevel = 7, TileType = ImageType.TERRAIN, WorldPath = Globals.worldPath });
            }
            catch (Exception err)
            {
                MessageBox.Show("Render failed for " + Globals.worldName + ": " + err.Message);
            }
            //RenderInfo.Visibility = Visibility.Visible;
        }


        private void RendererWork(object sender, DoWorkEventArgs e)
        {
            Globals.rendering = true;
            this.startTime = DateTime.Now;
            BackgroundWorker worker = sender as BackgroundWorker;

            MTS.RenderSettings RS = new MTS.RenderSettings();
            RS.WorldPath = Globals.worldPath;
            RS.TileType = ImageType.TERRAIN;
            RS.LightingLevel = 7;
            RS.SpectralBlock = 0;

            try
            {
                e.Result = main.renderWorld(RS, worker);
            }
            catch (Exception err)
            {
                failed = true;
                if (MessageBox.Show("The render failed (" + err.Message + ").  It might help to delete the cache and try again.  Delete the cache?", "Render Failed", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    DeleteCache(Globals.worldName);
                Globals.rendering = false;
            }
        }

        private void DeleteCache(string p)
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string mtsCacheFolder = Path.Combine(appData, "mts\\ChunkCache");
            if (Directory.Exists(mtsCacheFolder))
                Directory.Delete(mtsCacheFolder, true);
        }

        public int pass = 1;
        bool nonZeroProgressReached = false;
        public string origin = "";
        private void RendererProgress(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage == 200)
            {
                origin = (string)e.UserState;
                return;
            }
            if (e.ProgressPercentage > 0)
                nonZeroProgressReached = true;
            if (nonZeroProgressReached && e.ProgressPercentage == 0)
                pass = 2;
            Globals.renderProgress = e.ProgressPercentage;
            
            //this.RenderInfoText.Text = String.Format(ProgressTextFormat, e.UserState.ToString() +
            //    (e.ProgressPercentage > 0
            //        ? " - " + e.ProgressPercentage + "%"
            //        : ""));
        }

        private void RendererComplete(object sender, RunWorkerCompletedEventArgs e)
        {
            //RenderInfo.Visibility = Visibility.Collapsed;
            //RenderInfoText.Text = "Looking for world data...";

            //ToggleMenu(true);

            if (e.Error != null)
            {
                MessageBox.Show("Rendering failed: " + e.Error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (e.Cancelled)
            {
                MessageBox.Show("Rendering was aborted.", "Render incomplete", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                lock (this)
                {
                    if (failed)
                        return;
                    BitmapSource output = (BitmapSource)e.Result;
                    FileStream outFile = new FileStream(Globals.worldName + ".png", FileMode.Create, FileAccess.Write);
                    PngBitmapEncoder encoder = new PngBitmapEncoder();
                    
                    encoder.Frames.Add(BitmapFrame.Create(output));
                    encoder.Save(outFile);

                    outFile.Close();
                    File.WriteAllText(Globals.worldName + "origin.txt", origin + "\r" + output.Width + "x" + output.Height);
                    Globals.rendering = false;

                }
                TimeSpan elapsed = DateTime.Now - startTime;
                //this.UpdateRenderedImage(output);
                //this.Title = String.Format(TitleTextFormatRendered, String.Format("Rendered in {0:00}:{1:00}", Math.Floor(elapsed.TotalMinutes), elapsed.Seconds));
            }
        }
    }
}
