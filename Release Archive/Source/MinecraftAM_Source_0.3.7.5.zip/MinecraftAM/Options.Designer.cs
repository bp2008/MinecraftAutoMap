﻿namespace MinecraftAM
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Options));
            this.label2 = new System.Windows.Forms.Label();
            this.nudProcessPriority = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.cbLava = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtGlowingPath = new System.Windows.Forms.TextBox();
            this.cbGlowingPath = new System.Windows.Forms.CheckBox();
            this.txtShowCompass = new System.Windows.Forms.TextBox();
            this.cbShowCompass = new System.Windows.Forms.CheckBox();
            this.txtRotate = new System.Windows.Forms.TextBox();
            this.cbRotate = new System.Windows.Forms.CheckBox();
            this.txtShowRealtimeMap = new System.Windows.Forms.TextBox();
            this.cbShowRealtimeMap = new System.Windows.Forms.CheckBox();
            this.txtHotkeys = new System.Windows.Forms.TextBox();
            this.cbHotkeys = new System.Windows.Forms.CheckBox();
            this.txtStatusText = new System.Windows.Forms.TextBox();
            this.cbStatusText = new System.Windows.Forms.CheckBox();
            this.txtOre = new System.Windows.Forms.TextBox();
            this.txtWater = new System.Windows.Forms.TextBox();
            this.cbWater = new System.Windows.Forms.CheckBox();
            this.txtLava = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbOreDetection = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.nudDynamicMapMaxWidth = new System.Windows.Forms.NumericUpDown();
            this.btnDone = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.nudDynamicMapMinWidth = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.txtShowOptions = new System.Windows.Forms.TextBox();
            this.labelwhatever = new System.Windows.Forms.Label();
            this.nudIDD = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.nudODD = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.nudOCH = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCD = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCR = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtStick = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.nudGlowingIntensity = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.txtUpdateStaticTerrain = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cbHideMapZoomed = new System.Windows.Forms.CheckBox();
            this.txtClearGlowingPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label23 = new System.Windows.Forms.Label();
            this.nudMapX = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.nudMapY = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCBG = new System.Windows.Forms.TextBox();
            this.txtCGC = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.nudMapWidth = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.nudMapHeight = new System.Windows.Forms.NumericUpDown();
            this.txtMultiplayerMap = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.btnBrowseForMap = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.txtResetRealtimeMap = new System.Windows.Forms.TextBox();
            this.openFileDialogSMPMap = new System.Windows.Forms.OpenFileDialog();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.nudDegMapRot = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nudProcessPriority)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDynamicMapMaxWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDynamicMapMinWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudIDD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudODD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGlowingIntensity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapHeight)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDegMapRot)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Process Priority (0, 1, 2)";
            // 
            // nudProcessPriority
            // 
            this.nudProcessPriority.Location = new System.Drawing.Point(144, 12);
            this.nudProcessPriority.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudProcessPriority.Name = "nudProcessPriority";
            this.nudProcessPriority.Size = new System.Drawing.Size(76, 20);
            this.nudProcessPriority.TabIndex = 1;
            this.nudProcessPriority.ValueChanged += new System.EventHandler(this.nudProcessPriority_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(191, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "0 = Low, 1 = Below Normal, 2 = Normal";
            // 
            // cbLava
            // 
            this.cbLava.AutoSize = true;
            this.cbLava.Location = new System.Drawing.Point(15, 39);
            this.cbLava.Name = "cbLava";
            this.cbLava.Size = new System.Drawing.Size(50, 17);
            this.cbLava.TabIndex = 6;
            this.cbLava.Text = "Lava";
            this.cbLava.UseVisualStyleBackColor = true;
            this.cbLava.CheckedChanged += new System.EventHandler(this.cbLava_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtGlowingPath);
            this.groupBox1.Controls.Add(this.cbGlowingPath);
            this.groupBox1.Controls.Add(this.txtShowCompass);
            this.groupBox1.Controls.Add(this.cbShowCompass);
            this.groupBox1.Controls.Add(this.txtRotate);
            this.groupBox1.Controls.Add(this.cbRotate);
            this.groupBox1.Controls.Add(this.txtShowRealtimeMap);
            this.groupBox1.Controls.Add(this.cbShowRealtimeMap);
            this.groupBox1.Controls.Add(this.txtHotkeys);
            this.groupBox1.Controls.Add(this.cbHotkeys);
            this.groupBox1.Controls.Add(this.txtStatusText);
            this.groupBox1.Controls.Add(this.cbStatusText);
            this.groupBox1.Controls.Add(this.txtOre);
            this.groupBox1.Controls.Add(this.txtWater);
            this.groupBox1.Controls.Add(this.cbWater);
            this.groupBox1.Controls.Add(this.txtLava);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbLava);
            this.groupBox1.Controls.Add(this.cbOreDetection);
            this.groupBox1.Location = new System.Drawing.Point(12, 140);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(208, 277);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quick Toggles";
            // 
            // txtGlowingPath
            // 
            this.txtGlowingPath.Location = new System.Drawing.Point(153, 245);
            this.txtGlowingPath.MaxLength = 1;
            this.txtGlowingPath.Name = "txtGlowingPath";
            this.txtGlowingPath.Size = new System.Drawing.Size(39, 20);
            this.txtGlowingPath.TabIndex = 23;
            this.txtGlowingPath.TextChanged += new System.EventHandler(this.txtGlowingPath_TextChanged);
            // 
            // cbGlowingPath
            // 
            this.cbGlowingPath.AutoSize = true;
            this.cbGlowingPath.Location = new System.Drawing.Point(15, 247);
            this.cbGlowingPath.Name = "cbGlowingPath";
            this.cbGlowingPath.Size = new System.Drawing.Size(125, 17);
            this.cbGlowingPath.TabIndex = 22;
            this.cbGlowingPath.Text = "Toggle Glowing Path";
            this.toolTip1.SetToolTip(this.cbGlowingPath, "Colors the blocks you have walked on red so you can backtrack.");
            this.cbGlowingPath.UseVisualStyleBackColor = true;
            this.cbGlowingPath.CheckedChanged += new System.EventHandler(this.cbGlowingPath_CheckedChanged);
            // 
            // txtShowCompass
            // 
            this.txtShowCompass.Location = new System.Drawing.Point(153, 219);
            this.txtShowCompass.MaxLength = 1;
            this.txtShowCompass.Name = "txtShowCompass";
            this.txtShowCompass.Size = new System.Drawing.Size(39, 20);
            this.txtShowCompass.TabIndex = 21;
            this.txtShowCompass.TextChanged += new System.EventHandler(this.txtShowCompass_TextChanged);
            // 
            // cbShowCompass
            // 
            this.cbShowCompass.AutoSize = true;
            this.cbShowCompass.Location = new System.Drawing.Point(15, 221);
            this.cbShowCompass.Name = "cbShowCompass";
            this.cbShowCompass.Size = new System.Drawing.Size(99, 17);
            this.cbShowCompass.TabIndex = 20;
            this.cbShowCompass.Text = "Show Compass";
            this.cbShowCompass.UseVisualStyleBackColor = true;
            this.cbShowCompass.CheckedChanged += new System.EventHandler(this.cbShowCompass_CheckedChanged);
            // 
            // txtRotate
            // 
            this.txtRotate.Location = new System.Drawing.Point(153, 193);
            this.txtRotate.MaxLength = 1;
            this.txtRotate.Name = "txtRotate";
            this.txtRotate.Size = new System.Drawing.Size(39, 20);
            this.txtRotate.TabIndex = 19;
            this.txtRotate.TextChanged += new System.EventHandler(this.txtRotate_TextChanged);
            // 
            // cbRotate
            // 
            this.cbRotate.AutoSize = true;
            this.cbRotate.Location = new System.Drawing.Point(15, 195);
            this.cbRotate.Name = "cbRotate";
            this.cbRotate.Size = new System.Drawing.Size(112, 17);
            this.cbRotate.TabIndex = 18;
            this.cbRotate.Text = "Rotate with Player";
            this.cbRotate.UseVisualStyleBackColor = true;
            this.cbRotate.CheckedChanged += new System.EventHandler(this.cbRotate_CheckedChanged);
            // 
            // txtShowRealtimeMap
            // 
            this.txtShowRealtimeMap.Location = new System.Drawing.Point(153, 167);
            this.txtShowRealtimeMap.MaxLength = 1;
            this.txtShowRealtimeMap.Name = "txtShowRealtimeMap";
            this.txtShowRealtimeMap.Size = new System.Drawing.Size(39, 20);
            this.txtShowRealtimeMap.TabIndex = 17;
            this.txtShowRealtimeMap.TextChanged += new System.EventHandler(this.txtShowRealtimeMap_TextChanged);
            // 
            // cbShowRealtimeMap
            // 
            this.cbShowRealtimeMap.AutoSize = true;
            this.cbShowRealtimeMap.Location = new System.Drawing.Point(15, 169);
            this.cbShowRealtimeMap.Name = "cbShowRealtimeMap";
            this.cbShowRealtimeMap.Size = new System.Drawing.Size(121, 17);
            this.cbShowRealtimeMap.TabIndex = 16;
            this.cbShowRealtimeMap.Text = "Show Realtime Map";
            this.cbShowRealtimeMap.UseVisualStyleBackColor = true;
            this.cbShowRealtimeMap.CheckedChanged += new System.EventHandler(this.cbShowRealtimeMap_CheckedChanged);
            // 
            // txtHotkeys
            // 
            this.txtHotkeys.Location = new System.Drawing.Point(153, 141);
            this.txtHotkeys.MaxLength = 1;
            this.txtHotkeys.Name = "txtHotkeys";
            this.txtHotkeys.Size = new System.Drawing.Size(39, 20);
            this.txtHotkeys.TabIndex = 15;
            this.txtHotkeys.TextChanged += new System.EventHandler(this.txtHotkeys_TextChanged);
            // 
            // cbHotkeys
            // 
            this.cbHotkeys.AutoSize = true;
            this.cbHotkeys.Location = new System.Drawing.Point(15, 143);
            this.cbHotkeys.Name = "cbHotkeys";
            this.cbHotkeys.Size = new System.Drawing.Size(95, 17);
            this.cbHotkeys.TabIndex = 14;
            this.cbHotkeys.Text = "Show Hotkeys";
            this.cbHotkeys.UseVisualStyleBackColor = true;
            this.cbHotkeys.CheckedChanged += new System.EventHandler(this.cbHotkeys_CheckedChanged);
            // 
            // txtStatusText
            // 
            this.txtStatusText.Location = new System.Drawing.Point(153, 115);
            this.txtStatusText.MaxLength = 1;
            this.txtStatusText.Name = "txtStatusText";
            this.txtStatusText.Size = new System.Drawing.Size(39, 20);
            this.txtStatusText.TabIndex = 13;
            this.txtStatusText.TextChanged += new System.EventHandler(this.txtStatusText_TextChanged);
            // 
            // cbStatusText
            // 
            this.cbStatusText.AutoSize = true;
            this.cbStatusText.Location = new System.Drawing.Point(15, 117);
            this.cbStatusText.Name = "cbStatusText";
            this.cbStatusText.Size = new System.Drawing.Size(110, 17);
            this.cbStatusText.TabIndex = 12;
            this.cbStatusText.Text = "Show Status Text";
            this.cbStatusText.UseVisualStyleBackColor = true;
            this.cbStatusText.CheckedChanged += new System.EventHandler(this.cbStatusText_CheckedChanged);
            // 
            // txtOre
            // 
            this.txtOre.Location = new System.Drawing.Point(153, 89);
            this.txtOre.MaxLength = 1;
            this.txtOre.Name = "txtOre";
            this.txtOre.Size = new System.Drawing.Size(39, 20);
            this.txtOre.TabIndex = 11;
            this.txtOre.TextChanged += new System.EventHandler(this.txtOre_TextChanged);
            // 
            // txtWater
            // 
            this.txtWater.Location = new System.Drawing.Point(153, 63);
            this.txtWater.MaxLength = 1;
            this.txtWater.Name = "txtWater";
            this.txtWater.Size = new System.Drawing.Size(39, 20);
            this.txtWater.TabIndex = 9;
            this.txtWater.TextChanged += new System.EventHandler(this.txtWater_TextChanged);
            // 
            // cbWater
            // 
            this.cbWater.AutoSize = true;
            this.cbWater.Location = new System.Drawing.Point(15, 65);
            this.cbWater.Name = "cbWater";
            this.cbWater.Size = new System.Drawing.Size(55, 17);
            this.cbWater.TabIndex = 8;
            this.cbWater.Text = "Water";
            this.cbWater.UseVisualStyleBackColor = true;
            this.cbWater.CheckedChanged += new System.EventHandler(this.cbWater_CheckedChanged);
            // 
            // txtLava
            // 
            this.txtLava.Location = new System.Drawing.Point(153, 37);
            this.txtLava.MaxLength = 1;
            this.txtLava.Name = "txtLava";
            this.txtLava.Size = new System.Drawing.Size(39, 20);
            this.txtLava.TabIndex = 7;
            this.txtLava.TextChanged += new System.EventHandler(this.txtLava_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(150, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Hotkey";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Currently Active";
            // 
            // cbOreDetection
            // 
            this.cbOreDetection.AutoSize = true;
            this.cbOreDetection.Location = new System.Drawing.Point(15, 91);
            this.cbOreDetection.Name = "cbOreDetection";
            this.cbOreDetection.Size = new System.Drawing.Size(135, 17);
            this.cbOreDetection.TabIndex = 10;
            this.cbOreDetection.Text = "Mineral (Ore) Detection";
            this.cbOreDetection.UseVisualStyleBackColor = true;
            this.cbOreDetection.CheckedChanged += new System.EventHandler(this.cbOreDetection_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Realtime Map Max Width";
            this.toolTip1.SetToolTip(this.label6, "Limit the size of the realtime map, in blocks.");
            // 
            // nudDynamicMapMaxWidth
            // 
            this.nudDynamicMapMaxWidth.Location = new System.Drawing.Point(144, 60);
            this.nudDynamicMapMaxWidth.Maximum = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.nudDynamicMapMaxWidth.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nudDynamicMapMaxWidth.Name = "nudDynamicMapMaxWidth";
            this.nudDynamicMapMaxWidth.Size = new System.Drawing.Size(76, 20);
            this.nudDynamicMapMaxWidth.TabIndex = 2;
            this.toolTip1.SetToolTip(this.nudDynamicMapMaxWidth, "Limit the size of the realtime map, in blocks.");
            this.nudDynamicMapMaxWidth.Value = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.nudDynamicMapMaxWidth.ValueChanged += new System.EventHandler(this.nudDynamicMapMaxWidth_ValueChanged);
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(597, 395);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 11;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Realtime Map Min Width";
            this.toolTip1.SetToolTip(this.label9, "Limit the size of the realtime map, in blocks.");
            // 
            // nudDynamicMapMinWidth
            // 
            this.nudDynamicMapMinWidth.Location = new System.Drawing.Point(144, 86);
            this.nudDynamicMapMinWidth.Maximum = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.nudDynamicMapMinWidth.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nudDynamicMapMinWidth.Name = "nudDynamicMapMinWidth";
            this.nudDynamicMapMinWidth.Size = new System.Drawing.Size(76, 20);
            this.nudDynamicMapMinWidth.TabIndex = 4;
            this.toolTip1.SetToolTip(this.nudDynamicMapMinWidth, "Limit the size of the realtime map, in blocks.");
            this.nudDynamicMapMinWidth.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nudDynamicMapMinWidth.ValueChanged += new System.EventHandler(this.nudDynamicMapMinWidth_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(243, 197);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Show Options Window";
            // 
            // txtShowOptions
            // 
            this.txtShowOptions.Location = new System.Drawing.Point(391, 194);
            this.txtShowOptions.MaxLength = 1;
            this.txtShowOptions.Name = "txtShowOptions";
            this.txtShowOptions.Size = new System.Drawing.Size(39, 20);
            this.txtShowOptions.TabIndex = 34;
            this.txtShowOptions.TextChanged += new System.EventHandler(this.txtShowOptions_TextChanged);
            // 
            // labelwhatever
            // 
            this.labelwhatever.AutoSize = true;
            this.labelwhatever.Location = new System.Drawing.Point(13, 48);
            this.labelwhatever.Name = "labelwhatever";
            this.labelwhatever.Size = new System.Drawing.Size(97, 13);
            this.labelwhatever.TabIndex = 22;
            this.labelwhatever.Text = "Indoor Draw Depth";
            this.toolTip1.SetToolTip(this.labelwhatever, "How many blocks deep the realtime map shows when a ceiling is found between your " +
                    "head and 10 blocks above your head.");
            // 
            // nudIDD
            // 
            this.nudIDD.Location = new System.Drawing.Point(134, 46);
            this.nudIDD.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudIDD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudIDD.Name = "nudIDD";
            this.nudIDD.Size = new System.Drawing.Size(76, 20);
            this.nudIDD.TabIndex = 31;
            this.toolTip1.SetToolTip(this.nudIDD, "How many blocks deep the realtime map shows when a ceiling is found between your " +
                    "head and 10 blocks above your head.");
            this.nudIDD.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudIDD.ValueChanged += new System.EventHandler(this.nudIDD_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 76);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "Outdoor Draw Depth";
            this.toolTip1.SetToolTip(this.label13, "How many blocks deep the realtime map shows when NO ceiling is found between your" +
                    " head and [Max Height]");
            // 
            // nudODD
            // 
            this.nudODD.Location = new System.Drawing.Point(134, 74);
            this.nudODD.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudODD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudODD.Name = "nudODD";
            this.nudODD.Size = new System.Drawing.Size(76, 20);
            this.nudODD.TabIndex = 33;
            this.toolTip1.SetToolTip(this.nudODD, "How many blocks deep the realtime map shows when NO ceiling is found between your" +
                    " head and [Max Height]");
            this.nudODD.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudODD.ValueChanged += new System.EventHandler(this.nudODD_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Virtual Ceiling";
            this.toolTip1.SetToolTip(this.label14, "How far above the player\'s head to place the virtual ceiling, unless theres a rea" +
                    "l ceiling closer.");
            // 
            // nudOCH
            // 
            this.nudOCH.Location = new System.Drawing.Point(134, 20);
            this.nudOCH.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudOCH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudOCH.Name = "nudOCH";
            this.nudOCH.Size = new System.Drawing.Size(76, 20);
            this.nudOCH.TabIndex = 32;
            this.toolTip1.SetToolTip(this.nudOCH, "How far above the player\'s head to place the virtual ceiling, unless theres a rea" +
                    "l ceiling closer.");
            this.nudOCH.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudOCH.ValueChanged += new System.EventHandler(this.nudOCH_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(320, 177);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Hotkeys";
            // 
            // txtCI
            // 
            this.txtCI.Location = new System.Drawing.Point(391, 220);
            this.txtCI.MaxLength = 1;
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(39, 20);
            this.txtCI.TabIndex = 35;
            this.txtCI.TextChanged += new System.EventHandler(this.txtCI_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label15.Location = new System.Drawing.Point(243, 223);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 13);
            this.label15.TabIndex = 27;
            this.label15.Text = "Increase Camera Height";
            // 
            // txtCD
            // 
            this.txtCD.Location = new System.Drawing.Point(391, 246);
            this.txtCD.MaxLength = 1;
            this.txtCD.Name = "txtCD";
            this.txtCD.Size = new System.Drawing.Size(39, 20);
            this.txtCD.TabIndex = 36;
            this.txtCD.TextChanged += new System.EventHandler(this.txtCD_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(243, 249);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 13);
            this.label16.TabIndex = 29;
            this.label16.Text = "Decrease Camera Height";
            // 
            // txtCR
            // 
            this.txtCR.Location = new System.Drawing.Point(391, 272);
            this.txtCR.MaxLength = 1;
            this.txtCR.Name = "txtCR";
            this.txtCR.Size = new System.Drawing.Size(39, 20);
            this.txtCR.TabIndex = 37;
            this.txtCR.TextChanged += new System.EventHandler(this.txtCR_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(243, 275);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(108, 13);
            this.label17.TabIndex = 31;
            this.label17.Text = "Reset Camera Height";
            // 
            // txtStick
            // 
            this.txtStick.Location = new System.Drawing.Point(391, 298);
            this.txtStick.MaxLength = 1;
            this.txtStick.Name = "txtStick";
            this.txtStick.Size = new System.Drawing.Size(39, 20);
            this.txtStick.TabIndex = 38;
            this.toolTip1.SetToolTip(this.txtStick, "For use after you have moved the map using the arrow keys");
            this.txtStick.TextChanged += new System.EventHandler(this.txtStick_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(243, 301);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(114, 13);
            this.label18.TabIndex = 33;
            this.label18.Text = "Stick to Player (Follow)";
            this.toolTip1.SetToolTip(this.label18, "For use after you have moved the map using the arrow keys");
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(239, 14);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(112, 13);
            this.label19.TabIndex = 39;
            this.label19.Text = "Glowing Path Intensity";
            // 
            // nudGlowingIntensity
            // 
            this.nudGlowingIntensity.Location = new System.Drawing.Point(368, 12);
            this.nudGlowingIntensity.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudGlowingIntensity.Name = "nudGlowingIntensity";
            this.nudGlowingIntensity.Size = new System.Drawing.Size(76, 20);
            this.nudGlowingIntensity.TabIndex = 29;
            this.toolTip1.SetToolTip(this.nudGlowingIntensity, "Amount of red color added to visited squares if Toggle Glowing Path is on.");
            this.nudGlowingIntensity.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.nudGlowingIntensity.ValueChanged += new System.EventHandler(this.nudGlowingIntensity_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(257, 35);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(163, 13);
            this.label20.TabIndex = 41;
            this.label20.Text = "Intensity of red glow color (0-255)";
            // 
            // txtUpdateStaticTerrain
            // 
            this.txtUpdateStaticTerrain.Location = new System.Drawing.Point(391, 324);
            this.txtUpdateStaticTerrain.MaxLength = 1;
            this.txtUpdateStaticTerrain.Name = "txtUpdateStaticTerrain";
            this.txtUpdateStaticTerrain.Size = new System.Drawing.Size(39, 20);
            this.txtUpdateStaticTerrain.TabIndex = 43;
            this.txtUpdateStaticTerrain.TextChanged += new System.EventHandler(this.txtUpdateStaticTerrain_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(243, 327);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(108, 13);
            this.label21.TabIndex = 42;
            this.label21.Text = "Update Static Terrain";
            // 
            // cbHideMapZoomed
            // 
            this.cbHideMapZoomed.AutoSize = true;
            this.cbHideMapZoomed.Checked = true;
            this.cbHideMapZoomed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbHideMapZoomed.Location = new System.Drawing.Point(10, 113);
            this.cbHideMapZoomed.Name = "cbHideMapZoomed";
            this.cbHideMapZoomed.Size = new System.Drawing.Size(210, 17);
            this.cbHideMapZoomed.TabIndex = 44;
            this.cbHideMapZoomed.Text = "Hide Realtime Map When Zoomed Out";
            this.cbHideMapZoomed.UseVisualStyleBackColor = true;
            this.cbHideMapZoomed.CheckedChanged += new System.EventHandler(this.cbHideMapZoomed_CheckedChanged);
            // 
            // txtClearGlowingPath
            // 
            this.txtClearGlowingPath.Location = new System.Drawing.Point(391, 350);
            this.txtClearGlowingPath.MaxLength = 1;
            this.txtClearGlowingPath.Name = "txtClearGlowingPath";
            this.txtClearGlowingPath.Size = new System.Drawing.Size(39, 20);
            this.txtClearGlowingPath.TabIndex = 25;
            this.txtClearGlowingPath.TextChanged += new System.EventHandler(this.txtClearGlowingPath_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(243, 353);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Clear Glowing Path";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(455, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 45;
            this.label7.Text = "SMP Map Width";
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 60000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(455, 114);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(95, 13);
            this.label23.TabIndex = 49;
            this.label23.Text = "SMP Map X Offset";
            this.toolTip1.SetToolTip(this.label23, "The location of the 0,0 block in your map file.");
            // 
            // nudMapX
            // 
            this.nudMapX.Location = new System.Drawing.Point(564, 112);
            this.nudMapX.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMapX.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.nudMapX.Name = "nudMapX";
            this.nudMapX.Size = new System.Drawing.Size(108, 20);
            this.nudMapX.TabIndex = 50;
            this.toolTip1.SetToolTip(this.nudMapX, "The location of the 0,0 block in your map file.");
            this.nudMapX.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudMapX.ValueChanged += new System.EventHandler(this.nudMapX_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(455, 140);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 13);
            this.label24.TabIndex = 51;
            this.label24.Text = "SMP Map Y Offset";
            this.toolTip1.SetToolTip(this.label24, "The location of the 0,0 block in your map file.");
            // 
            // nudMapY
            // 
            this.nudMapY.Location = new System.Drawing.Point(564, 138);
            this.nudMapY.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMapY.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.nudMapY.Name = "nudMapY";
            this.nudMapY.Size = new System.Drawing.Size(108, 20);
            this.nudMapY.TabIndex = 52;
            this.toolTip1.SetToolTip(this.nudMapY, "The location of the 0,0 block in your map file.");
            this.nudMapY.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudMapY.ValueChanged += new System.EventHandler(this.nudMapY_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(455, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 13);
            this.label8.TabIndex = 59;
            this.label8.Text = "Background Color";
            this.toolTip1.SetToolTip(this.label8, "The color to draw where there is no map data.  Format: \"R,G,B,A\" where R = Red, G" +
                    " = Green, B = Blue, A = Alpha (Opacity).  Valid values are between 0 and 255 inc" +
                    "lusively.");
            // 
            // txtCBG
            // 
            this.txtCBG.Location = new System.Drawing.Point(571, 173);
            this.txtCBG.Name = "txtCBG";
            this.txtCBG.Size = new System.Drawing.Size(101, 20);
            this.txtCBG.TabIndex = 60;
            this.toolTip1.SetToolTip(this.txtCBG, "The color to draw where there is no map data.  Format: \"R,G,B,A\" where R = Red, G" +
                    " = Green, B = Blue, A = Alpha (Opacity).  Valid values are between 0 and 255 inc" +
                    "lusively.");
            this.txtCBG.TextChanged += new System.EventHandler(this.txtCBG_TextChanged);
            // 
            // txtCGC
            // 
            this.txtCGC.Location = new System.Drawing.Point(571, 199);
            this.txtCGC.Name = "txtCGC";
            this.txtCGC.Size = new System.Drawing.Size(101, 20);
            this.txtCGC.TabIndex = 62;
            this.toolTip1.SetToolTip(this.txtCGC, resources.GetString("txtCGC.ToolTip"));
            this.txtCGC.TextChanged += new System.EventHandler(this.txtCGC_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(455, 202);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 13);
            this.label12.TabIndex = 61;
            this.label12.Text = "Gapless Column Color";
            this.toolTip1.SetToolTip(this.label12, resources.GetString("label12.ToolTip"));
            // 
            // nudMapWidth
            // 
            this.nudMapWidth.Location = new System.Drawing.Point(564, 60);
            this.nudMapWidth.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMapWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMapWidth.Name = "nudMapWidth";
            this.nudMapWidth.Size = new System.Drawing.Size(108, 20);
            this.nudMapWidth.TabIndex = 46;
            this.nudMapWidth.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudMapWidth.ValueChanged += new System.EventHandler(this.nudMapWidth_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(455, 88);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(88, 13);
            this.label22.TabIndex = 47;
            this.label22.Text = "SMP Map Height";
            // 
            // nudMapHeight
            // 
            this.nudMapHeight.Location = new System.Drawing.Point(564, 86);
            this.nudMapHeight.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMapHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMapHeight.Name = "nudMapHeight";
            this.nudMapHeight.Size = new System.Drawing.Size(108, 20);
            this.nudMapHeight.TabIndex = 48;
            this.nudMapHeight.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.nudMapHeight.ValueChanged += new System.EventHandler(this.nudMapHeight_ValueChanged);
            // 
            // txtMultiplayerMap
            // 
            this.txtMultiplayerMap.Location = new System.Drawing.Point(458, 32);
            this.txtMultiplayerMap.Name = "txtMultiplayerMap";
            this.txtMultiplayerMap.Size = new System.Drawing.Size(214, 20);
            this.txtMultiplayerMap.TabIndex = 53;
            this.txtMultiplayerMap.TextChanged += new System.EventHandler(this.txtMultiplayerMap_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(455, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(116, 13);
            this.label25.TabIndex = 54;
            this.label25.Text = "Map file to use in SMP:";
            // 
            // btnBrowseForMap
            // 
            this.btnBrowseForMap.Location = new System.Drawing.Point(597, 4);
            this.btnBrowseForMap.Name = "btnBrowseForMap";
            this.btnBrowseForMap.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseForMap.TabIndex = 55;
            this.btnBrowseForMap.Text = "Browse";
            this.btnBrowseForMap.UseVisualStyleBackColor = true;
            this.btnBrowseForMap.Click += new System.EventHandler(this.btnBrowseForMap_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(243, 379);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 13);
            this.label26.TabIndex = 57;
            this.label26.Text = "Reset Realtime Map";
            // 
            // txtResetRealtimeMap
            // 
            this.txtResetRealtimeMap.Location = new System.Drawing.Point(391, 376);
            this.txtResetRealtimeMap.MaxLength = 1;
            this.txtResetRealtimeMap.Name = "txtResetRealtimeMap";
            this.txtResetRealtimeMap.Size = new System.Drawing.Size(39, 20);
            this.txtResetRealtimeMap.TabIndex = 56;
            this.txtResetRealtimeMap.TextChanged += new System.EventHandler(this.txtResetRealtimeMap_TextChanged);
            // 
            // openFileDialogSMPMap
            // 
            this.openFileDialogSMPMap.FileName = "openFileDialog1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nudODD);
            this.groupBox2.Controls.Add(this.nudIDD);
            this.groupBox2.Controls.Add(this.labelwhatever);
            this.groupBox2.Controls.Add(this.nudOCH);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(228, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(216, 100);
            this.groupBox2.TabIndex = 58;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Live Map Tweaks";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(455, 227);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(114, 13);
            this.label27.TabIndex = 63;
            this.label27.Text = "Map Rotation Degrees";
            this.toolTip1.SetToolTip(this.label27, resources.GetString("label27.ToolTip"));
            // 
            // nudDegMapRot
            // 
            this.nudDegMapRot.Location = new System.Drawing.Point(585, 225);
            this.nudDegMapRot.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudDegMapRot.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudDegMapRot.Name = "nudDegMapRot";
            this.nudDegMapRot.Size = new System.Drawing.Size(87, 20);
            this.nudDegMapRot.TabIndex = 64;
            this.nudDegMapRot.ValueChanged += new System.EventHandler(this.nudDegMapRot_ValueChanged);
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 430);
            this.Controls.Add(this.nudDegMapRot);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.txtCGC);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtCBG);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txtResetRealtimeMap);
            this.Controls.Add(this.btnBrowseForMap);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtMultiplayerMap);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.nudMapY);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.nudMapX);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.nudMapHeight);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.nudMapWidth);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbHideMapZoomed);
            this.Controls.Add(this.txtClearGlowingPath);
            this.Controls.Add(this.txtUpdateStaticTerrain);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.nudGlowingIntensity);
            this.Controls.Add(this.txtStick);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtCR);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtCD);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtCI);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtShowOptions);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.nudDynamicMapMinWidth);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nudDynamicMapMaxWidth);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nudProcessPriority);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Options";
            this.Text = "Options";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Options_FormClosed);
            this.Load += new System.EventHandler(this.Options_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudProcessPriority)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDynamicMapMaxWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDynamicMapMinWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudIDD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudODD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGlowingIntensity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMapHeight)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDegMapRot)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudProcessPriority;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbLava;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtLava;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtShowRealtimeMap;
        private System.Windows.Forms.CheckBox cbShowRealtimeMap;
        private System.Windows.Forms.TextBox txtHotkeys;
        private System.Windows.Forms.CheckBox cbHotkeys;
        private System.Windows.Forms.TextBox txtStatusText;
        private System.Windows.Forms.CheckBox cbStatusText;
        private System.Windows.Forms.TextBox txtOre;
        private System.Windows.Forms.CheckBox cbOreDetection;
        private System.Windows.Forms.TextBox txtWater;
        private System.Windows.Forms.CheckBox cbWater;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nudDynamicMapMaxWidth;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nudDynamicMapMinWidth;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtShowOptions;
        private System.Windows.Forms.TextBox txtShowCompass;
        private System.Windows.Forms.CheckBox cbShowCompass;
        private System.Windows.Forms.TextBox txtRotate;
        private System.Windows.Forms.CheckBox cbRotate;
        private System.Windows.Forms.Label labelwhatever;
        private System.Windows.Forms.NumericUpDown nudIDD;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nudODD;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown nudOCH;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCI;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtCD;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCR;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtStick;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtGlowingPath;
        private System.Windows.Forms.CheckBox cbGlowingPath;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown nudGlowingIntensity;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtUpdateStaticTerrain;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox cbHideMapZoomed;
        private System.Windows.Forms.TextBox txtClearGlowingPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudMapWidth;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown nudMapHeight;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown nudMapX;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown nudMapY;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox txtMultiplayerMap;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnBrowseForMap;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtResetRealtimeMap;
        private System.Windows.Forms.OpenFileDialog openFileDialogSMPMap;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCBG;
        private System.Windows.Forms.TextBox txtCGC;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown nudDegMapRot;
    }
}