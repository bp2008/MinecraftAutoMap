﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.ComponentModel;
using System.Threading.Tasks;
using System.IO.Compression;

namespace MTS
{
    public class ChunkCache
    {
        private String cachedir;
        private long worldWidth;
        private long worldHeight;
        private long worldYOffset;
        private long worldXOffset;
        private int size;

        public String CacheDir
        {
            get
            {
                if (cachedir == null)
                {
                    cachedir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "mts");
                }
                return cachedir;
            }
            set
            {
                cachedir = value;
            }
        }
        public long WorldWidth
        {
            get
            {
                return worldWidth;
            }
        }

        public long WorldHeight
        {
            get
            {
                return worldHeight;
            }
        }

        public long WorldXOffset
        {
            get
            {
                return worldXOffset;
            }
        }

        public long WorldYOffset
        {
            get
            {
                return worldYOffset;
            }
        }

        public int Size
        {
            get
            {
                return size;
            }
        }

        public ChunkCache()
        {
            
        }
        
        public static int worldXBound = 20000;
        public static int worldYBound = 20000;
        public List<TileImage> getCache(RenderSettings settings, BackgroundWorker worker)
        {
            //Second parameter controls HELL
            List<String> chunkFiles = this.getFolder(settings.WorldPath, settings.Hell);
            List<LevelChunk> chunks = new List<LevelChunk>();
            List<TileImage> tiles = new List<TileImage>();
            List<TileImage> freshChunks = new List<TileImage>();

            string CachePath = Path.Combine(CacheDir, "ChunkCache", settings.ToString() + ".dat");
            Console.WriteLine("Using cache file \"{0}\".", CachePath);

            FileInfo serialisedFileInfo = new FileInfo(CachePath);
            IFormatter formatter = new BinaryFormatter();

            if (serialisedFileInfo.Exists)
            {
                try
                {
                    using (Stream stream = serialisedFileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        using (GZipStream decompressor = new GZipStream(stream, CompressionMode.Decompress))
                        {

                            worker.ReportProgress(0, "Loading cache");
                            tiles = (List<TileImage>)formatter.Deserialize(decompressor);
                        }
                    }
                }
                catch
                {   //The chunk file is broken or outdated; dump it and restart
                    Console.Error.WriteLine("Cache was outdated, invalid or corrupt; dumping it");
                    worker.ReportProgress(0, "Deleting outdated cache");
                    File.Delete(serialisedFileInfo.FullName);
                    tiles = new List<TileImage>();
                }
            }
            else
            {
                tiles = new List<TileImage>();
            }
            tiles.Sort();

            int success = 0;
            int failure = 0;
            int minWorldx = int.MaxValue;
            int maxWorldx = int.MinValue;
            int minWorldy = int.MaxValue;
            int maxWorldy = int.MinValue;
            int newChunks = 0;
            int deadChunks = 0;
            int existingChunks = 0;
            int refreshChunks = 0;
            int currentChunkIndex = 0;
            int maximumChunks = chunkFiles.Count;

            foreach (TileImage current in tiles)
            {
                if (chunkFiles.Contains(current.File.FullName))
                {
                    // Remove it off the string list
                    
                    if (current.File.LastWriteTime > current.ReadTime)
                    {
                        freshChunks.Add(current);
                        refreshChunks++;
                    }
                    else
                    {
                        chunkFiles.Remove(current.File.FullName);
                        existingChunks++;
                    }

                }
                else
                {
                    // Remove it from the TileImage list
                    Console.Out.WriteLine("Removed chunk {0} from cache", current.File.FullName);
                    tiles.Remove(current);
                    deadChunks++;
                }
                worker.ReportProgress((int)((float)currentChunkIndex / (float)tiles.Count * 100), "Updating cache");
                currentChunkIndex++;
            }
            currentChunkIndex = 0;
            foreach (TileImage current in freshChunks)
            {
                tiles.Remove(current);
                currentChunkIndex++;
                worker.ReportProgress((int)((float)currentChunkIndex / (float) refreshChunks * 100), "Cleaning cache");
            }
            // All that will be left on the string list is the new chunks

            foreach (String chunkPath in chunkFiles)
            {
                //Create new LevelChunks
                LevelChunk newChunk = new LevelChunk(new FileInfo(chunkPath), settings.BytesPerPixel);
                chunks.Add(newChunk);
                newChunks++;
            }
#if DEBUG
            Console.Out.WriteLine("{0} chunks added, {1} chunks removed, {2} chunks from cache and {3} chunks need redrawing", newChunks, deadChunks, existingChunks, refreshChunks);
#endif
            Parallel.ForEach(chunks, current =>
            {
                if (current.hasBlocks)
                {
                    BlockColors colorer = new BlockColors();
                    current.Colorer = colorer;
                    current.lightingLevel = settings.LightingLevel;
                    if (settings.TileType.Equals(ImageType.OBLIQUE))
                    {
                        //TileImage currentTile = new TileImage(current.ObliqueImage, current.worldX, current.worldY, 16, 16 + 129, settings);
                        TileImage currentTile = new TileImage();
                        currentTile.Image = current.ObliqueImage;
                        currentTile.WorldX = current.worldX;
                        currentTile.WorldY = current.worldY;
                        currentTile.Width = 16;
                        currentTile.Height = 16 + 129;
                        currentTile.Settings = settings;
                        currentTile.ReadTime = current.fileInfo.LastWriteTime;
                        currentTile.File = current.fileInfo;
                        lock (tiles)
                        {
                            tiles.Add(currentTile);
                        }
                        success++;
                    }
                    else if (settings.TileType.Equals(ImageType.TERRAIN)
                        || settings.TileType.Equals(ImageType.HEIGHTMAP)
                        || settings.TileType.Equals(ImageType.CAVEMAP)
                        || settings.TileType.Equals(ImageType.SPECTROGRAPH))
                    {
                        TileImage currentTile = new TileImage();
                        currentTile.WorldX = current.worldX;
                        currentTile.WorldY = current.worldY;
                        currentTile.Width = 16;
                        currentTile.Height = 16;
                        currentTile.Settings = settings;
                        currentTile.ReadTime = current.fileInfo.LastWriteTime;
                        currentTile.File = current.fileInfo;
                        if (settings.TileType.Equals(ImageType.TERRAIN))
                        {
                            currentTile.Image = current.TerrainImage;
                        }
                        else if (settings.TileType.Equals(ImageType.HEIGHTMAP))
                        {
                            currentTile.Image = current.HeightmapImage;
                        }
                        else if (settings.TileType.Equals(ImageType.SPECTROGRAPH))
                        {
                            currentTile.Image = current.renderSpectograph(settings.SpectralBlock);
                        }
                        else
                        {
                            currentTile.Image = current.CavemapImage;
                        }
                        lock (tiles)
                        {
                            tiles.Add(currentTile);
                        }
                        success++;
                    }
                    else
                    {
                        throw new Exception("Not yet implemented " + settings.TileType.ToString());
                    }
                    try
                    {
                        worker.ReportProgress((int)((float)success / (float)(newChunks + refreshChunks) * 100), "Processing chunks");
                    }
                    catch { }
                }
                else
                {
                    failure++;
                    maximumChunks--;
#if DEBUG
                    Console.Out.WriteLine("Could not read chunk {0}", current.getFileName());
#endif
                }
            });

            // Recompute world size
            foreach (TileImage current in tiles)
            {
                if (current.WorldX > worldXBound)
                    current.WorldX = worldXBound;
                if (current.WorldX < (-worldXBound))
                    current.WorldX = (-worldXBound);
                if (current.WorldY > worldYBound)
                    current.WorldY = worldYBound;
                if (current.WorldY < (-worldYBound))
                    current.WorldY = (-worldYBound);
                minWorldx = Math.Min(minWorldx, (int)current.WorldX);
                maxWorldx = Math.Max(maxWorldx, (int)current.WorldX);
                minWorldy = Math.Min(minWorldy, (int)current.WorldY);
                maxWorldy = Math.Max(maxWorldy, (int)current.WorldY);
            }

            worldWidth = maxWorldx - minWorldx;
            worldHeight = maxWorldy - minWorldy;
            worldXOffset = minWorldx;
            worldYOffset = minWorldy;

            if (!serialisedFileInfo.Directory.Exists)
            {
                serialisedFileInfo.Directory.Create();
            }
            using (Stream stream = serialisedFileInfo.Open(FileMode.Create, FileAccess.Write, FileShare.None))
            {
                using (GZipStream compressor = new GZipStream(stream, CompressionMode.Compress))
                {
                    worker.ReportProgress(0, "Saving cache");
                    formatter.Serialize(compressor, tiles);
                }
            }
            size = maximumChunks;
            return tiles;
        }

        private List<String> getFolder(String folder, bool hell)
        {
            List<String> files = new List<String>();
            foreach (String directory in Directory.GetDirectories(folder))
            {
                if (hell && directory.Substring(directory.LastIndexOf('\\') + 1).StartsWith("DIM-"))
                {
                        files.AddRange(getFolder(directory, hell));
                }
                else if (!hell && !directory.Substring(directory.LastIndexOf('\\') + 1).StartsWith("DIM-"))
                {
                        files.AddRange(getFolder(directory, hell));
                }
            }
            foreach (String fileItem in Directory.GetFiles(folder, "*.dat"))
            {
                files.Add(fileItem);
            }
            return files;
        }

    }
}
