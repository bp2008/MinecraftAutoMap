﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

namespace MTS
{
    [Serializable()]
    public class TileImage : IComparable<TileImage>
    {
        private byte[] image;
        private long worldX, worldY;
        private int width, height;
        private RenderSettings settings;
        private DateTime readTime;
        private FileInfo file;

        public int Width
        {
            get
            {
                return this.width;
            }
            set
            {
                this.width = value;
            }
        }

        public int Height
        {
            get
            {
                return this.height;
            }
            set
            {
                this.height = value;
            }
        }

        public long WorldX
        {
            get
            {
                return this.worldX;
            }
            set
            {
                this.worldX = value;
            }
        }

        public long WorldY
        {
            get
            {
                return this.worldY;
            }
            set
            {
                this.worldY = value;
            }
        }

        public byte[] Image
        {
            get
            {
                return this.image;
            }
            set
            {
                this.image = value;
            }
        }

        public DateTime ReadTime
        {
            get
            {
                return readTime;
            }
            set
            {
                readTime = value;
            }
        }

        public FileInfo File
        {
            get
            {
                return file;
            }
            set
            {
                file = value;
            }
        }

        public RenderSettings Settings
        {
            get
            {
                return settings;
            }
            set
            {
                this.settings = value;
            }
        }


        public TileImage(byte[] image, long worldX, long worldY, int width, int height, RenderSettings settings)
        {
            this.image = image;
            this.worldX = worldX;
            this.worldY = worldY;
            this.width = width;
            this.height = height;
        }

        public TileImage()
        {

        }

        public int CompareTo(TileImage other)
        {
            int yComp = worldY.CompareTo(other.WorldY);
            if (yComp != 0)
            {
                return yComp;
            }
            else
            {
                return worldX.CompareTo(other.WorldX);
            }
        }

        
    }
}
