﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Xml;

namespace MTS
{
    public class BlockColors
    {
        private Dictionary<int, Blocks> blocks;
        private Blocks defaultBlock;

        public BlockColors()
        {
            this.blocks = new Dictionary<int, Blocks>();
            
            XmlDocument ColorsDocument = new XmlDocument();
            ColorsDocument.Load("BlockColors.xml");
            foreach (XmlElement BlockElement in ColorsDocument.SelectNodes("/Blocks/Block"))
            {
                Blocks newBlock = new Blocks
                {
                    Id = (int)Int32.Parse(BlockElement.Attributes["Id"].Value),
                    Color = Color.FromArgb(
                        (byte)Int32.Parse(BlockElement.Attributes["A"].Value),
                        (byte)Int32.Parse(BlockElement.Attributes["R"].Value),
                        (byte)Int32.Parse(BlockElement.Attributes["G"].Value),
                        (byte)Int32.Parse(BlockElement.Attributes["B"].Value)),
                    Name = BlockElement.Attributes["Name"].Value
                };
                blocks.Add(newBlock.Id, newBlock);
                if (newBlock.Id == -1)
                {
                    defaultBlock = newBlock;
                }
                
            }
            return;
        }

        public Dictionary<int, Blocks> Blocks
        {
            get
            {
                return blocks;
            }
        }

        public Color getBlockColor(byte tile)
        {
            if (blocks.ContainsKey(tile))
            {
                return this.blocks[tile].Color;
            }
            else
            {
                //Console.Out.WriteLine("Unknown block {0}", tile);
                return this.defaultBlock.Color;
            }
        }
    }
}
