﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace MTS
{
    public enum ImageType { TERRAIN, HEIGHTMAP, OBLIQUE, ISOMETRIC, CAVEMAP, SPECTROGRAPH };

    public class WorldRenderer
    {
        BackgroundWorker worker = new BackgroundWorker();
        private ChunkCache cache;

        public String CacheDir
        {
            get
            {
                return cache.CacheDir;
            }
            set
            {
                cache.CacheDir = value;
            }
        }

        public WorldRenderer()
        {
            cache = new ChunkCache();
        }

        public BitmapSource renderWorld(RenderSettings settings, BackgroundWorker worker)
        {
            DateTime startTime = DateTime.Now;
            PixelFormat outputFormat = PixelFormats.Bgra32;
            int _bytesPerPixel = (outputFormat.BitsPerPixel + 7) / 8;
            settings.BytesPerPixel = _bytesPerPixel;
            
            List<TileImage> tiles = cache.getCache(settings, worker);

#if DEBUG
            Console.Out.WriteLine("{0}bpp", settings.BytesPerPixel); 
#endif
            
            int worldImageWidth = ((int)cache.WorldWidth + 1);
            int worldImageHeight = ((int)cache.WorldHeight + 1);
            if (settings.TileType.Equals(ImageType.OBLIQUE))
            {
                worldImageWidth = worldImageWidth * 16;
                worldImageHeight = worldImageHeight * 16 + 129;
            }
            else if (settings.TileType.Equals(ImageType.TERRAIN) || settings.TileType.Equals(ImageType.HEIGHTMAP) || settings.TileType.Equals(ImageType.CAVEMAP) || settings.TileType.Equals(ImageType.SPECTROGRAPH))
            {
                worldImageWidth = worldImageWidth * 16;
                worldImageHeight = worldImageHeight * 16;
            }
            else
            {
                throw new Exception("Not yet implemented " + settings.TileType.ToString());
            }
#if DEBUG
            Console.Out.WriteLine("Image is {0}x{1}", worldImageWidth, worldImageHeight);
#endif
            WriteableBitmap outputBitmap = new WriteableBitmap(worldImageWidth, worldImageHeight, 96, 96, outputFormat, null);
            tiles.Sort();
            tiles.Reverse();

#if DEBUG
            Console.Out.WriteLine("World is {0}x{1}", cache.WorldWidth, cache.WorldHeight);
#endif
            int currentIndex = 0;

            foreach (TileImage current in tiles)
            {
                byte[] inputImageBytes = current.Image;
                int _innerStride = current.Width * _bytesPerPixel;
                Int32 destinationX = ((int)current.WorldX - (int)cache.WorldXOffset) * 16;
                Int32 destinationY = ((int)current.WorldY - (int)cache.WorldYOffset) * 16;
                Int32Rect destinationRect = new Int32Rect(destinationX, destinationY, current.Width, current.Height);
                outputBitmap.Lock();
                unsafe
                {
                    int pBackBuffer = (int)outputBitmap.BackBuffer;
                    // Go to the first pixel from the global coordinates
                    pBackBuffer += destinationRect.Y * outputBitmap.BackBufferStride;
                    pBackBuffer += destinationRect.X * _bytesPerPixel;
                    // Now iterate over each pixel
                    for (int y = 0; y < current.Height; y++)
                    {
                        for (int x = 0; x < current.Width; x++)
                        {
                            // Insert the pixel then move the backbuffer on a pixel
                            int byteOffset = (x + y * current.Width) * _bytesPerPixel;

                            int existing_color_data = *((int*)pBackBuffer);
                            Color existing_color = Color.FromArgb((byte)((existing_color_data & 0xFF000000) >> 24),
                                                                    (byte)((existing_color_data & 0x00FF0000) >> 16),
                                                                    (byte)((existing_color_data & 0x0000FF00) >> 8),
                                                                    (byte)((existing_color_data & 0x000000FF) >> 0));

                            Color input_color = Color.FromArgb(255, 0, 0, 0);
                            if (inputImageBytes != null)
                                input_color = Color.FromArgb(inputImageBytes[byteOffset + 3],
                                                                inputImageBytes[byteOffset + 2],
                                                                inputImageBytes[byteOffset + 1],
                                                                inputImageBytes[byteOffset]);

                            if (existing_color.A == 0 && input_color.A > 0)
                            {
                                Color outputColor = this.blendColors(input_color, existing_color, 128);
                                
                                // Begin MinecraftAM modification
                                if (current.WorldX == 0 && current.WorldY == 0 && x == 7 && y == 0)
                                {
                                    //outputColor = Color.FromRgb(0x12, 0x34, 0x67); // This is a sentinal color for the origin pixel, for positioning the map.

                                    worker.ReportProgress(200, (destinationX + 7) + "," + destinationY);
                                }
                                // End MinecraftAM modification


                                int color_data = outputColor.A << 24; // A
                                color_data |= outputColor.R << 16; // R
                                color_data |= outputColor.G << 8; // G
                                color_data |= outputColor.B << 0; // B
                                *((int*)pBackBuffer) = color_data;
                            }



                            pBackBuffer += _bytesPerPixel;
                        }
                        // Move on to the start of the next row (backbufferstride - width * bytes per pixel)
                        pBackBuffer += (outputBitmap.BackBufferStride - current.Width * _bytesPerPixel);
                    }
                    outputBitmap.AddDirtyRect(destinationRect);
                }
                outputBitmap.Unlock();
                worker.ReportProgress((int)((float)currentIndex / (float)cache.Size * 100), "Drawing image");
                currentIndex++;
            }

            outputBitmap.Freeze();

            TimeSpan elapsed = DateTime.Now - startTime;
#if DEBUG
            Console.Out.WriteLine("Rendered {0} chunks in {1}", cache.Size, elapsed);
#endif
            return outputBitmap;
        }

        private List<String> getFolder(String folder)
        {
            List<String> files = new List<String>();
            foreach (String directory in Directory.GetDirectories(folder))
            {
                files.AddRange(getFolder(directory));
            }
            foreach (String fileItem in Directory.GetFiles(folder, "*.dat"))
            {
                files.Add(fileItem);
            }
            return files;
        }

        private Color blendColors(Color A, Color B, int h)
        {
            Color C = new Color();
            float Aa = A.ScA;
            float Ba = B.ScA;
            float Alpha = Aa + Ba * (1 - Aa);
            C.R = (byte)((float)A.R * Aa + (float)B.R * Ba * (1 - Aa) * (float)h / 128 / Alpha);
            C.G = (byte)(float)(A.G * Aa + (float)B.G * Ba * (1 - Aa) * (float)h / 128 / Alpha);
            C.B = (byte)((float)A.B * Aa + (float)B.B * Ba * (1 - Aa) * (float)h / 128 / Alpha);
            C.A = (byte)(Alpha * 255);
            return C;
        }
    }
}
