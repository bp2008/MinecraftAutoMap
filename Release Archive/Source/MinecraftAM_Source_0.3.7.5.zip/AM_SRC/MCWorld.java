import java.io.File;

/*
  private long F = System.currentTimeMillis();
  protected int j = 40;
  public int k;
  public Random l = new Random();
  public int m;
  public int n;
  public int o;
  public boolean p = false;
  public final ou q;
  protected List r = new ArrayList();
  private bd G;
  public File s;
  public File t;   World Folder (the second File)
  public long u = 0L;
  private in H;
  public long v = 0L;
  public final String w;
  public boolean x;
  private ArrayList I = new ArrayList();
 */
/**
 *
 * @author Brian
 */
public class MCWorld
{
    /**
     * File pointing at the loaded world directory.
     */
    public File worldFile;

    public MCWorld(dn paramworld)
    {
        worldFile = paramworld.t;
    }

    public static File getWorldFile(dn paramworld)
    {
        return new MCWorld(paramworld).worldFile;
    }
}
