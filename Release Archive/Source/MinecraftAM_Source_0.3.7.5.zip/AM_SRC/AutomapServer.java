import java.util.Random;
import java.util.Vector;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.brian.eventtcp.BitConverter;
import org.brian.eventtcp.EventTcpClient;
import org.brian.eventtcp.EventTcpClientListener;
import org.brian.eventtcp.EventTcpServer;
/**
 *
 * @author Brian
 */
public class AutomapServer implements EventTcpClientListener
{
    // eu = Player
    // dn = world
    // Player.aB = player world object
    private static eu playerUser = null;
    private static Vector<eu> players = new Vector<eu>();
    private static dn world;
    private static String playerName = "";
    private static byte[] playerNameArray = new byte[0];
    private static byte[] playerNameSize = new byte[0];
    private static final int SHORT_BYTES = 2;
    private static final int INT_BYTES = 4;
    private static final int LONG_BYTES = 8;
    private static final int FLOAT_BYTES = 4;
    private static final int DOUBLE_BYTES = 8;
    private static final byte GET_PLAYER_LOCATION = 0;
    private static final byte GET_WORLD_CHUNK = 1;
    private static final byte GET_FULL_COLUMN = 2;
    private static final byte GET_WORLD_PATH = 20;
    private static int blockChunkUpdatesOnWorldChangeMs = 10000;
    private static int playerIdleTimeMs = 60000;
    private static double[] playerLastPositionHash = new double[1024];
    private static long[] playerLastMoved = new long[1024];
    private static boolean initialized = false;
    private static boolean initializing = false;
    private final static Object initLock = new Object();
    private static int port = 50191;
    private static AutomapServer asInstance = new AutomapServer();
    //private static Logger logger = Logger.getLogger("MCCLIENT");
    private static EventTcpServer server = null;
    private boolean sendNewWorldFile = false;
    private long chunksAllowedAfter = System.currentTimeMillis();
    private static int errors = 0;
    private boolean sendRandomChunkData = false;
    private static Logger logger = Logger.getLogger("AutomapServer");
    private static FileHandler fh;

    private static void SetNewWorldObject(dn worldparam)
    {
        if (world == worldparam)
            return; // A new player joined an SMP server, most likely.  Or, I suppose, the player could have died in SMP.  Either way, lets not require a reload.
        asInstance.BlockChunkUpdates(blockChunkUpdatesOnWorldChangeMs);
        asInstance.sendNewWorldFile = true;
        world = worldparam;
        ClearAllButMe();
    }

    private static void ClearAllButMe()
    {
        synchronized (players)
        {
            for (int i = 0; i < players.size(); i++)
            {
                if (!MCPlayer.getName(players.elementAt(i)).equals(playerName))
                {
                    players.removeElementAt(i);
                    i--;
                }
            }
        }
    }

    private static double GetPlayerLocationHash(eu paramPlayer)
    {
        MCPlayer p = new MCPlayer(paramPlayer);
        return p.x * p.y * p.z * p.rotation * p.pitch;
    }

    private static eu getMyPlayer()
    {
        synchronized (players)
        {
            for (int i = 0; i < players.size(); i++)
            {
                eu pl = players.elementAt(i);
                if (pl == null)
                    return null;
                MCPlayer mcp = new MCPlayer(pl);
                if (mcp.name.equals(playerName))
                    return pl;
            }
        }
        return null;
    }
//    static int ctr = 0;

    private void CheckWorldObject()
    {
        eu myplayer = AutomapServer.getMyPlayer();
        if (myplayer != null)
            SetNewWorldObject(myplayer.aB);
    }

    private void BlockChunkUpdates(int msTime)
    {
        chunksAllowedAfter = System.currentTimeMillis() + msTime;
    }

    private AutomapServer()
    {
    }

    public static void initialize(eu playerparam, dn worldparam)
    {
        try
        {
            // I'll be damned if I am going to cause the game to crash here.
            // logger.log(Level.INFO, "Initialization started");
            SetNewWorldObject(worldparam);
            synchronized (players)
            {
                if (!players.contains(playerparam))
                {
                    players.add(playerparam);
                    int idx = players.size() - 1;
                    if (idx < playerLastMoved.length && idx >= 0)
                    {
                        playerLastMoved[idx] = System.currentTimeMillis();
                        playerLastPositionHash[idx] = GetPlayerLocationHash(playerparam);
                    }
                }
            }
            synchronized (initLock)
            {
                if (initialized || initializing)
                    return;
                initializing = true;
            }
            try
            {
                server = new EventTcpServer(port, asInstance);
                fh = new FileHandler("AutoMapServer.log");
                logger.addHandler(fh);
                logger.setLevel(Level.ALL);
                SimpleFormatter formatter = new SimpleFormatter();
                fh.setFormatter(formatter);
                playerUser = playerparam;
                if (playerUser != null)
                {
                    MCPlayer mcp = new MCPlayer(playerUser);
                    if (mcp.name != null && !mcp.name.equals(""))
                    {
                        playerName = mcp.name;
                        playerNameArray = BitConverter.GetBytes(playerName);
                        playerNameSize = BitConverter.GetBytes(playerNameArray.length);
                    }
                }
            } catch (Exception ex)
            {
                logger.log(Level.SEVERE, "Unable to initialize the AutomapServer: " + ex.getMessage());
                try
                {
                    logger.log(Level.INFO, "Player Name: " + playerName);
                    logger.log(Level.INFO, "Player Name array length: " + playerNameArray.length);
                    logger.log(Level.INFO, "Player Name size length: " + playerNameArray.length);
                } catch (Exception exc)
                {
                    logger.log(Level.WARNING, "Exception while logging exception: " + exc.getMessage());
                }
//            LogException(ex);
                synchronized (initLock)
                {
                    initializing = false;
                    initialized = false;
                }
            }
            synchronized (initLock)
            {
                initializing = false;
                initialized = true;
            }
//        LogText("Success!");
//        logger.log(Level.INFO, "Initialization complete");
        } catch (Exception ex)
        {
            ex.getMessage();
        }
    }

    public byte[] getWorldChunk(byte[] request)
    {
        try
        {
            if (System.currentTimeMillis() < chunksAllowedAfter)
                return new byte[0];
            //EventTcpServer.ReportException("GWC: 0, Length: " + request.length + ", required Length: " + ((INT_BYTES * 6) + 1));
            if (request.length < (INT_BYTES * 6) + 1)
                return new byte[0];
            int x, y, z, dx, dy, dz, reqIdx = 1;
            try
            {
                x = BitConverter.ToInt32(request, reqIdx);
                // EventTcpServer.ReportException("GWC: 1");
                reqIdx += INT_BYTES;
                y = BitConverter.ToInt32(request, reqIdx);
                // EventTcpServer.ReportException("GWC: 2");
                reqIdx += INT_BYTES;
                z = BitConverter.ToInt32(request, reqIdx);
                //EventTcpServer.ReportException("GWC: 3");
                reqIdx += INT_BYTES;
                dx = BitConverter.ToInt32(request, reqIdx);
                //EventTcpServer.ReportException("GWC: 4");
                reqIdx += INT_BYTES;
                dy = BitConverter.ToInt32(request, reqIdx);
                //EventTcpServer.ReportException("GWC: 5");
                reqIdx += INT_BYTES;
                dz = BitConverter.ToInt32(request, reqIdx);
                reqIdx += INT_BYTES;
                //EventTcpServer.ReportException("GWC: \r\n" + x + "\r\n" + y + "\r\n" + z + "\r\n" + dx + "\r\n" + dy + "\r\n" + dz);
            } catch (Exception ex)
            {
                errors++;
                return new byte[0];
            }
            byte[] bytes = new byte[request.length + (dx * dy * dz)];
            // Put the original request into the array at the beginning.
            this.InsertBytes(bytes, 0, request);
            Location Correct = Location.Translate(x, y, z);
            if (sendRandomChunkData)
            {
                Random r = new Random();
                for (int a = 0; a < dy; a++)
                    for (int b = 0; b < dx; b++)
                        for (int c = 0; c < dz; c++)
                            bytes[reqIdx++] = (byte) r.nextInt(128);
            } else
            {
                for (int a = 0; a < dy; a++)
                    for (int b = 0; b < dx; b++)
                        for (int c = 0; c < dz; c++) // world.e is something similar that seems to detect torches or light or object rotation or something and display them using the first few integers (0-4?)
                            bytes[reqIdx++] = (byte) world.a(Correct.x + b, Correct.z + c, Correct.y + a);
            }
            return bytes;
        } catch (Exception ex)
        {
            return new byte[0];
        }
    }

    /**
     * Format:
     * packet type, x, y, z, rotation, pitch, player name
     * which uses types
     * byte, double, double, double, float, float, char[]
     * @return
     */
    public byte[] getPlayerLocation()
    {
        try
        {
            if (playerNameSize == null || playerNameSize.length <= 0)
            {
                if (playerUser != null)
                {
                    MCPlayer mcp = new MCPlayer(playerUser);
                    if (mcp.name != null && !mcp.name.equals(""))
                    {
                        playerName = mcp.name;
                        playerNameArray = BitConverter.GetBytes(playerName);
                        playerNameSize = BitConverter.GetBytes(playerNameArray.length);
                    }
                }
            }
            int playercount = players.size();
            synchronized (players)
            {
                Vector<eu> playersSeenAlready = new Vector<eu>(players.size());
                // Get rid of players that no longer exist.
                for (int i = playercount - 1; i > -1; i--)
                {
                    eu pl = players.elementAt(i);
                    MCPlayer mcp = new MCPlayer(pl);
                    if (pl == null || playerIsDuplicate(mcp.name, playersSeenAlready))
                    {
                        players.removeElementAt(i);
                        playercount = players.size();
                    } else
                        playersSeenAlready.add(pl);
                }
                if (playercount < 1)
                    return new byte[0];
                // Get player names, turn them into byte, count total size
                byte[][] playerNames = new byte[playercount][];
                int playerNamesTotalSize = 0;
                long currentTimeMs = System.currentTimeMillis();
                for (int i = 0; i < playercount; i++)
                {
                    String playerNameHolder = MCPlayer.getName(players.elementAt(i));
                    ///// Handle idle checks /////
                    if (!playerNameHolder.equals(playerName) && i < playerLastMoved.length)
                    {
                        double newHash = GetPlayerLocationHash(players.elementAt(i));
                        if (newHash != playerLastPositionHash[i])
                        {
                            playerLastMoved[i] = System.currentTimeMillis();
                            playerLastPositionHash[i] = newHash;
                        } else if (playerLastMoved[i] + playerIdleTimeMs < currentTimeMs)
                            playerNameHolder += " [idle]";
                    }
                    // Create byte array for name
                    playerNames[i] = BitConverter.GetBytes(playerNameHolder);
                    playerNamesTotalSize += playerNames[i].length;
                }
                int basePlayerSize = 36;
                int byteCounter = 0;
                byte[] bytes = new byte[1 + INT_BYTES + playerNameArray.length + (basePlayerSize * playercount) + playerNamesTotalSize];
                bytes[byteCounter++] = GET_PLAYER_LOCATION;
                InsertBytes(bytes, byteCounter, playerNameSize);
                byteCounter += INT_BYTES;
                InsertBytes(bytes, byteCounter, playerNameArray);
                byteCounter += playerNameArray.length;
                for (int i = 0; i < playercount; i++)
                {
                    eu pl = players.elementAt(i);
                    MCPlayer mcp = new MCPlayer(pl);
                    InsertBytes(bytes, byteCounter, BitConverter.GetBytes(-mcp.x)); // X
                    byteCounter += DOUBLE_BYTES;
                    InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.y)); // Y
                    byteCounter += DOUBLE_BYTES;
                    InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.z)); // Z
                    byteCounter += DOUBLE_BYTES;
                    InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.rotation)); // Rotation
                    byteCounter += FLOAT_BYTES;
                    InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.pitch)); // Pitch
                    byteCounter += FLOAT_BYTES;
                    InsertBytes(bytes, byteCounter, BitConverter.GetBytes(playerNames[i].length)); // Pitch
                    byteCounter += INT_BYTES;
                    InsertBytes(bytes, byteCounter, playerNames[i]); // Name
                    byteCounter += playerNames[i].length;
                }
                return bytes;
            }

        } catch (Exception ex)
        {
            // Nothing to worry about, I hope.
            //Should just mean a player went null while function was running.
            //Will be fixed on the next function call.
            logger.log(Level.WARNING, "Failed getting player locations.  A player may have become null while the function was executing.  Exception message: " + ex.getMessage());
            return new byte[0];
        }
    }

    /**
     * Returns a full column of blocks as chars.
     * Preceding the chars is "gfc\r" to inform the client
     * that this is a response to getFullColumn.
     * @param x
     * @param y
     * @return
     * @throws RemoteException
     */
    public byte[] getFullColumn(String[] parts)
    {
        return new byte[0];
//        if (parts.length < 3)
//            return "";
//        int x;
//        int y;
//        try
//        {
//            x = Integer.parseInt(parts[1]);
//            y = Integer.parseInt(parts[2]);
//        } catch (Exception ex)
//        {
////            LogException(ex);
//            return "";
//        }
//
//        Location Correct = Location.Translate(x, y, 0);
//        StringBuffer sb = new StringBuffer(130);
//        sb.append("gfc\r");
//        sb.append(parts[1]);
//        sb.append("\r");
//        sb.append(parts[2]);
//        sb.append("\r");
//        for (int i = 0; i < 130; i++)
//            sb.append((char) world.a(Correct.x, i, Correct.y));
//        return sb.toString();
    }

    private byte[] getFilePath()
    {
        byte[] fp;
        MCWorld mcw = new MCWorld(world);
        if (mcw.worldFile == null)
            fp = BitConverter.GetBytes("multiplayer");
        else
        {
            fp = BitConverter.GetBytes(mcw.worldFile.getAbsolutePath());
            if (fp.length <= 0)
                fp = BitConverter.GetBytes("multiplayer");
        }
        byte[] bytes = new byte[fp.length + 1];
        bytes[0] = GET_WORLD_PATH;
        InsertBytes(bytes, 1, fp);
        return bytes;
    }
//boolean shown = false;

    @Override
    public void messageReceived(byte[] message, EventTcpClient client)
    {
        try
        {
            CheckWorldObject();
            if (sendNewWorldFile)
            {
                client.sendMessage(this.getFilePath());
                sendNewWorldFile = false;
            }
//        LogText("Message Received: " + message);
            byte[] response = null;
            if (message.length <= 0)
            {
                //EventTcpServer.ReportException("WTF message blank");
                errors++;
                return;
            }
            byte messageType = message[0];
//        if (messageType == GET_FULL_COLUMN)
//            response = getFullColumn(message);
            if (messageType == GET_PLAYER_LOCATION)
                response = getPlayerLocation();
            else if (messageType == GET_WORLD_CHUNK)
            {
                byte[] responseDupe = new byte[0];
                int tryCount = 0;
                int maxTries = 10;
                do
                {   // Integrity Check the result!

                    if (tryCount++ >= maxTries)
                    {
                        logger.log(Level.SEVERE, "Failed to get a correctly formed chunk "
                                + maxTries + " times in a row.  Most recent chunk data follows:\r\n"
                                + ByteArrayToCommaString(responseDupe));
                        return;
                    }
                    response = getWorldChunk(message);
                    if (response.length == 0)
                        return;
                    responseDupe = getWorldChunk(message);
                    if (responseDupe.length == 0)
                        return;
                } while (!ArraysMatch(response, responseDupe));
            } else if (messageType == GET_WORLD_PATH)
                response = getFilePath();
            //      else if (message.startsWith("err"))
            //          response = String.valueOf(errors) + ", "
            //                  + String.valueOf(org.brian.eventtcp.StringPacker.parseerrors + ", "
            //                  + String.valueOf(org.brian.eventtcp.StringPacker.parseerrorsType2) + ", "
            //                  + String.valueOf(org.brian.eventtcp.StringPacker.existing255s));
            //      else if (message.startsWith("cnt"))
            //          response = String.valueOf(EventTcpServer.receivedCnt) + " recv, "
            //                  + String.valueOf(EventTcpServer.sentCnt) + " sent\r\n"
            //                  + String.valueOf(EventTcpServer.receivedChars) + "cRecv, "
            //                  + String.valueOf(EventTcpServer.sentChars) + "cSent";
            if (response != null && response.length > 0)
            {
                if (!client.sendMessage(response))
                    client.Disconnect();
            } else
            {
                errors++;
            }
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex, "Exception in message handler: ");
        }
    }

    @Override
    public void disconnected(EventTcpClient client)
    {
        server.removeClient(client);
    }

    public void InsertBytes(byte[] destination, int destinationOffset, byte[] source)
    {
        if (destination.length - destinationOffset < source.length)
            return;
        for (int i = 0; i < source.length; i++, destinationOffset++)
            destination[destinationOffset] = source[i];
    }

    private String ByteArrayToCommaString(byte[] message)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < message.length; i++)
        {
            sb.append(message[i]);
            sb.append(',');
        }
        return sb.toString();
    }

    private String ByteArrayToMultilineString(byte[] message)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < message.length; i++)
        {
            sb.append(message[i]);
            sb.append("\r\n");
        }
        return sb.toString();
    }

    private boolean ArraysMatch(byte[] response, byte[] responseDupe)
    {
        if (response.length != responseDupe.length)
            return false;
        //logger.log(Level.SEVERE, "WorldChunk Length Mismatch: " + response.length + " vs " + responseDupe.length + "\r\n" + ByteArrayToCommaString(response) + "\r\n" + ByteArrayToCommaString(responseDupe));
        //EventTcpServer.ReportException("Response lengths did not match: " + response.length + ", " + responseDupe.length);
//        int mismatches = 0;
        for (int i = 0; i < response.length; i++)
            if (response[i] != responseDupe[i])
                return false;
//        if (mismatches > 0)
//            logger.log(Level.SEVERE, "WorldChunk Content Mismatch (" + mismatches + "):\r\n" + ByteArrayToCommaString(response) + "\r\n" + ByteArrayToCommaString(responseDupe));
        return true;
    }

    private boolean playerIsDuplicate(String name, Vector<eu> playersSeenAlready)
    {
        for (int i = 0; i < playersSeenAlready.size(); i++)
            if (name.equals(MCPlayer.getName(playersSeenAlready.elementAt(i))))
                return true;
        return false;
    }

    private static boolean AccurateStringCompare(String one, String two)
    {
        if (one.length() != two.length())
            return false;
        for (int i = 0; i < one.length(); i++)
        {
            if (one.charAt(i) != two.charAt(i))
                return false;
        }
        return true;
    }
}

class Location
{
    int x, y, z;

    public Location(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public static Location Translate(int x, int y, int z)
    {
        x = -x - 1;
        int tempx = y;
        y = x;
        x = tempx;
        return new Location(x, y, z);
    }
}
