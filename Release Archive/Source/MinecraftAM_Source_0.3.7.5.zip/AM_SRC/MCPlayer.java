/*
     * public abstract class lr
{
  private static int a = 0;

  public int am = a++;

  public double an = 1.0D;

  public boolean ao = false;
  public lr ap;
  public lr aq;
  public cw ar;
  public double as;
  public double at;
  public double au;
  public double av; Y
  public double aw; Z
  public double ax; X
  public double ay;
  public double az;
  public double aA;
  public float aB; Rotation
  public float aC; Pitch
  public float aD;
  public float aE;
  public final cn aF = cn.a(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
  public boolean aG = false;
  public boolean aH;
  public boolean aI;
  public boolean aJ = false;
*/
/**
 *
 * @author Brian
 */
public class MCPlayer
{
    // String o = Player Name
    // double aH = Player x
    // double aF = Player y
    // double aG = Player z
    // float aL = Player Rotation
    // float aM = Player Pitch
    // dn aB = world object;
    String name = "";
    double x = 0;
    double y = 0;
    double z = 0;
    float rotation = 0;
    float pitch = 0;
    public MCPlayer(eu playerObj)
    {
        name = playerObj.o;
        x = playerObj.aH;
        y = playerObj.aF;
        z = playerObj.aG;
        rotation = playerObj.aL;
        pitch = playerObj.aM;
    }
    public static String getName(eu playerObj)
    {
        return new MCPlayer(playerObj).name;
    }
    public static double getX(eu playerObj)
    {
        return new MCPlayer(playerObj).x;
    }
    public static double getY(eu playerObj)
    {
        return new MCPlayer(playerObj).y;
    }
    public static double getZ(eu playerObj)
    {
        return new MCPlayer(playerObj).z;
    }
    public static float getRotation(eu playerObj)
    {
        return new MCPlayer(playerObj).rotation;
    }
    public static float getPitch(eu playerObj)
    {
        return new MCPlayer(playerObj).pitch;
    }
}
