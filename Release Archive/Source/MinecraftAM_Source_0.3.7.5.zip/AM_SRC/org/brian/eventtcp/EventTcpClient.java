package org.brian.eventtcp;

import java.io.*;
import java.net.*;

/**
 *
 * @author Brian
 */
public class EventTcpClient
{
    protected Socket sockClient = null;
    protected OutputStream out = null;
    protected InputStream in = null;
    // Logger logger = Logger.getLogger("EventTcp");
    public boolean isConnected = false;
    protected EventTcpReader readerThread = null;
    protected EventTcpWriter writerThread = null;
    protected EventTcpClientListener listener;
    public boolean announcedDisconnect = false;
    protected final Object disconnectLock = new Object();

    public EventTcpClient(String host, int port, EventTcpClientListener listener)
    {
        try
        {
            boolean announcedDisconnect = false;
            this.listener = listener;
            sockClient = new Socket();
            sockClient.setReceiveBufferSize(EventTcpServer.bufferSize);
            sockClient.setSendBufferSize(EventTcpServer.bufferSize);
            sockClient.connect(new InetSocketAddress(host, port));

            in = sockClient.getInputStream();
            out = sockClient.getOutputStream();

            readerThread = new EventTcpReader(in, this, listener);
            writerThread = new EventTcpWriter(out, this);
            readerThread.start();
            writerThread.start();

            isConnected = true;
        } catch (UnknownHostException e)
        {
//            logger.log(Level.WARNING, e.getMessage(), e);
            isConnected = false;
            Disconnect();
        } catch (IOException e)
        {
//            logger.log(Level.SEVERE, e.getMessage(), e);
            isConnected = false;
            Disconnect();
        }
    }

    public EventTcpClient(Socket sock, EventTcpClientListener listener)
    {
        try
        {
            boolean announcedDisconnect = false;
            this.listener = listener;
            sockClient = sock;
            if (sockClient.getReceiveBufferSize() != EventTcpServer.bufferSize)
                sockClient.setReceiveBufferSize(EventTcpServer.bufferSize);
            sockClient.setSendBufferSize(EventTcpServer.bufferSize);

            in = sockClient.getInputStream();
            out = sockClient.getOutputStream();

            readerThread = new EventTcpReader(in, this, listener);
            writerThread = new EventTcpWriter(out, this);
            readerThread.start();
            writerThread.start();

            isConnected = true;
        } catch (UnknownHostException ex)
        {
            EventTcpServer.ReportException(ex);
//            logger.log(Level.WARNING, e.getMessage(), e);
            isConnected = false;
            Disconnect();
        } catch (IOException ex)
        {
            EventTcpServer.ReportException(ex);
//            logger.log(Level.SEVERE, e.getMessage(), e);
            isConnected = false;
            Disconnect();
        }
    }

    public void Disconnect()
    {
        try
        {

            if (sockClient != null)
                sockClient.close();
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
//            logger.log(Level.WARNING, ex.getMessage(), ex);
        }
        try
        {
            readerThread.abort();
            if (writerThread != null)
                writerThread.abort();
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
        }
        try
        {
            if (out != null)
                out.close();
            if (in != null)
                in.close();
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
        }
        synchronized (disconnectLock)
        {
            if (!announcedDisconnect)
            {
                listener.disconnected(this);
                announcedDisconnect = true;
            }
        }
        isConnected = false;
    }

//    public String getMessage()
//    {
//        if (readerThread == null)
//            return null;
//        return readerThread.getMessage();
//    }
    public boolean sendMessage(byte[] msg)
    {
        if (writerThread == null)
            return false;
        return writerThread.sendMessage(msg);
    }
}


