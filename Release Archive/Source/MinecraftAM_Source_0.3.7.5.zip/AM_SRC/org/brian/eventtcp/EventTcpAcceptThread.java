package org.brian.eventtcp;

import java.net.Socket;

/**
 *
 * @author Brian
 */
public class EventTcpAcceptThread extends Thread
{
    EventTcpAcceptThreadArgs args;

    public EventTcpAcceptThread(EventTcpAcceptThreadArgs argsparam)
    {
        args = argsparam;
    }

    @Override
    public void run()
    {
        args.isListening = true;
        try
        {
            while (args.isListening)
            {
                Socket client = args.sockServer.accept();
                if (client == null)
                {
                    EventTcpServer.ReportException("Client was null");
                    //logger.log(Level.WARNING, "EventTcpServer failed to accept a client connection.");
                    continue;
                }
                EventTcpClient etc = new EventTcpClient(client, args.listener);
                if (etc == null)
                {
                    EventTcpServer.ReportException("EventTcpClient was null");
                    //logger.log(Level.WARNING, "EventTcpServer failed to work with a new client connection.");
                    continue;
                }
                //
                //
                synchronized (args.clientLock)
                {
                    args.clients.add(etc);
                }
            //EventTcpServer.ReportException("Client was connected");
                //etc.sendMessage("Welcome");
            }
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
            //logger.log(Level.WARNING, ex.getMessage(), ex);
        }
        args.isListening = false;
    }
}
