﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace DataSource
{
    public class PacketPacker
    {
        public bool haveASize = false;
        public int iCurrentIndex = 0;
        public int iCurrentSize = 0;
        public byte[] currentPacket;
        public byte[] leftovers;
        public static bool Sha256Digest = false;

        public PacketPacker()
        {
            leftovers = new byte[0];
        }
        public byte[] Pack(byte[] bytes)
        {
            if (Sha256Digest)
                bytes = AddSha256Digest(bytes);
            byte[] size = ByteConverter.GetBytes(bytes.Length);
            byte[] bytesNew = new byte[bytes.Length + size.Length];
            if (size.Length == 4)
            {
                bytesNew[0] = size[0];
                bytesNew[1] = size[1];
                bytesNew[2] = size[2];
                bytesNew[3] = size[3];
            }
            else
            {
                // awwe F, what now?!
            }
            for (int i = 0, j = 4; i < bytes.Length; i++, j++)
            {
                bytesNew[j] = bytes[i];
            }
            return bytesNew;
        }
        
        public void Unpack(byte[] bytes, ref List<Packet> packets)
        {
            // Attach leftovers, if there were any.
            if (leftovers.Length > 0)
            {
                byte[] newBytes = new byte[leftovers.Length + bytes.Length];
                int i = 0;
                // Copy leftovers into new array.
                for (; i < leftovers.Length; i++)
                    newBytes[i] = leftovers[i];
                // Get rid of leftovers so they are not used again by accident.
                leftovers = new byte[0];
                // Copy passed-in bytes into new array starting where the leftovers left off.
                for (int k = 0; k < bytes.Length; i++, k++)
                    newBytes[i] = bytes[k];
                // Replace passed-in byte array with new array.
                bytes = newBytes;
            }
            // Handle the passed-in byte array.
            int j = 0;
            while (true)
            {
                // j is the index we are currently at in 'bytes'
                if (!haveASize)
                {
                    if (bytes.Length - j < 4)
                    {
                        leftovers = ArrayCopy(bytes, j, bytes.Length - j); // These are leftovers.
                        return;
                    }
                    // Get the size out of the passed byte array
                    // Convert size to int and prepare for array copying.
                    iCurrentSize = ByteConverter.ToInt32(bytes, j);
                    j += 4;
                    iCurrentIndex = 0;
                    currentPacket = new byte[iCurrentSize];
                    haveASize = true;
                }
                // We now have a set size if we got to here.
                // Copy bytes until something runs out or fills up
                for (; iCurrentIndex < iCurrentSize && j < bytes.Length; iCurrentIndex++, j++)
                {
                    currentPacket[iCurrentIndex] = bytes[j];
                }
                // We got here, meaning either the packet is complete or we ran out of bytes to fill the packet with, or both!
                if (iCurrentIndex == iCurrentSize)
                {
                    if (Sha256Digest)
                        currentPacket = VerifySha256Digest(currentPacket);
                    // Packet is complete.  Return it and start another.
                    packets.Add(new Packet(currentPacket));
                    // Reset values.
                    iCurrentSize = 0;
                    iCurrentIndex = 0;
                    haveASize = false;
                }
                if (j == bytes.Length)
                {
                    // We ran out of bytes.  We need to wait for more before we can continue.
                    return;
                }
            }
        }

        /**
         * Copies the specified section of the specified array into a new array of size count.
         * Copy starts at startIndex and proceeds until count bytes have been reached.
         * An array of size 0 will be returned if the parameters are not valid.
         * @param bytes
         * @param startIndex
         * @param count
         * @return
         */
        private byte[] ArrayCopy(byte[] bytes, int startIndex, int count)
        {
            if (count <= 0 || startIndex < 0 || startIndex >= bytes.Length || startIndex + count > bytes.Length)
                return new byte[0];
            byte[] copy = new byte[count];
            for (int i = 0; i < count; i++, startIndex++)
                copy[i] = bytes[startIndex];
            return copy;
        }
        private bool ArraysMatch(byte[] response, byte[] responseDupe)
        {
            if (response.Length != responseDupe.Length)
                return false;
            for (int i = 0; i < response.Length; i++)
                if (response[i] != responseDupe[i])
                    return false;
            return true;
        }
        public void InsertBytes(byte[] destination, int destinationOffset, byte[] source)
        {
            if (destination.Length - destinationOffset < source.Length)
                return;
            for (int i = 0; i < source.Length; i++, destinationOffset++)
                destination[destinationOffset] = source[i];
        }

        private byte[] AddSha256Digest(byte[] bytesNew)
        {
            try
            {
                SHA256Managed md = new SHA256Managed();
                byte[] digest = md.ComputeHash(bytesNew);
                byte[] digestedBytes = new byte[bytesNew.Length + 32];
                InsertBytes(digestedBytes, 0, digest);
                InsertBytes(digestedBytes, 32, bytesNew);
                return digestedBytes;
            }
            catch (Exception ex)
            {
                ex.GetType();
                return bytesNew;
            }
        }

        private byte[] VerifySha256Digest(byte[] digestedBytes)
        {
            try
            {
                SHA256Managed md = new SHA256Managed();
                byte[] givenDigest = ArrayCopy(digestedBytes, 0, 32);
                byte[] bytes = ArrayCopy(digestedBytes, 32, digestedBytes.Length - 32);
                byte[] digest = md.ComputeHash(bytes);
                if (ArraysMatch(digest, givenDigest))
                    return bytes;
                else
                    System.Windows.Forms.MessageBox.Show("Digest did not match");
            }
            catch (Exception ex)
            {
                ex.GetType();
            }
            return new byte[0];
        }
    }
}
