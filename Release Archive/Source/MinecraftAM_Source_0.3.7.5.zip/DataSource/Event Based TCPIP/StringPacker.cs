﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Text.RegularExpressions;

///// <summary>
///// Marks the end of a string by duplicating all existing '$' in the string and adding a single '$' to the end.
///// </summary>
//public class StringPacker
//{
//    /// <summary>
//    /// Duplicates all '$' and adds one '$' to the end of the string to mark its end.  Also adds a ' ' to the beginning to mark the beginning.
//    /// </summary>
//    /// <param name="s">The string to "pack"</param>
//    /// <returns>The packed string</returns>
//    public static string Pack(string s)
//    {
//        if (string.IsNullOrEmpty(s))
//            return "";
//        return " " + s.Replace("$", "$$") + "$";
//    }
//    /// <summary>
//    /// Adds to [strings] all unpacked strings from [s].  The returned strings will be in the original form that they were sent in.  The return value is any remaining unmatched string.  The return value should be appended to the next string to be unpacked from this source.
//    /// </summary>
//    /// <param name="s">The string to unpack.</param>
//    /// <param name="strings">The list which will be populated with unpacked strings.</param>
//    /// <returns>The return value is any remaining unmatched string remaining in s after the valid strings are unpacked.</returns>
//    public static string Unpack(string s, out List<string> strings)
//    {
//        //Regex rx = new Regex("((\\$\\$)|[^$])+?\\$(?!\\$)", RegexOptions.Singleline);
//        StringBuilder sb = new StringBuilder();
//        strings = new List<string>();
//        s = s.TrimEnd('\0');
//        //Match m = rx.Match(s);

//        // Here I am trusting that only "Packed" strings are sent to the server
//        // If a string does not begin correctly, or if it exceeds the maximum string
//        // size, the entirety of [s] will be cleared and parsing of s will end.
//        //
//        // Individual strings which loop from one buffer into the next will be returned 
//        // and will be appended to the beginning of the next data received.
//        if (s.Length < 1 || s[0] != ' ' || s.Length > 25000000)
//            return "";

//        int i = 1;

//        while (i < s.Length)
//        {
//            // Append characters onto [sb] until [s] is empty or we find a $.
//            for (; i < s.Length && s[i] != '$'; i++)
//                sb.Append(s[i]);

//            // I could have gotten here because I have already appended the last character 
//            // onto [sb] (and it was not a $), or because s[i] is a $.
//            if (i < s.Length)
//            {
//                // I must have found a $. Either the $ I read was the end of [s] or not.
//                i++;
//                if (i < s.Length)
//                {
//                    // There is more text. See if this is a legit $ or the end of a string
//                    if (s[i] == '$')
//                    {
//                        // Go on.
//                        sb.Append('$');
//                    }
//                    else if (s[i] == ' ')
//                    {
//                        // The $ was the end of a string.
//                        strings.Add(sb.ToString());
//                        sb = new StringBuilder();
//                    }
//                    else
//                    {
//                        // There was a single $ not followed by a $ or space!
//                        Console.WriteLine("StringPacker.Unpack error: Single $ found not followed by a $ or a space.");
//                        return "";
//                    }
//                }
//                else
//                {
//                    // That $ was the end of [s]. Yay!
//                    strings.Add(sb.ToString());
//                    sb = new StringBuilder();
//                    return "";
//                }
//            }
//            else
//            {
//                // That was the end.  I have leftovers to return.
//                return " " + sb.ToString();
//            }
//            // Increment i so that on the next loop iteration we start on a fresh character.
//            i++;
//        }
//        return "";
//    }
//}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

/// <summary>
/// Marks the end of a string by duplicating all existing '$' in the string and adding a single '$' to the end.
/// </summary>
public class StringPacker
{
    public static int parseerrors = 0;
    public static int parseerrorsType2 = 0;
    public static int existing255s = 0;
    private static char endMark = (char)255;
    /// <summary>
    /// Adds char 255 to the end of the string.
    /// </summary>
    /// <param name="s">The string to "pack"</param>
    /// <returns>The packed string</returns>
    public static string Pack(string s)
    {
        if (string.IsNullOrEmpty(s))
            return "";
        existing255s += count(s, endMark);
        return s + endMark;
    }
    private static int count(string s, char c)
    {
        int cnt = 0;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == c)
                cnt++;
        }
        return cnt;
    }
    /// <summary>
    /// Adds to [strings] all unpacked strings from [s].  The returned strings will be in the original form that they were sent in.  The return value is any remaining unmatched string.  The return value should be appended to the next string to be unpacked from this source.
    /// </summary>
    /// <param name="s">The string to unpack.</param>
    /// <param name="strings">The list which will be populated with unpacked strings.</param>
    /// <returns>The return value is any remaining unmatched string remaining in s after the valid strings are unpacked.</returns>
    public static string Unpack(string s, out List<string> strings)
    {
        StringBuilder sb = new StringBuilder();
        strings = new List<String>();
        //string t = s.TrimEnd('\0'); <-- This SOB has given us more hell than I care to admit.

        if (s.Length < 1)
        {
            parseerrors++;
            return "";
        }

        for (int i = 0; i < s.Length; i++)
        {
            char next = s[i];
            if (next == endMark)
            {
                strings.Add(sb.ToString());
                sb = new StringBuilder();
            }
            else
                sb.Append(next);
        }
        return sb.ToString();
    }
}


