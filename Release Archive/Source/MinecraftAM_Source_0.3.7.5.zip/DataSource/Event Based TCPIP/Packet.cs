﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataSource
{
    public class Packet
    {
        public byte[] bytes;

        public Packet(byte[] bytes)
        {
            this.bytes = bytes;
        }
    }
}
