﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Net;
namespace DataSource
{
    #region Client
    public abstract class EventTcpClient
    {
        public static int allRequestCnt = 0;
        public static int allRequestSendCnt = 0;
        public static int allRecptCnt = 0;
        public static int allRecptDeliveredCnt = 0;
        public static int bufferSize = 1048576;
        public static int recvChars = 0;
        public static int sendChars = 0;
        #region Events
        #region OnRefused
        /// <summary>
        /// 
        /// </summary>
        public delegate void OnRefusedEventHandler();
        /// <summary>
        /// This event is raised when a connection is refused (server not running).
        /// </summary>
        public event OnRefusedEventHandler OnRefused;
        /// <summary>
        /// This function raises the OnRefused event.
        /// </summary>
        protected void RaiseRefused()
        {
            if (OnRefused != null)
                OnRefused();
        }
        #endregion
        #region OnConnect
        /// <summary>
        /// This event handler handles the OnConnect event.
        /// </summary>
        public delegate void OnConnectEventHandler();
        /// <summary>
        /// This event is raised when a connection is established.
        /// </summary>
        public event OnConnectEventHandler OnConnect;
        /// <summary>
        /// This function raises the OnConnect event.
        /// </summary>
        protected virtual void RaiseConnect()
        {
            if (OnConnect != null)
                OnConnect();
        }
        #endregion
        #region OnDisconnect
        /// <summary>
        /// This event handler handles the OnDisconnect event.
        /// </summary>
        public delegate void OnDisconnectEventHandler();
        /// <summary>
        /// This event is raised when the connection is closed.
        /// </summary>
        public event OnDisconnectEventHandler OnDisconnect;
        /// <summary>
        /// This function raises the OnDisconnect event.
        /// </summary>
        protected virtual void RaiseDisconnect()
        {
            if (OnDisconnect != null)
                OnDisconnect();
        }
        #endregion
        #endregion
        #region Globals / Constructor
        protected object ClientLock = new object();
        protected TcpClient tcpc;
        protected Thread tReceive;
        protected Thread tSend;
        protected volatile bool bAbort = false;
        protected List<byte[]> messagesToSend;
        public EventTcpClient()
        {
            messagesToSend = new List<byte[]>();
        }
        public bool Connected
        {
            get
            {
                try
                {
                    return SocketConnected();
                }
                catch (Exception) { }
                return false;
            }
        }
        #endregion
        #region Connect / Disconnect
        public void Connect(string host = "localhost", ushort port = 50191)
        {
            try
            {
                lock (ClientLock)
                    if (tcpc != null && SocketConnected()) return;
                tReceive = new Thread(ReceiveThread);
                tReceive.Name = "Receive Thread";
                tReceive.Start(new object[] { host, port });
            }
            catch (Exception) { }
        }
        protected bool SocketConnected()
        {
            lock (ClientLock)
                return tcpc != null && tcpc.IsConnected();
        }
        public void Disconnect()
        {
            try
            {
                bAbort = true;
                if (tReceive != null)
                    tReceive.Abort();
                if (tSend != null)
                    tSend.Abort();
                if (tcpc != null)
                    tcpc.Close();
            }
            catch (Exception) { }
            RaiseDisconnect();
        }
        #endregion
        #region Send / Receive
        protected void ReceiveThread(object param)
        {
            try
            {
                object[] parameters = (object[])param;
                string host = (string)parameters[0];
                ushort port = (ushort)parameters[1];
                lock (messagesToSend)
                {
                    messagesToSend.Clear();
                    tcpc = new TcpClient(host, port);
                    tcpc.ReceiveBufferSize = bufferSize;
                    tcpc.SendBufferSize = bufferSize;
                    //NoDelay = true;
                }
                RaiseConnect();
                tSend = new Thread(SendThread);
                tSend.Name = "Send Thread";
                tSend.Start();
                NetworkStream ns = tcpc.GetStream();
                byte[] bytes = new byte[tcpc.ReceiveBufferSize];
                while (SocketConnected() && !bAbort)
                {
                    while (!bAbort && tcpc.Available == 0)
                        Thread.Sleep(1);
                    if (tcpc.Available == 0)
                        break;
                    if (bytes.Length != Math.Min(tcpc.Available, tcpc.ReceiveBufferSize))
                        bytes = new byte[Math.Min(tcpc.Available, tcpc.ReceiveBufferSize)];
                    int read = ns.Read(bytes, 0, bytes.Length);
                    if (read > 0)
                    {
                        recvChars += read;
                        allRecptCnt++;
                        HandleReceivedData(bytes);
                    }
                }
            }
            catch (SocketException ex)
            {
                if (ex.ErrorCode == 10061)
                {
                    // Connection was actively refused
                    RaiseRefused();
                    return;
                }
                Console.Error.WriteLine(ex.ToString());
            }
            catch (Exception ex)
            {
                if (ex.Message == "Cannot access a disposed object.\r\nObject name: 'System.Net.Sockets.Socket'.")
                {
                    Console.Error.WriteLine(ex.ToString());
                    // We have been disconnected (This can happen when the Disconnect() function is called)
                }
                else { }
                Console.Error.WriteLine(ex.ToString());
            }
            Disconnect();
        }
        protected void SendThread()
        {
            try
            {
                NetworkStream ns = tcpc.GetStream();
                List<byte[]> messageCache = new List<byte[]>();
                while (!bAbort)
                {
                    lock (messagesToSend)
                    {
                        if (messagesToSend.Count > 0)
                        {
                            for (int i = 0; i < messagesToSend.Count; i++)
                            {
                               byte[] temp = new byte[messagesToSend[i].Length];
                               messagesToSend[i].CopyTo(temp, 0);
                               messageCache.Add(temp);
                            }
                            messagesToSend.Clear();
                        }
                    }
                    for (int i = 0; i < messageCache.Count; i++)
                    {
                        allRequestSendCnt++;
                        //if (allRequestSendCnt % 5 == 0)
                        //      Thread.Sleep(1);
                        sendChars += messageCache[i].Length;
                        ns.Write(messageCache[i], 0, messageCache[i].Length);
                    }
                    if (messageCache.Count > 0)
                        messageCache.Clear();
                    Thread.Sleep(1);
                }

            }
            catch (SocketException ex)
            {
                Console.Error.WriteLine(ex.ToString());
            }
            catch (Exception ex)
            {
                // Happens on disconnect: Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host.
                Console.Error.WriteLine(ex.ToString());
            }
            Disconnect();
        }
        protected abstract void HandleReceivedData(byte[] bytes);
        protected void SendToServer(byte[] message)
        {
            try
            {
                lock (messagesToSend)
                    messagesToSend.Add(message);
                allRequestCnt++;
            }
            catch (Exception) { }
        }
        #endregion
    }
    public class BytesEventTcpClient : EventTcpClient
    {
        #region OnDataReceived
        /// <summary>
        /// </summary>
        public delegate void BytesReceivedEventHandler(byte[] bytes);
        /// <summary>
        /// This event is raised when data is received.
        /// </summary>
        public event BytesReceivedEventHandler OnDataReceived;
        /// <summary>
        /// This function raises the OnDataReceived event.
        /// </summary>
        protected void RaiseDataReceived(byte[] bytes)
        {
            //byte[] copiedBytes = new byte[bytes.Length];
            // bytes.CopyTo(copiedBytes, 0);
            if (OnDataReceived != null)
                OnDataReceived(bytes);
        }
        #endregion
        #region Globals/Constructor
        List<Packet> packetList;
        PacketPacker packer;
        public BytesEventTcpClient()
            : base()
        {
            packer = new PacketPacker();
            packetList = new List<Packet>();
        }
        #endregion
        #region HandleReceivedData, Send Functions
        protected override void HandleReceivedData(byte[] bytes)
        {
            packer.Unpack(bytes, ref packetList);
            for (int i = 0; i < packetList.Count; i++)
                RaiseDataReceived(packetList[i].bytes);
            packetList.Clear();
        }
        public void Send(byte[] data)
        {
            byte[] sendData = packer.Pack(data);
            SendToServer(sendData);
        }
        #endregion
    }
    public class StringEventTcpClient : EventTcpClient
    {
        #region OnDataReceived
        /// <summary>
        /// </summary>
        public delegate void StringReceivedEventHandler(string message);
        /// <summary>
        /// This event is raised when data is received.
        /// </summary>
        public event StringReceivedEventHandler OnDataReceived;
        /// <summary>
        /// This function raises the OnDataReceived event.
        /// </summary>
        protected void RaiseDataReceived(string message)
        {
            if (OnDataReceived != null)
                OnDataReceived(message);
        }
        #endregion
        #region Globals/Constructor
        object LeftoversLock = new object();
        string sLeftovers = "";
        public StringEventTcpClient()
            : base()
        {
        }
        #endregion
        #region HandleReceivedData, Send Functions
        protected override void HandleReceivedData(byte[] bytes)
        {
            lock (LeftoversLock)
            {
                try
                {
                    List<string> strings;
                    sLeftovers = sLeftovers + Encoding.Default.GetString(bytes);
                    sLeftovers = StringPacker.Unpack(sLeftovers, out strings);
                    for (int i = 0; i < strings.Count; i++)
                    {
                        EventTcpClient.allRecptDeliveredCnt++;
                        RaiseDataReceived(strings[i]);
                    }
                }
                catch (Exception) { }
            }
        }
        public void Send(string message)
        {
            SendToServer(System.Text.Encoding.Default.GetBytes(StringPacker.Pack(message)));
        }
        #endregion
    }
    #endregion
    #region Server
    public abstract class EventTcpServer
    {
        #region Events
        #region OnDataSent
        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sender">The object which raised the event.</param>
        ///// <param name="e"></param>
        //public delegate void OnDataSentEventHandler(object sender, DataSentArgs e);
        ///// <summary>
        ///// This event is raised when data is received from the client.
        ///// </summary>
        //public event OnDataSentEventHandler OnDataSent;
        ///// <summary>
        ///// This function raises the OnDataReceived event.
        ///// </summary>
        ///// <param name="e"></param>
        //protected void RaiseDataSent(DataSentArgs e)
        //{
        //    if (OnDataSent != null)
        //        OnDataSent(this, e);
        //}
        #endregion
        #region OnDataReceived
        // This event is to be done entirely in subclasses
        #endregion
        #region OnResolveBegin
        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sender">The object which raised the event.</param>
        ///// <param name="e"></param>
        //public delegate void OnResolveBeginEventHandler(object sender, EventArgs e);
        ///// <summary>
        ///// This event is raised when a hostname must be resolved using dns.
        ///// </summary>
        //public event OnResolveBeginEventHandler OnResolveBegin;
        ///// <summary>
        ///// This function raises the OnResolveBegin event.
        ///// </summary>
        ///// <param name="e"></param>
        //protected void RaiseResolveBegin(EventArgs e)
        //{
        //    if (OnResolveBegin != null)
        //        OnResolveBegin(this, e);
        //}
        #endregion
        #region OnResolveEnd
        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sender">The object which raised the event.</param>
        ///// <param name="e"></param>
        //public delegate void OnResolveEndEventHandler(object sender, ResolveEndArgs e);
        ///// <summary>
        ///// This event is raised when a hostname is resolved using dns.
        ///// </summary>
        //public event OnResolveEndEventHandler OnResolveEnd;
        ///// <summary>
        ///// This function raises the OnResolveEnd event.
        ///// </summary>
        ///// <param name="e"></param>
        //protected void RaiseResolveEnd(ResolveEndArgs e)
        //{
        //    if (OnResolveEnd != null)
        //        OnResolveEnd(this, e);
        //}
        #endregion
        #region OnClientConnect
        /// <summary>
        /// This event handler handles the OnClientConnect event.
        /// </summary>
        /// <param name="sender">The object which raised the event.</param>
        /// <param name="e"></param>
        public delegate void OnClientConnectEventHandler(string clientKey);
        /// <summary>
        /// This event is raised when a client connection is created.
        /// </summary>
        public event OnClientConnectEventHandler OnClientConnect;
        /// <summary>
        /// This function raises the OnClientConnect event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void RaiseClientConnect(string clientKey)
        {
            if (OnClientConnect != null)
                OnClientConnect(clientKey);
        }
        #endregion
        #region OnDisconnect
        /// <summary>
        /// This event handler handles the OnDisconnect event.
        /// </summary>
        /// <param name="sender">The object which raised the event.</param>
        /// <param name="e"></param>
        public delegate void OnDisconnectEventHandler(string clientKey);
        /// <summary>
        /// This event is raised when a client connection is closed.
        /// </summary>
        public event OnDisconnectEventHandler OnClientDisconnect;
        /// <summary>
        /// This function raises the OnDisconnect event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void RaiseClientDisconnect(string clientKey)
        {
            if (OnClientDisconnect != null)
                OnClientDisconnect(clientKey);
        }
        #endregion
        #region OnListenStop
        /// <summary>
        /// This event handler handles the OnListenStop event.
        /// </summary>
        /// <param name="sender">The object which raised the event.</param>
        /// <param name="e"></param>
        public delegate void OnListenStopEventHandler();
        /// <summary>
        /// This event is raised when the server stops listening.
        /// </summary>
        public event OnListenStopEventHandler OnListenStop;
        /// <summary>
        /// This function raises the OnListenStop event.
        /// </summary>
        /// <param name="e"></param>
        protected virtual void RaiseListenStop()
        {
            if (OnListenStop != null)
                OnListenStop();
        }
        #endregion
        #endregion
        #region Globals/Constructor
        protected object ListenerStartStopLock = new object();
        // USE TCPCLIENT and TCPLISTENER
        protected Thread tListen;
        protected TcpListener tcpl;
        protected SortedList<string, ClientThreadPack> clientList;
        protected IPAddress address = IPAddress.Any;
        protected volatile bool bListening = false;
        public bool Listening
        {
            get { return bListening; }
        }
        public EventTcpServer()
        {
            clientList = new SortedList<string, ClientThreadPack>();
        }
        #endregion
        #region Listen
        public void Listen(IPAddress ip = null, ushort port = 58910)
        {
            if (bListening) return;
            lock (clientList)
                clientList.Clear();
            if (ip == null) ip = IPAddress.Any;
            tListen = new Thread(ListenThread);
            tListen.Start(new object[] { ip, port });
        }
        public void StopListening()
        {
            lock (ListenerStartStopLock)
            {
                bListening = false;
                tcpl.Stop();
            }
        }
        // Listen Loop
        protected void ListenThread(object param)
        {
            try
            {
                object[] parameters = (object[])param;
                IPAddress ip = (IPAddress)parameters[0];
                ushort port = (ushort)parameters[1];
                IPEndPoint ipep = new IPEndPoint(ip, port);
                lock (ListenerStartStopLock)
                {
                    if (tcpl == null)
                    {
                        tcpl = new TcpListener(ipep);
                        tcpl.AllowNatTraversal(true);
                    }
                    bListening = true;
                    tcpl.Start(10);
                }
            }
            catch (SocketException ex)
            {
                bListening = false;
                ex.ToString();
                try
                {
                    if (tcpl != null)
                        tcpl.Stop();
                }
                catch (Exception) { }
                RaiseListenStop();
                return;
            }
            catch (Exception ex)
            {
                bListening = false;
                ex.ToString();
                try
                {
                    if (tcpl != null)
                        tcpl.Stop();
                }
                catch (Exception) { }
                RaiseListenStop();
                return;
            }
            TcpClient client = null;
            string key = "";
            try
            {
                while (bListening)
                {
                    client = null;
                    key = "";
                    client = tcpl.AcceptTcpClient();
                    key = client.Client.RemoteEndPoint.ToString();
                    Thread clientThread;
                    Thread clientSendThread;
                    lock (clientList)
                    {
                        if (clientList.ContainsKey(key))
                        {
                            client.Close();
                            continue;
                        }
                        clientThread = new Thread(ClientThread);
                        clientSendThread = new Thread(ClientSendThread);
                        clientList.Add(key, new ClientThreadPack(clientThread, clientSendThread, client, key));
                    }
                    clientThread.Start(key);
                    clientSendThread.Start(key);
                    RaiseClientConnect(key);
                }
            }
            catch (SocketException ex)
            {
                if (ex.ErrorCode == 10004)
                {
                    // TcpListener Stop function was called while waiting for a client to connect
                }
                ex.ToString();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            bListening = false;
            try
            {
                if (tcpl != null)
                    tcpl.Stop();
            }
            catch (Exception) { }
            if (client != null)
            {
                client.Close();
                lock (clientList)
                    if (clientList.ContainsKey(key))
                        clientList.Remove(key);
                RaiseClientDisconnect(key);
            }
            DisconnectAllClients();
            RaiseListenStop();
        }
        #endregion
        #region Client Handling Threads / Functions
        protected void ClientThread(object param)
        {
            ClientThreadPack ctp = null;
            string myKey = "";
            try
            {
                myKey = (string)param;
                lock (clientList)
                {
                    if (!clientList.ContainsKey(myKey))
                        return;
                    ctp = clientList[myKey];
                }
                NetworkStream ns = ctp.client.GetStream();
                byte[] bytes = new byte[ctp.client.ReceiveBufferSize];
                //bool bytesRead = false;
                while (bListening)
                {
                    while (bListening && !ctp.Abort && ctp.Connected && ctp.client.Available == 0)
                        Thread.Sleep(0);
                    if (ctp.client.Available == 0)
                        break;
                    if (bytes.Length != Math.Min(ctp.client.Available, ctp.client.ReceiveBufferSize))
                        bytes = new byte[Math.Min(ctp.client.Available, ctp.client.ReceiveBufferSize)];
                    if (ns.Read(bytes, 0, bytes.Length) > 0)
                        HandleReceivedData(bytes, myKey);
                }
            }
            catch (SocketException ex)
            {
                ex.ToString();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            if (ctp != null)
            {
                ctp.Abort = true;
                ctp.client.Close();
            }
            lock (clientList)
                if (clientList.ContainsKey(myKey))
                    clientList.Remove(myKey);
            RaiseClientDisconnect(myKey);
        }
        protected void ClientSendThread(object param)
        {
            ClientThreadPack ctp = null;
            string myKey = "";
            bool bMessagesSentThisLoop = false;
            try
            {
                myKey = (string)param;
                lock (clientList)
                {
                    if (!clientList.ContainsKey(myKey))
                        return;
                    ctp = clientList[myKey];
                }
                NetworkStream ns = ctp.client.GetStream();
                while (bListening && !ctp.Abort)
                {
                    lock (ctp.messagesToSend)
                        if (ctp.messagesToSend.Count > 0)
                        {
                            bMessagesSentThisLoop = true;
                            for (int i = 0; i < ctp.messagesToSend.Count; i++)
                                ns.Write(ctp.messagesToSend[i], 0, ctp.messagesToSend[i].Length);
                            ctp.messagesToSend.Clear();
                        }
                        else
                            bMessagesSentThisLoop = false;

                    if (!bMessagesSentThisLoop)
                        Thread.Sleep(0);
                }
            }
            catch (SocketException ex)
            {
                ex.ToString();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            if (ctp != null)
                ctp.client.Close();
            ctp.Abort = true;
        }
        protected abstract void HandleReceivedData(byte[] bytes, string key);
        protected void SendToClient(string key, byte[] message)
        {
            ClientThreadPack ctp = null;
            try
            {
                lock (clientList)
                {
                    if (!clientList.ContainsKey(key))
                        return;
                    ctp = clientList[key];
                }
                lock (ctp.messagesToSend)
                    ctp.messagesToSend.Add(message);
            }
            catch (Exception) { }
        }
        private void DisconnectAllClients()
        {
            lock (clientList)
            {
                foreach (ClientThreadPack ctp in clientList.Values)
                {
                    ctp.client.Close();
                    RaiseClientDisconnect(ctp.key);
                }
            }
        }
        #endregion
    }
    public class BytesEventTcpServer : EventTcpServer
    {
        #region OnDataReceived
        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void BytesReceivedEventHandler(string senderKey, byte[] bytes);
        /// <summary>
        /// This event is raised when data is received.
        /// </summary>
        public event BytesReceivedEventHandler OnDataReceived;
        /// <summary>
        /// This function raises the OnDataReceived event.
        /// </summary>
        /// <param name="e"></param>
        protected void RaiseDataReceived(string senderKey, byte[] bytes)
        {
            //byte[] copiedBytes = new byte[bytes.Length];
            //bytes.CopyTo(copiedBytes, 0);
            if (OnDataReceived != null)
                OnDataReceived(senderKey, bytes);
        }
        #endregion
        #region Globals/Constructor
        List<Packet> packetList;
        PacketPacker packer;
        public BytesEventTcpServer()
            : base()
        {
            packer = new PacketPacker();
            packetList = new List<Packet>();
        }
        #endregion
        #region HandleReceivedData, Send Functions
        protected override void HandleReceivedData(byte[] bytes, string key)
        {
            packer.Unpack(bytes, ref packetList);
            for (int i = 0; i < packetList.Count; i++)
                RaiseDataReceived(key, packetList[i].bytes);
            packetList.Clear();
        }
        public void Send(string clientKey, byte[] data)
        {
            byte[] sendData = packer.Pack(data);
            SendToClient(clientKey, sendData);
        }
        #endregion
    }
    public class StringEventTcpServer : EventTcpServer
    {
        #region OnDataReceived
        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void StringReceivedEventHandler(string senderKey, string message);
        /// <summary>
        /// This event is raised when data is received.
        /// </summary>
        public event StringReceivedEventHandler OnDataReceived;
        /// <summary>
        /// This function raises the OnDataReceived event.
        /// </summary>
        /// <param name="e"></param>
        protected void RaiseDataReceived(string senderKey, string message)
        {
            if (OnDataReceived != null)
                OnDataReceived(senderKey, message);
        }
        #endregion
        #region Globals/Constructor
        SortedList<string, string> slLeftovers;
        public StringEventTcpServer()
            : base()
        {
            slLeftovers = new SortedList<string, string>();
        }
        #endregion
        #region HandleReceivedData, Send Functions
        protected override void HandleReceivedData(byte[] bytes, string key)
        {
            lock (slLeftovers)
            {
                if (!slLeftovers.ContainsKey(key))
                    slLeftovers.Add(key, "");
                List<string> strings;
                string sReceived = slLeftovers[key] + Encoding.Default.GetString(bytes);
                slLeftovers[key] = StringPacker.Unpack(sReceived, out strings);
                for (int i = 0; i < strings.Count; i++)
                    RaiseDataReceived(key, strings[i]);
            }
        }

        public void Send(string clientKey, string message)
        {
            SendToClient(clientKey, System.Text.Encoding.Default.GetBytes(StringPacker.Pack(message)));
        }
        #endregion
    }
    #endregion
    #region Helper Classes
    public class ClientThreadPack
    {
        public string key;
        public Thread readingThread;
        public Thread sendingThread;
        public TcpClient client;
        public List<byte[]> messagesToSend;
        public bool Abort = false;
        public bool Connected
        {
            get
            {
                try
                {
                    return client.IsConnected();
                }
                catch (Exception) { return false; }
            }
        }
        public ClientThreadPack(Thread rt, Thread st, TcpClient c, string k)
        {
            readingThread = rt;
            sendingThread = st;
            client = c;
            key = k;
            messagesToSend = new List<byte[]>();
        }
    }
    public static class SocketExtensions
    {
        public static bool IsConnected(this TcpClient client)
        {
            if (client == null)
                return false;
            if (client.Connected == false)
                return false;
            try
            {
                return true;// return !(client.Available == 0 && client.Client.Poll(100, SelectMode.SelectRead));
            }
            catch (SocketException) { return false; }
            catch (Exception) { return false; }
        }
    }
    #endregion
}
