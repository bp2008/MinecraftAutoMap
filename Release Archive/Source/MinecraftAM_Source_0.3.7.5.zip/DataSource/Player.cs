﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataSource
{
    public class Player
    {
        public static int chunkSizeM1;
        public static int tileWidth;
        public static int tileHeight;
        public string name = "default";
        public double x = 0;
        public double y = 0;
        public double z = 0;
        public int ix = 0;
        public int iy = 0;
        public int iz = 0;
        public double pixelx = 0;
        public double pixely = 0;
        public double rotation = 0;
        public float pitch = 0;
        public Player()
        {
        }
        //public Player(string name, double x, double y, double z, float rotation, float pitch)
        //{
        //    this.name = name;
        //    this.x = x;
        //    this.y = y;
        //    this.z = z;
        //    this.pitch = pitch;
        //}
        public void Calc()
        {
            ix = (int)Math.Floor(x);
            iy = (int)Math.Floor(y);
            iz = (int)Math.Floor(z);
            this.pixelx = x + chunkSizeM1;
            this.pixelx *= tileWidth;
            this.pixely = y * tileHeight;
            this.rotation = (Math.PI / 180) * (rotation - 90);
        }
        public double ChangeAmount(Player comparedTo)
        {
            double changeAmount = 0;
            changeAmount += Math.Abs(this.x - comparedTo.x);
            changeAmount += Math.Abs(this.y - comparedTo.y);
            changeAmount += 0.3 * (Math.Abs(this.z - comparedTo.z) / 128);
            changeAmount += 0.3 * (Math.Abs(this.pitch - comparedTo.pitch) / 5000);
            changeAmount += Math.Min(0.3, Math.Abs(this.pitch - comparedTo.pitch) / 100);
            changeAmount += Math.Min(0.3, Math.Abs(this.rotation - comparedTo.rotation) / 360);
            return changeAmount;
        }
    }
}
