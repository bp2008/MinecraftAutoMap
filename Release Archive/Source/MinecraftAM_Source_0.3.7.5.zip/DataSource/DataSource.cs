﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel;

namespace DataSource
{
    public class DS
    {
        //private static int SHORT_BYTES = 2;
        private static int INT_BYTES = 4;
        //private static int LONG_BYTES = 8;
        private static int FLOAT_BYTES = 4;
        private static int DOUBLE_BYTES = 8;
        private static byte GET_PLAYER_LOCATION = 0;
        private static byte GET_WORLD_CHUNK = 1;
        //private static byte GET_FULL_COLUMN = 2;
        private static byte GET_WORLD_PATH = 20;
        /// <summary>
        /// True if connected.
        /// </summary>
        public static bool isConnected
        {
            get
            {
                return client != null && client.Connected;
            }
        }
        public static void ShutDown()
        {
            shuttingDown = true;
            client.Disconnect();
        }
        private static bool shuttingDown = false;
        protected static BytesEventTcpClient client;
        protected static DSHandlerPlayerLocation playerLocationHandler;
        public static void InitializePlayerLocation(DSHandlerPlayerLocation handlerparam, int tileWidth, int tileHeight, int chunkSize)
        {
            playerLocationHandler = handlerparam;
            Player.chunkSizeM1 = chunkSize - 1;
            Player.tileHeight = tileHeight;
            Player.tileWidth = tileWidth;
        }
        protected static DSHandlerChunk chunkHandler;
        public static void InitializeChunks(DSHandlerChunk handlerparam)
        {
            chunkHandler = handlerparam;
        }
        protected static DSHandlerWorldPath worldPathHandler;
        public static void InitializeWorldPath(DSHandlerWorldPath handlerparam)
        {
            worldPathHandler = handlerparam;
        }
        //public static string url = "http://localhost:8080/MCAutomapSrv/AutomapChunk";
        /// <summary>
        /// Requests from the Minecraft Client a chunk of custom location and size.
        /// </summary>
        /// <param name="x">X coordinate</param>
        /// <param name="y">Y coordinate</param>
        /// <param name="z">Z coordinate</param>
        /// <param name="dx">Distance to grab from the X coordinate. (Width)</param>
        /// <param name="dy">Distance to grab from the Y coordinate. (Height)</param>
        /// <param name="dz">Distance to grab from the Z coordinate. (Depth)</param>
        public static void GetChunkData(int x, int y, int z, int dx, int dy, int dz)
        {
            if (isConnected)
            {
                byte[] bytes = new byte[(INT_BYTES * 6) + 1];
                int i = 0;
                bytes[i] = GET_WORLD_CHUNK;
                i++;
                InsertBytes(bytes, i, ByteConverter.GetBytes(x)); // X
                i += INT_BYTES;
                InsertBytes(bytes, i, ByteConverter.GetBytes(y)); // Y
                i += INT_BYTES;
                InsertBytes(bytes, i, ByteConverter.GetBytes(z)); // Z
                i += INT_BYTES;
                InsertBytes(bytes, i, ByteConverter.GetBytes(dx)); // DX
                i += INT_BYTES;
                InsertBytes(bytes, i, ByteConverter.GetBytes(dy)); // DY
                i += INT_BYTES;
                InsertBytes(bytes, i, ByteConverter.GetBytes(dz)); // DZ
                client.Send(bytes);
            }
        }

        /// <summary>
        /// Requests from the Minecraft Client the player's location.
        /// </summary>
        public static void GetPlayerLocation()
        {
            if (isConnected)
            {
                client.Send(new byte[] { GET_PLAYER_LOCATION });
            }
        }
        /// <summary>
        /// Requests from the Minecraft Client the player's location.
        /// </summary>
        public static void GetWorldPath()
        {
            if (isConnected)
            {
                client.Send(new byte[] { GET_WORLD_PATH });
            }
        }

        /// <summary>
        /// Handles a message received from the Minecraft Client.
        /// </summary>
        /// <param name="message">The string received from the Minecraft Client.</param>
        private static void HandleMessage(byte[] message)
        {
            if (message.Length <= 0)
                return;
            byte messageType = message[0];
            if (messageType == GET_PLAYER_LOCATION)
            {
                HandlePlayerLocation(message);
            }
            else if (messageType == GET_WORLD_CHUNK)
            {
                HandleWorldChunk(message);
            }
            else if (messageType == GET_WORLD_PATH)
            {
                HandleWorldPath(message);
            }
        }

        private static void HandlePlayerLocation(byte[] message)
        {
            try
            {
                if (playerLocationHandler == null)
                    return;
                SortedList<string, Player> players = new SortedList<string, Player>();
                int reqIdx = 1;
                int sizeOfPlayerName = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                string playerName = ByteConverter.ToString(message, reqIdx, sizeOfPlayerName);
                reqIdx += sizeOfPlayerName;
                while (reqIdx < message.Length)
                {
                    Player p = new Player();
                    p.x = ByteConverter.ToDouble(message, reqIdx);
                    reqIdx += DOUBLE_BYTES;
                    p.y = ByteConverter.ToDouble(message, reqIdx);
                    reqIdx += DOUBLE_BYTES;
                    p.z = ByteConverter.ToDouble(message, reqIdx);
                    reqIdx += DOUBLE_BYTES;
                    p.rotation = ByteConverter.ToSingle(message, reqIdx);
                    reqIdx += FLOAT_BYTES;
                    p.pitch = ByteConverter.ToSingle(message, reqIdx);
                    reqIdx += FLOAT_BYTES;
                    int namesize = ByteConverter.ToInt32(message, reqIdx);
                    reqIdx += INT_BYTES;
                    p.name = ByteConverter.ToString(message, reqIdx, namesize);
                    reqIdx += namesize;
                    p.Calc();
                    players.Add(p.name, p);
                }
                playerLocationHandler.PlayerLocationReceived(players, playerName);
            }
            catch (Exception ex)
            {
                Eat(ex);
                return;
            }
        }
        private static void Eat(Exception ex)
        {
            System.Windows.Forms.MessageBox.Show("OMG an exception in the Socket communication.  What a surprise!" + Environment.NewLine + ex.Message + Environment.NewLine + ex.StackTrace);
        }
        #region Handle Messages
        private static void HandleWorldChunk(byte[] message)
        {
            try
            {
                if (chunkHandler == null)
                    return;
                int originalRequestLength = (INT_BYTES * 6) + 1;
                if (message.Length < originalRequestLength)
                    return;
                int x, y, z, dx, dy, dz, reqIdx = 1;
                x = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                y = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                z = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                dx = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                dy = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                dz = ByteConverter.ToInt32(message, reqIdx);
                reqIdx += INT_BYTES;
                int chunklength = dx * dy * dz;
                if (chunklength + originalRequestLength != message.Length)
                    return;
                byte[] newChunkData = new byte[chunklength];
                Array.Copy(message, originalRequestLength, newChunkData, 0, chunklength);
                chunkHandler.WorldChunkReceived(x, y, z, dx, dy, dz, newChunkData);
            }
            catch (Exception ex)
            {
                Eat(ex);
                return;
            }
        }
        private static void HandleWorldPath(byte[] message)
        {
            worldPathHandler.WorldPathReceived(ByteConverter.ToString(message, 1, message.Length - 1));
        }
        #endregion

        #region Helpers
        public static void InsertBytes(byte[] destination, int destinationOffset, byte[] source)
        {
            if (destination.Length - destinationOffset < source.Length)
                return;
            for (int i = 0; i < source.Length; i++, destinationOffset++)
                destination[destinationOffset] = source[i];
        }
        #endregion

        #region Networking
        public static void Connect(string host, ushort port)
        {
            client = new BytesEventTcpClient();
            client.OnConnect += new EventTcpClient.OnConnectEventHandler(client_OnConnect);
            client.OnDataReceived += new BytesEventTcpClient.BytesReceivedEventHandler(client_OnDataReceived);
            client.OnDisconnect += new EventTcpClient.OnDisconnectEventHandler(client_OnDisconnect);
            client.OnRefused += new EventTcpClient.OnRefusedEventHandler(client_OnRefused);
            client.Connect(host, port);
        }

        /// <summary>
        /// Called if a connection is refused (unable to connect).
        /// </summary>
        static void client_OnRefused()
        {
            System.Windows.Forms.MessageBox.Show("Connection refused.  If Minecraft is already running and has been patched by the Minecraft AutoMap installer, make sure your firewall is not blocking communication to and from Minecraft.");
            Console.WriteLine("Connection Refused");

        }

        /// <summary>
        /// Called when we get disconnected.
        /// </summary>
        static void client_OnDisconnect()
        {
            if (!shuttingDown)
                System.Windows.Forms.MessageBox.Show("Disconnected");
            Console.WriteLine("Disconnected");

        }

        /// <summary>
        /// Called when data is received.
        /// </summary>
        /// <param name="message">A byte array that has been received.</param>
        static void client_OnDataReceived(byte[] message)
        {
            HandleMessage(message);
        }

        /// <summary>
        /// Called when we establish a connection.
        /// </summary>
        static void client_OnConnect()
        {
            Console.WriteLine("Connected");
        }
        #endregion
    }
}
