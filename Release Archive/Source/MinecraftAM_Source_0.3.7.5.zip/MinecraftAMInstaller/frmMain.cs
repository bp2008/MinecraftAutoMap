﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using System.Diagnostics;
using System.Threading;
using System.Security.Cryptography;

namespace MinecraftAMInstaller
{
    public partial class frmMain : Form
    {
        // These are now loaded from the file "patchCfg"
        private string classToPatch = "";//"ea.class";
        private string expectedClassFileHash = "";//"F70lHKEO0TcSmAcGnxCFJg=="; // This is the hash of the expected [classToPatch] file.  We use our tiny ComputeHash project to get this.
        public frmMain()
        {
            // Update this with any new files that have to be removed from minecraft.jar
            filesToDelete.Add("META-INF/MOJANG_C.DSA");
            filesToDelete.Add("META-INF/MOJANG_C.SF");


            InitializeComponent();
            if (File.Exists("patchCfg"))
            {
                string cfgBuf = File.ReadAllText("patchCfg");
                if (!string.IsNullOrEmpty(cfgBuf))
                {
                    string[] split = cfgBuf.Split('|');
                    if (split.Length == 2)
                    {
                        classToPatch = split[0];
                        expectedClassFileHash = split[1];
                    }
                }
                Install();
            }
            else
                MessageBox.Show("Unable to find the required file: patchCfg");
            Environment.Exit(0);
        }

        private List<string> filesToDelete = new List<string>();
        private void ExtractFile(ZipFile zf, string filename)
        {
            ZipEntry entry = zf.GetEntry(filename);
            Stream zipinput = zf.GetInputStream(zf.GetEntry(filename));
            byte[] buffer = new byte[entry.Size];
            int bytesRead = 0;
            int bytesReadTotal = 0;
            do
            {
                bytesRead = zipinput.Read(buffer, bytesReadTotal, (int)entry.Size - bytesReadTotal);
                bytesReadTotal += bytesRead;
            } while (bytesRead > 0);
            zipinput.Close();
            if (filename.Contains("/"))
                filename = filename.Remove(0, filename.LastIndexOf("/") + 1);
            File.WriteAllBytes(filename, buffer);
        }
        private void AddDirectory(ZipFile zf, string fullrootpath, string dir)
        {
            DirectoryInfo diRoot = new DirectoryInfo(dir);
            foreach (FileInfo fi in diRoot.GetFiles())
            {
                zf.Add(fi.FullName, fi.FullName.Replace(fullrootpath + "\\", "").Replace("\\", "/"));
            }

            foreach (DirectoryInfo di in diRoot.GetDirectories())
            {
                AddDirectory(zf, fullrootpath, di.FullName);
            }
        }
        private void btnInstall_Click(object sender, EventArgs e)
        {
        }

        private void Install()
        {

            // First find minecraft.jar
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string minecraftFolder = Path.Combine(appData, ".minecraft\\bin");
            if (!File.Exists(Path.Combine(minecraftFolder, "minecraft.jar")))
            {
                MessageBox.Show("Couldn't find minecraft in " + minecraftFolder + ".  Have you run minecraft at least once?");
                return;
            }
            MessageBox.Show("Found minecraft.  Please make sure Minecraft is not running and minecraft.jar is not open in any program.");

            File.Copy(Path.Combine(minecraftFolder, "minecraft.jar"), Path.Combine(Environment.CurrentDirectory, "minecraft.jar"), true);


            ICSharpCode.SharpZipLib.Zip.ZipFile zf = new ICSharpCode.SharpZipLib.Zip.ZipFile("minecraft.jar");
            ExtractFile(zf, classToPatch);
            ExtractFile(zf, "terrain.png");
            ExtractFile(zf, "gui/items.png");

            byte[] usersFileData = File.ReadAllBytes(classToPatch);
            MD5 hasher = MD5.Create();

            byte[] usersFileHash = hasher.ComputeHash(usersFileData);
            byte[] expectedHash = Convert.FromBase64String(expectedClassFileHash);
            bool filesMatch = usersFileHash.Length == expectedHash.Length;
            for (int i = 0; i < usersFileHash.Length; i++)
            {
                if (usersFileHash[i] != expectedHash[i])
                    filesMatch = false;
            }
            string patchFile = classToPatch.Replace(".class", ".ips");
            if (!filesMatch)
                MessageBox.Show("The " + classToPatch + " file from your Minecraft.jar is not the expected original file.  It may be an incompatible version of the game or it may have already been patched.  Skipping patch of this file.  If MinecraftAM doesn't work, try getting a new copy of Minecraft.jar and running PatchMinecraft.exe again.  If MinecraftAM still doesn't work, you probably need a newer version of MinecraftAM.");
            else if (File.Exists("uips.exe") && File.Exists(patchFile))
            {

                Process patcher = Process.Start("uips.exe", "a " + patchFile + " " + classToPatch);
                while (!patcher.HasExited)
                {
                    Thread.Sleep(50);
                }
            }

            if (filesMatch && (!File.Exists("uips.exe") || !File.Exists(patchFile)))
            {
                MessageBox.Show("Could not find either uips.exe or " + patchFile + ".  Unable to install.");
                zf.Close();
                Environment.Exit(0);
            }
            else
            {
                zf.BeginUpdate();
                if (filesMatch)
                    zf.Add(classToPatch);
                foreach (string fName in filesToDelete)
                {
                    ZipEntry ze = zf.GetEntry(fName);
                    if (ze != null)
                        zf.Delete(ze);
                }
                if (Directory.Exists("patch"))
                    AddDirectory(zf, new DirectoryInfo("patch").FullName, "patch");
                try
                {
                    zf.CommitUpdate();
                    zf.Close();
                    File.Delete(classToPatch);
                    int counter = 1;
                    string backupFileNameBase = "minecraft.jar.backup";
                    string backupFileName = backupFileNameBase;
                    while (File.Exists(Path.Combine(minecraftFolder, backupFileName)))
                        backupFileName = backupFileNameBase + (counter++).ToString();
                    File.Copy(Path.Combine(minecraftFolder, "minecraft.jar"), Path.Combine(minecraftFolder, backupFileName));
                    File.Copy(Path.Combine(Environment.CurrentDirectory, "minecraft.jar"), Path.Combine(minecraftFolder, "minecraft.jar"), true);
                    File.Delete(Path.Combine(Environment.CurrentDirectory, "minecraft.jar"));
                    MessageBox.Show("Minecraft.jar has been updated.  A backup of the original file has been created at " + Path.Combine(minecraftFolder, backupFileName) + ". Startup Minecraft, load a world, then run MinecraftAM.exe.  NOTE: Your firewall may ask you to allow Java/Minecraft to access the network.  This is because the mod uses a network socket to communicate with the automap.");
                }
                catch (Exception err)
                {
                    MessageBox.Show("The patch failed.  If Minecraft is running or Minecraft.jar is open in some program, please close it and try again.  Detail: " + err.ToString());
                }
            }
        }
    }
}
