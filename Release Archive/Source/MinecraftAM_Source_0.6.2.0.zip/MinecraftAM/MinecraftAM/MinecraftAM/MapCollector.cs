﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.Collections.Concurrent;

namespace MinecraftAM
{
	public class MapCollector
	{
		WriteableBitmap wbmp = null;
		// Fields unrelated to the current writable bitmap
		public MapFlattener cFlattener = new MapFlattener(true);
		public GraphicsDevice gd = null;
		//Texture2D tex = null;
		int chunkWidth = Chunk.chunkSize;
		int chunkHeight = Chunk.chunkSize;
		public DateTime savedAt = DateTime.Now;
		ConcurrentQueue<KeyValuePair<MCTile[,], IntVector2>> flatChunkQueue;

		volatile bool suspendUpdates = false;
		// Fields related to the current writable bitmap
		bool initialized = false;
		// bmpOffsetX is a number that can be subtracted from "left" to find the coordinate local to wbmp of the leftmost block.
		int bmpOffsetX;
		// bmpOffsetX is a number that can be subtracted from "top" to find the coordinate local to wbmp of the topmost block.
		int bmpOffsetY;
		// bitmapsize is the width and height of the writablebitmap.  wbmp must be square.
		int bitmapsize = 500;
		// top is the block coordinate of the topmost block in the writable bitmap.  ditto for left, right, bottom.
		int top = int.MaxValue, left = int.MaxValue, bottom = int.MinValue, right = int.MinValue; // bounds tracking

		public MapCollector()
		{
			flatChunkQueue = new ConcurrentQueue<KeyValuePair<MCTile[,], IntVector2>>();
			if (!LoadWorldMapFromCache())
				wbmp = new WriteableBitmap(bitmapsize, bitmapsize, 72, 72, System.Windows.Media.PixelFormats.Bgra32, System.Windows.Media.Imaging.BitmapPalettes.Gray16);
		}

		private bool LoadWorldMapFromCache()
		{
			FileInfo fiMap = new FileInfo(Globals.worldID + Globals.worldMapImageExtension);
			FileInfo fiOrigin = new FileInfo(Globals.worldID + "origin.txt");
			if (!fiMap.Exists || !fiOrigin.Exists)
				return false;
			PngBitmapDecoder decoder = null;
			FileStream inputStream = null;
			int tries = 0;
            try
            {
                while (true)
                {
                    try
                    {
                        inputStream = new FileStream(fiMap.FullName, FileMode.Open, FileAccess.Read, FileShare.Read);
                        decoder = new PngBitmapDecoder(inputStream, BitmapCreateOptions.None, BitmapCacheOption.Default);
                        break;
                    }
                    catch (Exception ex)
                    {
                        if (inputStream != null)
                        {
                            File.AppendAllText("errordump.txt", "\r\nUnable to read from map file in MapCollector.LoadWorldMapFromCache: " + ex.ToString() + "\r\n");
                            return false;
                        }
                        if (tries++ >= 10)
                        {
                            File.AppendAllText("errordump.txt", "\r\nUnable to open map file in MapCollector.LoadWorldMapFromCache: " + ex.ToString() + "\r\n");
                        }
                        Thread.Sleep(200);
                    }
                }
                if (inputStream == null || decoder == null)
                    return false;
                try
                {
                    if (decoder.Frames.Count > 0)
                        wbmp = new WriteableBitmap(decoder.Frames[0]);
                    else
                        return false;
                    string mapInfo = File.ReadAllText(fiOrigin.FullName);
                    string[] split = mapInfo.Split('\r');
					string[] splitLoc = split[0].Trim().Split(',');
					string[] splitSize = split[1].Trim().Split('x');
                    int worldMapOriginX = Convert.ToInt32(splitLoc[0]);
                    int worldMapOriginY = Convert.ToInt32(splitLoc[1]);
                    int worldMapWidth = Convert.ToInt32(splitSize[0]);
                    int worldMapHeight = Convert.ToInt32(splitSize[1]);
                    bitmapsize = Math.Max(worldMapWidth, worldMapHeight);
                    top = -worldMapOriginY;
                    left = -worldMapOriginX;
                    right = left + worldMapWidth;
                    bottom = top + worldMapHeight;
                    bmpOffsetX = -left;
                    bmpOffsetY = -top;
                    initialized = true;
                }
                catch (Exception ex)
                {
                    File.AppendAllText("errordump.txt", "\r\nException in MapCollector.LoadWorldMapFromCache: " + ex.ToString() + "\r\n");
                    return false;
                }
                finally
                {
                }
            }
            finally
            {
                try
                {
                    if (inputStream != null) inputStream.Close();
                }
                catch (Exception) { }
            }
            ExpandBitmap(bitmapsize);
			return true;
		}

		public void SetChunk(Chunk c, bool notCreatingThread = false)
		{
			if (gd == null || (AMSettings.bDisableStaticMapStreaming && !notCreatingThread) || AMSettings.bDisableStaticMap)
				return;
			MCTile[,] output = new MCTile[chunkWidth, chunkHeight];
			MapFlattener.FlattenParams fp = new MapFlattener.FlattenParams(new IntVector2(0, 0), c, output, chunkWidth, chunkHeight, Chunk.height, Chunk.height - 1, 0, 1, true);
			cFlattener.Flatten(fp);
			if (notCreatingThread || suspendUpdates)
				flatChunkQueue.Enqueue(new KeyValuePair<MCTile[,], IntVector2>(output, c.o));
			else
				SaveFlatChunk(output, c.o, false);
		}



		private void SaveFlatChunk(MCTile[,] output, IntVector2 origin, bool isQueued)
		{
			KeyValuePair<MCTile[,], IntVector2> queuedChunk;
			while (!isQueued && flatChunkQueue.TryDequeue(out queuedChunk))
			{
				SaveFlatChunk(queuedChunk.Key, queuedChunk.Value, true);
			}
			//if (Thread.CurrentThread != threadThatCreatedWbmp)
			//{
			//    wbmp.Dispatcher.Invoke(saveFlatChunkDelegate, new object[] { output, origin });
			//    return;
			//}
			if (!initialized)
			{
				bmpOffsetX = (bitmapsize / 2) - origin.X;
				bmpOffsetY = (bitmapsize / 2) - origin.Y;
				initialized = true;
			}
			uint[,] rawData = new uint[Chunk.chunkSize, Chunk.chunkSize];

			int airCount = 0;
			for (int y = 0; y < chunkHeight; y++)
			{
				for (int x = 0; x < chunkWidth; x++)
				{
					MCTile t = output[y, x];
					while (t.nextTile != null)
						t = t.nextTile;
					//int idx = ((y * chunkWidth) + x) * bytesPerBlock;
					byte blockType = (byte)t.blockType;
					if (blockType == 0)
						airCount++;
					float av = 1 - (((t.c.R + t.c.B + t.c.G) / 3) / 255f);
					Color c = new Color(0, 0, 0, 255);
					Color rgbaColor = Color.Lerp(Block.pureColor[blockType], c, av);
					uint bgraColor = (uint)(rgbaColor.A << 24 | rgbaColor.R << 16 | rgbaColor.G << 8 | rgbaColor.B);

					rawData[x, y] = bgraColor;
				}
			}
			if (Globals.multiplayer && (airCount > 14 || (Globals.worldDimension == -1 && airCount > 200)))
				return; // This must be from SMP where Minecraft didn't have the chunk completely downloaded.  Do not use it or it might overwrite some good data.

			int X, Y;
			X = origin.X + bmpOffsetX;
			Y = origin.Y + bmpOffsetY;

			while (!BoundsCheck(X, Y))
			{
				if (bitmapsize > 14000)
					return; // too big, give up;
				if (right == int.MinValue)
					return;
				ExpandBitmap();
				X = origin.X + bmpOffsetX;
				Y = origin.Y + bmpOffsetY;
			}
			if (wbmp.TryLock(new System.Windows.Duration(new TimeSpan(0, 0, 5))))
			{
				wbmp.WritePixels(new System.Windows.Int32Rect(X, Y, Chunk.chunkSize, Chunk.chunkSize), rawData, chunkWidth * 4, 0);
				wbmp.Unlock();
			}
			if (origin.Y < top)
				top = origin.Y;
			if (origin.X < left)
				left = origin.X;
			if ((origin.Y + Chunk.chunkSize) > bottom)
				bottom = origin.Y + Chunk.chunkSize;
			if ((origin.X + Chunk.chunkSize) > right)
				right = origin.X + Chunk.chunkSize;
			if (savedAt + TimeSpan.FromSeconds(AMSettings.iStaticMapSaveIntervalSeconds) < DateTime.Now || Globals.saveStaticMapImmediately)
			{
				SavePng();
				savedAt = DateTime.Now;
				Globals.saveStaticMapImmediately = false;
			}
		}

		public void SavePng()
		{
			WriteableBitmapCreator croppedBmp = Crop();
			suspendUpdates = true;
			Thread thr = new Thread(SaveThreadStart);
			thr.Name = "Save Static Map";
			thr.Start(croppedBmp);
		}
		/// <summary>
		/// Saves the cropped bitmap and generates a new texture from it.
		/// </summary>
		/// <param name="param"></param>
		private void SaveThreadStart(object param)
		{
			WriteableBitmapCreator croppedBmpCreator = (WriteableBitmapCreator)param;
			WriteableBitmap croppedBmp = croppedBmpCreator.CreateWriteableBitmap();
			FileStream outputStream = null;
			int tries = 0;
			while (tries++ < 10)
			{
				try
				{
					outputStream = new FileStream(Globals.worldID + ".png", FileMode.Create, FileAccess.Write, FileShare.Read);
					break;
				}
				catch (Exception)
				{
					Thread.Sleep(500);
				}
			}
			PngBitmapEncoder encoder;
			if (outputStream != null)
			{
				encoder = new PngBitmapEncoder();
				encoder.Frames.Add(BitmapFrame.Create(croppedBmp));
				encoder.Save(outputStream);
				outputStream.Close();

				SaveOrigin();
			}
			// Write the texture to a MemoryStream so that it may be loaded into the WorldMap texture without having to read from disk!
			MemoryStream mStream = new MemoryStream();
			encoder = new PngBitmapEncoder();
			encoder.Frames.Add(BitmapFrame.Create(croppedBmp));
			encoder.Save(mStream);
			Globals.mapLayer.WorldMap = Texture2D.FromStream(this.gd, mStream);
			// Load the new origin and size information.
			Globals.worldMapOriginX = -left;
			Globals.worldMapOriginY = -top;
			Globals.worldMapWidth = (right - left);
			Globals.worldMapHeight = (bottom - top);
			suspendUpdates = false;
		}

		private void SaveOrigin()
		{
			string originstr = -left + "," + -top + "\r\n" + (right - left) + "x" + (bottom - top);
			File.WriteAllText(Globals.worldID + "origin.txt", originstr);
		}

		private WriteableBitmapCreator Crop()
		{
			int width = right - left;
			int height = bottom - top;
			uint[] rawData = new uint[width * height];
			if (right == int.MinValue)
				return null;
			wbmp.CopyPixels(new System.Windows.Int32Rect(left + bmpOffsetX, top + bmpOffsetY, width, height), rawData, width * 4, 0);
			return new WriteableBitmapCreator(rawData, width, height);
		}

		private void ExpandBitmap(int newSize = -1)
		{
			//if (right == int.MinValue) // no data yet, just move the offsets
			//{
			//    bmpOffsetX = (bitmapsize / 2) - origin.X;
			//    bmpOffsetY = (bitmapsize / 2) - origin.Y;
			//}
			//else
			//{
			if (right == int.MinValue)
				return;
			int newbmpsize = newSize == -1 ? (int)((float)bitmapsize * 1.41421356) : newSize;
			int width = right - left;
			int height = bottom - top;

			int bmpNewLeft = (newbmpsize - width) / 2;
			int bmpNewTop = (newbmpsize - height) / 2;

			uint[] rawData = new uint[width * height];
			//if (!wbmp.TryLock(new System.Windows.Duration(new TimeSpan(0, 0, 10))))
			//    throw new ApplicationException("Failed to lock static map bitmap for expansion.");
			wbmp.CopyPixels(new System.Windows.Int32Rect(left + bmpOffsetX, top + bmpOffsetY, width, height), rawData, width * 4, 0);
			//wbmp.Unlock();

			WriteableBitmap newbmp = new WriteableBitmap(newbmpsize, newbmpsize, 72, 72, System.Windows.Media.PixelFormats.Bgra32, System.Windows.Media.Imaging.BitmapPalettes.Gray16);

			if (!newbmp.TryLock(new System.Windows.Duration(new TimeSpan(0, 0, 10))))
				throw new ApplicationException("Failed to lock new static map bitmap for expansion.");
			newbmp.WritePixels(new System.Windows.Int32Rect(bmpNewLeft, bmpNewTop, width, height), rawData, width * 4, 0);
			newbmp.Unlock();

			// left, top is the real coordinate of the first pixel we drew to the new bitmap at bmpNewleft, bmpNewTop.
			bmpOffsetX = bmpNewLeft - left;
			bmpOffsetY = bmpNewTop - top;

			bitmapsize = newbmpsize;

			wbmp = newbmp;
			//}

		}
		private bool BoundsCheck(int x, int y)
		{
			if (x + Chunk.chunkSize > bitmapsize || x < 0)
				return false;
			if (y + Chunk.chunkSize > bitmapsize || y < 0)
				return false;
			return true;
		}
		//static int worldCacheSize = 1000;
		//static byte[] blankCache = new byte[worldCacheSize * worldCacheSize * bytesPerBlock];
		//string cacheDir = "StaticMapCache";
		//private void WriteChunkToCacheFile(byte[] data, IntVector2 origin)
		//{
		//    int fileNameX;
		//    int fileNameY;
		//    int fileByteOffset;
		//    CalculateFile(origin, out fileNameX, out fileNameY, out fileByteOffset);

		//    string fileName = fileNameX + "_" + fileNameY + ".amcache";

		//    fileName = Path.Combine(cacheDir, fileName);
		//    if (!Directory.Exists(cacheDir))
		//        Directory.CreateDirectory(cacheDir);
		//    if (!File.Exists(fileName))
		//        CreateEmptyCacheFile(fileName);

		//    FileStream output = new FileStream(fileName, FileMode.Open, FileAccess.Write);
		//    output.Seek(fileByteOffset, SeekOrigin.Begin);
		//    output.Write(data, 0, data.Length);
		//    output.Close();
		//}

		//private void CalculateFile(IntVector2 origin, out int fileNameX, out int fileNameY, out int fileByteOffset)
		//{
		//    int X = origin.X;
		//    int Y = origin.Y;
		//    if (X < 0)
		//        X -= worldCacheSize;
		//    if (Y < 0)
		//        Y -= worldCacheSize;
		//    fileNameX = X / worldCacheSize;
		//    fileNameY = Y / worldCacheSize;
		//    int fileX = X % worldCacheSize;
		//    if (fileX < 0)
		//        fileX = worldCacheSize - (-fileX);
		//    int fileY = Y % worldCacheSize;
		//    if (fileY < 0)
		//        fileY = worldCacheSize - (-fileY);
		//    fileByteOffset = (((fileY * worldCacheSize) + fileX) * bytesPerBlock);
		//}

		//private void CreateEmptyCacheFile(string fileName)
		//{
		//    FileStream output = new FileStream(fileName, FileMode.Create, FileAccess.Write);
		//    output.Write(blankCache, 0, blankCache.Length);
		//    output.Close();
		//}
	}
	internal class WriteableBitmapCreator
	{
		private int width;
		private int height;
		private uint[] rawData;

		public WriteableBitmapCreator(uint[] rawData, int width, int height)
		{
			this.rawData = rawData;
			this.width = width;
			this.height = height;
		}
		public WriteableBitmap CreateWriteableBitmap()
		{
			WriteableBitmap newbmp = new WriteableBitmap(width, height, 72, 72, System.Windows.Media.PixelFormats.Bgra32, System.Windows.Media.Imaging.BitmapPalettes.Gray16);

			if (!newbmp.TryLock(new System.Windows.Duration(new TimeSpan(0, 0, 10))))
				throw new ApplicationException("Failed to lock new static map bitmap after cropping.");
			newbmp.WritePixels(new System.Windows.Int32Rect(0, 0, width, height), rawData, width * 4, 0);
			newbmp.Unlock();
			return newbmp;
		}
	}
}
