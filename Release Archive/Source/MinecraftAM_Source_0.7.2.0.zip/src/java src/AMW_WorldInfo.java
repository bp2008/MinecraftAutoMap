public class AMW_WorldInfo
{
	// Fixed 10
	eg inst;
	// Fixed 10
	public AMW_WorldInfo(eg param)
	{
		inst = param;
	}
	public String getName()
	{
		// Fixed 10
		return inst.j();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Fixed 10
		return inst.e() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Fixed 10
		return inst.c();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Fixed 10
		return inst.d();
	}
}
