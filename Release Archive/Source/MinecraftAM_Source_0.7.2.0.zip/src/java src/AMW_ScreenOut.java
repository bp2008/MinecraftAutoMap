import net.minecraft.client.Minecraft;

public class AMW_ScreenOut
{
	// ScreenOut class is qv
	private static Minecraft mc;
	public static void DisplayMessage(String message)
	{
		// Fixed 10
		mc.v.a("�E" + message);
	}
	public static void Initialize(Minecraft parammc)
	{
		mc = parammc;
	}
}
