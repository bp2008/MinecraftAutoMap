package org.brian.eventtcp;

import java.io.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Brian
 */
public class EventTcpWriter extends Thread
{
    PacketPacker packer;
    final Object writerLock = new Object();
    OutputStream os;
    ConcurrentLinkedQueue<byte[]> sendQueue;
    public boolean isRunning = false;
    //   Logger logger = Logger.getLogger("EventTcp");
    EventTcpClient client;
    Semaphore syncSem;

    public EventTcpWriter(OutputStream os, EventTcpClient client)
    {
        packer = new PacketPacker();
        syncSem = new Semaphore(-1);
        this.client = client;
        sendQueue = new ConcurrentLinkedQueue<byte[]>();
        this.os = os;
    }

    public boolean sendMessage(byte[] message)
    {
        try
        {
            sendQueue.add(message);
            syncSem.release();
        } catch (Exception ex)
        {
            //       logger.log(Level.WARNING, ex.getMessage(), ex);
            isRunning = false;

            EventTcpServer.ReportException(ex, "SendMessage Failed");
            if (sendQueue != null)
                syncSem.release(2);
        }
        return isRunning;
    }

    public void abort()
    {
        isRunning = false;
    }

    @Override
    public void run()
    {
        isRunning = true;
        try
        {
            while (isRunning)
            {
                syncSem.acquire();
                byte[] b = sendQueue.poll();
                if (b != null)
                {
                    b = packer.Pack(b);

                    EventTcpServer.sentChars += b.length;
                    EventTcpServer.sentCnt++;
                    os.write(b);
                    os.flush();
                }
            }
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
            //       logger.log(Level.WARNING, ex.getMessage(), ex);
        }
        isRunning = false;
        try
        {
            client.Disconnect();
            os.close();
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
            //          logger.log(Level.WARNING, ex.getMessage(), ex);
        }
    }
}
