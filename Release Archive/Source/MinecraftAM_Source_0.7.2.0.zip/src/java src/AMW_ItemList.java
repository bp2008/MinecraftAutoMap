
public class AMW_ItemList
{
	public static int getImageIndex(int itemID)
	{
		// Fixed 10
		return gk.c[itemID].bg;
	}
	public static String getName(int itemID)
	{
		// Fixed 10
		return gk.c[itemID].a();
	}
}
