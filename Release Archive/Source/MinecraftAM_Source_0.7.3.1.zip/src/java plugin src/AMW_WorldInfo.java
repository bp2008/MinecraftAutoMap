public class AMW_WorldInfo
{
	// Find this class with "SizeOnDisk"
	// Fixed 11
	ei inst;
	// Fixed 11
	public AMW_WorldInfo(ei param)
	{
		inst = param;
	}
	public String getName()
	{
		// Fixed 11
		return inst.j();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Fixed 11
		return inst.e() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Fixed 11
		return inst.c();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Fixed 11
		return inst.d();
	}
}
