package org.brian.eventtcp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.Vector;

/**
 *
 * @author Brian
 */
public class EventTcpServer
{
    public final static int bufferSize = 1048576;
    protected final Object clientLock = new Object();
    protected Vector<EventTcpClient> clients;
    protected ServerSocket sockServer = null;
    // Logger logger = Logger.getLogger("EventTcp");
    public boolean isListening = false;
    protected EventTcpAcceptThread threadAcceptConnections = null;
    protected EventTcpClientListener listener;
    protected EventTcpAcceptThreadArgs args;
    public static int receivedCnt = 0;
    public static int sentCnt = 0;
    public static int receivedChars = 0;
    public static int sentChars = 0;

    public EventTcpServer(int port, final EventTcpClientListener listener)
    {
        this("0.0.0.0", port, listener);
    }

    public EventTcpServer(String host, int port, final EventTcpClientListener listener)
    {
        try
        {
            clients = new Vector<EventTcpClient>();
            this.listener = listener;
            sockServer = new ServerSocket();
            sockServer.setReceiveBufferSize(bufferSize);
            sockServer.bind(new InetSocketAddress(host, port));
            args = new EventTcpAcceptThreadArgs(isListening, sockServer, clientLock, clients, listener);
            threadAcceptConnections = new EventTcpAcceptThread(args);
            threadAcceptConnections.start();
        } catch (UnknownHostException ex)
        {
            EventTcpServer.ReportException(ex);
            //logger.log(Level.WARNING, e.getMessage(), e);
        } catch (IOException ex)
        {
            EventTcpServer.ReportException(ex);
            // logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }

    public void stopListening()
    {
        args.isListening = false;
    }

    /**
     * Gets the client at the specified index.  
     * There is no guarantee that the client you get will be not be null.
     * The client may also be disconnected.
     * @param index
     * @return
     */
    public EventTcpClient getClient(int index)
    {
        try
        {
            synchronized (clientLock)
            {
                return clients.elementAt(index);
            }
        } catch (Exception ex)
        {
            EventTcpServer.ReportException(ex);
            //  logger.log(Level.WARNING, ex.getMessage(), ex);
        }

        return null;
    }

    /**
     * Returns the number of clients in the client vector.
     * Some may be disconnected, and this is a synchronized
     * function so calling frequently may slow down application
     * execution.
     * @return
     */
    public int getClientCount()
    {
        synchronized (clientLock)
        {
            return clients.size();
        }
    }

    public void removeClient(int index)
    {
        synchronized (clientLock)
        {
            clients.remove(index);
        }
    }

    public void removeClient(EventTcpClient c)
    {
        synchronized (clientLock)
        {
            clients.remove(c);
        }
    }
    static boolean enableReporting = false;

    public static void ReportException(Exception ex)
    {
        if (enableReporting)
            ReportException(ex.getMessage() + "\r\n" + ex.getStackTrace());
    }

    public static void ReportException(Exception ex, String message)
    {
        if (enableReporting)
            ReportException(message + "\r\n" + ex.getMessage() + "\r\n" + ex.getStackTrace());
    }

    public static void ReportException(String s)
    {
        if (enableReporting)
            javax.swing.JOptionPane.showMessageDialog(java.awt.Frame.getFrames()[0], s);
    }
}
