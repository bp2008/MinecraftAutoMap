
public class AMW_ItemList
{
	// Find class with "shovelIron"
	public static int getImageIndex(int itemID)
	{
		// Last int before 2 bools -- this int is uninitialized
		// Fixed 11
		return gm.c[itemID].bh;
	}
	public static String getName(int itemID)
	{
		// Near the bottom
		// Fixed 11
		return gm.c[itemID].a();
	}
}
