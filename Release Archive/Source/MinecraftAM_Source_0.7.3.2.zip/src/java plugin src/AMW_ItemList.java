
public class AMW_ItemList
{
	// Find class with "shovelIron"
	public static int getImageIndex(int itemID)
	{
		// Last int before 2 bools -- this int is uninitialized
		// Fixed 12
		return sv.f[itemID].bt;
	}
	public static String getName(int itemID)
	{
		// Near the bottom
		// Fixed 12
		return sv.f[itemID].c();
	}
}
