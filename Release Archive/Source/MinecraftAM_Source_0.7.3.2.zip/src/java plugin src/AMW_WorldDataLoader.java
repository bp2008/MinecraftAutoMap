import java.io.File;
import java.lang.reflect.Field;

//The WorldDataLoader comes from world.p (a protected
// variable accessed via reflection)
public class AMW_WorldDataLoader
{
	// Look this one up with
	// "The save is being accessed from another location, aborting"
	// Fixed 12
	dd inst;

	// Fixed 12
	public AMW_WorldDataLoader(dd param)
	{
		inst = param;
	}

	public File getWorldFilePath()
	{
		//return inst.a();
		// This can be obtained via Reflection from the private field if
		// necessary.
		File worldFilePath = null;
		try
		{
			// Note the CLASS NAME and the FIELD NAME STRING both need updated.
			// Fixed 12
			Field privateFieldFile = dd.class.getDeclaredField("b");
			privateFieldFile.setAccessible(true);
			Object fileObj = privateFieldFile.get(inst);
			if (!(fileObj instanceof File))
			{
				AutomapServer
						.LogL1("getWorldInfo() failed.  The File object from the World Data Loader is not an instance of File.");
				return null;
			}
			worldFilePath = (File) fileObj;
		} catch (SecurityException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  SecurityException was thrown when trying to the the World Data Loader's File object.");
			return null;
		} catch (NoSuchFieldException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  The World Data Loader's File field did not exist.");
			return null;
		} catch (IllegalArgumentException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  IllegalArgumentException was thrown when trying to the the World Data Loader's File object.");
			return null;
		} catch (IllegalAccessException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  IllegalAccessException was thrown when trying to the the World Data Loader's File object.");
			return null;
		}
		return worldFilePath;
	}

}

// Getting the world path is a little more complicated.
// String FailString = "Unknown|" + dimension + "|" + worldName + "|"
// + spawnX + "|" + spawnY + "|" + spawnZ;

// ek worldDataLoader = null;
// try
// {
// Field privateFieldWorldDataLoader = AMW_World.class.getDeclaredField("p");
// privateFieldWorldDataLoader.setAccessible(true);
// Object wDL = privateFieldWorldDataLoader.get(getWorld());
// if (!(wDL instanceof ek))
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  The World Data Loader field is not an instance of the correct class.");
// return FailString;
// }
// worldDataLoader = (ek) wDL;
// } catch (SecurityException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  SecurityException was thrown when trying to the the World Data Loader.");
// return FailString;
// } catch (NoSuchFieldException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  The World Data Loader field did not exist inside the World object.");
// return FailString;
// } catch (IllegalArgumentException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  IllegalArgumentException was thrown when trying to the the World Data Loader.");
// return FailString;
// } catch (IllegalAccessException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  IllegalAccessException was thrown when trying to the the World Data Loader.");
// return FailString;
// }
// Get the File object that we want out of it!
// File worldFilePath = null;
// try
// {
// Field privateFieldFile = ek.class.getDeclaredField("b");
// privateFieldFile.setAccessible(true);
// Object fileObj = privateFieldFile.get(worldDataLoader);
// if (!(fileObj instanceof File))
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  The File object from the World Data Loader is not an instance of File.");
// return FailString;
// }
// worldFilePath = (File) fileObj;
// } catch (SecurityException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  SecurityException was thrown when trying to the the World Data Loader's File object.");
// return FailString;
// } catch (NoSuchFieldException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  The World Data Loader's File field did not exist.");
// return FailString;
// } catch (IllegalArgumentException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  IllegalArgumentException was thrown when trying to the the World Data Loader's File object.");
// return FailString;
// } catch (IllegalAccessException e)
// {
// AutomapServer
// .LogL1("getWorldInfo() failed.  IllegalAccessException was thrown when trying to the the World Data Loader's File object.");
// return FailString;
// }