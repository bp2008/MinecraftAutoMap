import net.minecraft.client.Minecraft;

public class mod_automap extends BaseMod
{
	public static mod_automap instance;

	private boolean isLoaded = false;
	public static boolean alternateStart = false;

	public mod_automap()
	{
		instance = this;
		if (!alternateStart)
			ModLoader.SetInGameHook(this, true, true);
	}

	/**
	 * Called every "tick"?
	 */
	public boolean OnTickInGame(float tick, Minecraft mc)
	{
		if (!isLoaded)
		{
			try
			{
				AMW_ScreenOut.Initialize(mc);
				AutomapServer.initialize(new AM_MCWorld(new AMW_Minecraft(mc)));
				AMW_ScreenOut.DisplayMessage("AutoMap Java Code v" + Version()
						+ " Initialized");
				isLoaded = true;
			} catch (Exception ex)
			{
				AMW_ScreenOut.DisplayMessage("AutoMap initialization error!");
				AMW_ScreenOut.DisplayMessage(ex.getMessage());
				StackTraceElement[] ste = ex.getStackTrace();
				for (int i = 0; i < ste.length && i < 5; i++)
					AMW_ScreenOut.DisplayMessage(ste[i].toString());
			}
		}
		return false;
	}

	@Override
	public String Version()
	{
		return "12";
	}
}
