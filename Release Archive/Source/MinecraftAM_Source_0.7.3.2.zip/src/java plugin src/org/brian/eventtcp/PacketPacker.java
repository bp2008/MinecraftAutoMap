package org.brian.eventtcp;

import java.security.MessageDigest;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Brian
 */
public class PacketPacker
{
    // GDI - Java generics make me use reference types!
    public boolean haveASize = false;
    public int iCurrentIndex = 0;
    public int iCurrentSize = 0;
    public byte[] currentPacket;
    public byte[] leftovers;
    public static boolean Sha256Digest = false;

    public PacketPacker()
    {
        leftovers = new byte[0];
    }

    public byte[] Pack(byte[] bytes)
    {
        if (Sha256Digest)
            bytes = AddSha256Digest(bytes);
        byte[] size = BitConverter.GetBytes(bytes.length);
        byte[] bytesNew = new byte[bytes.length + size.length];
        if (size.length == 4)
        {
            bytesNew[0] = size[0];
            bytesNew[1] = size[1];
            bytesNew[2] = size[2];
            bytesNew[3] = size[3];
        } else
        {
            // awwe F, what now?!
        }
        for (int i = 0, j = 4; i < bytes.length; i++, j++)
        {
            bytesNew[j] = bytes[i];
        }
        return bytesNew;
    }

    public void Unpack(byte[] bytes, int byteCount, Vector<Packet> packets)
    {
        // Attach leftovers, if there were any.
        if (leftovers.length > 0)
        {
            byte[] newBytes = new byte[leftovers.length + byteCount];
            int i = 0;
            // Copy leftovers into new array.
            for (; i < leftovers.length; i++)
                newBytes[i] = leftovers[i];
            // Get rid of leftovers so they are not used again by accident.
            leftovers = new byte[0];
            // Copy passed-in bytes into new array starting where the leftovers left off.
            for (int k = 0; k < byteCount; i++, k++)
                newBytes[i] = bytes[k];
            // Replace passed-in byte array with new array.
            bytes = newBytes;
        }
        // Handle the passed-in byte array.
        int j = 0;
        while (true)
        {
            // j is the index we are currently at in 'bytes'
            if (!haveASize)
            {
                if (byteCount - j < 4)
                {
                    leftovers = ArrayCopy(bytes, j, byteCount - j); // These are leftovers.
                    return;
                }
                // Convert size to int and prepare for array copying.
                iCurrentSize = BitConverter.ToInt32(bytes, j);
                j += 4;
                //EventTcpServer.ReportException("iCurrentSize: " + iCurrentSize);
                iCurrentIndex = 0;
                currentPacket = new byte[iCurrentSize];
                haveASize = true;
            }
            // We now have a set size if we got to here.
            // Copy bytes until something runs out or fills up
            for (; iCurrentIndex < iCurrentSize && j < byteCount; iCurrentIndex++, j++)
            {
                currentPacket[iCurrentIndex] = bytes[j];
            }
            // We got here, meaning either the packet is complete or we ran out of bytes to fill the packet with, or both!
            if (iCurrentIndex == iCurrentSize)
            {
                if(Sha256Digest)
                    currentPacket = VerifySha256Digest(currentPacket);
                // Packet is complete.  Return it and start another.
                packets.add(new Packet(currentPacket));
                // Reset values.
                iCurrentSize = 0;
                iCurrentIndex = 0;
                haveASize = false;
            }
            if (j == byteCount)
            {
                // We ran out of bytes.  We need to wait for more before we can continue.
                return;
            }
        }
    }

    /**
     * Copies the specified section of the specified array into a new array of size count.
     * Copy starts at startIndex and proceeds until count bytes have been reached.
     * An array of size 0 will be returned if the parameters are not valid.
     * @param bytes
     * @param startIndex
     * @param count
     * @return
     */
    public static byte[] ArrayCopy(byte[] bytes, int startIndex, int count)
    {
        if (count <= 0 || startIndex < 0 || startIndex >= bytes.length || startIndex + count > bytes.length)
        {
                logger.log(Level.WARNING, "Cannot Copy Array: count/startIndex/length: " + count + "/" + startIndex + "/" + bytes.length);
            return new byte[0];
        }
        byte[] copy = new byte[count];
        for (int i = 0; i < count; i++, startIndex++)
            copy[i] = bytes[startIndex];
        return copy;
    }

    public static void InsertBytes(byte[] destination, int destinationOffset, byte[] source)
    {
        if (destination.length - destinationOffset < source.length)
            return;
        for (int i = 0; i < source.length; i++, destinationOffset++)
            destination[destinationOffset] = source[i];
    }

    public static boolean ArraysMatch(byte[] response, byte[] responseDupe)
    {
        if (response.length != responseDupe.length)
            return false;
        for (int i = 0; i < response.length; i++)
            if (response[i] != responseDupe[i])
                return false;
        return true;
    }

    private byte[] AddSha256Digest(byte[] bytesNew)
    {
        try
        {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(bytesNew);
            byte[] digestedBytes = new byte[bytesNew.length + 32];
            InsertBytes(digestedBytes, 0, digest);
            InsertBytes(digestedBytes, 32, bytesNew);
            return digestedBytes;
        } catch (Exception ex)
        {
            return bytesNew;
        }
    }

    private static Logger logger = Logger.getLogger("AutomapServer");
    private byte[] VerifySha256Digest(byte[] digestedBytes)
    {
        try
        {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] givenDigest = ArrayCopy(digestedBytes, 0, 32);
            byte[] bytes = ArrayCopy(digestedBytes, 32, digestedBytes.length - 32);
            byte[] digest = md.digest(bytes);
            if (ArraysMatch(digest, givenDigest))
                return bytes;
            else
                logger.log(Level.SEVERE, "Digest did not match!: \r\n" + ByteArrayToCommaString(digest) + "\r\n" + ByteArrayToCommaString(givenDigest) + "\r\n" + ByteArrayToCommaString(digestedBytes));
        } catch (Exception ex)
        {
        }
        return new byte[0];
    }
    private String ByteArrayToCommaString(byte[] message)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < message.length; i++)
        {
            sb.append(message[i]);
            sb.append(',');
        }
        return sb.toString();
    }
}

