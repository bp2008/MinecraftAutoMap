import net.minecraft.client.Minecraft;

public class AMW_Minecraft
{
	Minecraft inst;

	public AMW_Minecraft(Minecraft mc)
	{
		inst = mc;
	}

	public AMW_World getWorld()
	{
		// Fixed 12
		return new AMW_World(inst.f);
	}

	public AMW_Player getPlayer()
	{
		// Fixed 12
		return new AMW_Player(inst.h);
	}
	
	public String getSMPHost()
	{
		// Fixed 12
		return inst.z.F;
	}

	public boolean checkWorldChanged(Object inst2)
	{
		// Fixed 12
		return inst2 != inst.f;
	}
}
