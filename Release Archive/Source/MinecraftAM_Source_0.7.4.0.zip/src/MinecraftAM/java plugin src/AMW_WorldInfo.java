public class AMW_WorldInfo
{
	// Find this class with "SizeOnDisk"
	// Fixed 12
	rl inst;
	// Fixed 12
	public AMW_WorldInfo(rl param)
	{
		inst = param;
	}
	public String getName()
	{
		// Fixed 12
		return inst.j();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Fixed 12
		return inst.e() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Fixed 12
		return inst.c();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Fixed 12
		return inst.d();
	}
}
