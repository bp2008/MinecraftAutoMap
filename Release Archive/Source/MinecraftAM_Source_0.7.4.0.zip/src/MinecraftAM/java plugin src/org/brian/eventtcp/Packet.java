/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.brian.eventtcp;

/**
 *
 * @author Brian
 */
public class Packet
{
    public byte[] bytes;
    public Packet(byte[] bytes)
    {
        this.bytes = bytes;
    }
}
