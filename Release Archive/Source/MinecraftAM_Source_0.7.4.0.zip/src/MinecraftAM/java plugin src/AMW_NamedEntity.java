public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 12
	public static final Class<wd> wrappedClass = wd.class;
	// Fixed 12
	public wd inst;
	// Fixed 12
	public AMW_NamedEntity(wd param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity")
			name = null;
		if (name == null || name.equals(""))
			// Fixed 12
			name = inst.f_(); // fully qualified name? Or perhaps sound file ID
		if (name == null || name.equals(""))
			// Fixed 12
			name = inst.bn; // entity texture?
		if (name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
