import java.lang.reflect.Field;
import java.util.List;

public class AMW_World
{
	// Fixed 12
	rv inst;

	// Fixed 12
	public AMW_World(rv world)
	{
		inst = world;
	}

	public AMW_WorldInfo getWorldInfo()
	{
		// world.w() gets a dy which contains the text "RandomSeed", "SpawnX",
		// "LastPlayed", "SizeOnDisk"
		//
		// Fixed 12
		return new AMW_WorldInfo(inst.x());
	}

	public AMW_WorldDataLoader getWorldDataLoader()
	{
		// ek is a WorldDataLoader which comes from world.p (a protected
		// variable accessed via reflection)
		//
		// Fix WorldDataLoader first so you know the class name to replace here.
		// Fixed 12
		dd worldDataLoader = null;
		try
		{
			// Fixed 12
			Field privateFieldWorldDataLoader = inst.getClass()
					.getDeclaredField("B");
			privateFieldWorldDataLoader.setAccessible(true);
			Object wDL = privateFieldWorldDataLoader.get(inst);
			// Fixed 12
			if (!(wDL instanceof dd))
			{
				AutomapServer
						.LogL1("getWorldInfo() failed.  The World Data Loader field is not an instance of the correct class.");
				return null;
			}
			// Fixed 12
			worldDataLoader = (dd) wDL;
		} catch (SecurityException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  SecurityException was thrown when trying to the the World Data Loader.");
			return null;
		} catch (NoSuchFieldException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  The World Data Loader field did not exist inside the World object.");
			return null;
		} catch (IllegalArgumentException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  IllegalArgumentException was thrown when trying to load the World Data Loader.");
			return null;
		} catch (IllegalAccessException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  IllegalAccessException was thrown when trying to load the World Data Loader.");
			return null;
		}
		return new AMW_WorldDataLoader(worldDataLoader); // new
															// AMW_WorldDataLoader((ek)
															// inst.p);
	}

	// World has a public final variable shortly after the Random which is
	// sent to a function in another class that contains the text "DIM-1".
	// This lets us detect whether or not the dimension is Nether because
	// the one in the world info object only tells us what the dimension was
	// when the world loaded from the menu.
	public String getDimension()
	{
		// uw is something that world.o can be. extends vr
		// now, the object itself has a field which contains the dimension number
		//
		// Fixed 12
		return String.valueOf(inst.y.g);
	}

	public byte getBlockId(int x, int y, int z)
	{
		// Fixed 12
		return (byte) inst.a(x, z, y);
	}

	public byte getBlockMeta(int x, int y, int z)
	{
		// Fixed 12
		return (byte) inst.e(x, z, y);
	}

	public byte getBlockLight(int x, int y, int z)
	{
		// Fixed 12
		return (byte) inst.n(x, z, y);
	}

	/**
	 * The NPC list also has players in it.
	 */
	public List<?> GetPlayerList()
	{
		// Second to last public list?. (Players) NPC list also has players in it.
		//
		// Fixed 12
		return inst.i;
	}

	/**
	 * Also contains players.
	 */
	public List<?> GetNPCList()
	{
		// First public list
		//
		// Fixed 12
		return inst.g;
	}
	public void CreateExplosion(double x, double y, double z, float power)
	{
		// This function can be found with the regex:
		//  \w+\([^ ]+ [^,]+, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat\)
		//
		// it is 2 functions, one is an overload which passes in false.
		//
		// Fixed 12
		inst.a(null, x, y, z, power);
	}
}

// THE COMMENT BELOW IS OUTDATED - IT REMAINS HERE AS A GUIDE FOR WHAT
// NOT TO DO
// This function used to be able to just return getWorld().t;
// But the world class no longer has a simple File pointer.
// The method I have devised for getting a File reference to the world's
// folder is this:
// 1. Get access to the "saves" directory via Minecraft's static method
// that returns a File reference to the .minecraft directory.
// 2. Minecraft has a public accessor that returns a MCRegion Loader
// (called worldInspector here) class instance. This can create for us a
// List of objects that map world names and world save folder names
// together.
// 3. Get the list that matches world names and save folder names.
// (this is called worldInfo here)
// 4. Get the name of the current world from the current world object.
// 5. Compare the name of the current world with the names in worldInfo.
// 6. If there is a match, return a File reference using the matched
// path. If there is no match, return reference to saves folder and
// report the error.
// /////
// This method now returns a String containing the full path, a pipe,
// the dimension number, another pipe, and the world name.
// /////////
// world.w() is a public accessor for world.q, which has world info.