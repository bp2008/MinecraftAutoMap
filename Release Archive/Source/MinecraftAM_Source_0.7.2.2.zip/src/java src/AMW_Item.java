public class AMW_Item extends AMW_Entity
{
	// Find with "Age"
	// Fixed 11
	public static final Class<hl> wrappedClass = hl.class;
	// Fixed 11
	public hl inst;
	// Fixed 11
	public AMW_Item(hl param)
	{
		super(param);
		inst = param;
	}

	public int getID()
	{
		// Fixed 11
		return inst.a.c;
	}

	public int getCount()
	{
		// Fixed 11
		return inst.a.a;
	}

	@Override
	public String getName()
	{
		// IGNORE WHEN UPDATING <-- Verified: Ignore this function
		int itemID = getID();
		int numberOfItems = getCount();
		if (itemID >= 256)
		{
			// Add item tag, graphic index, name, and count
			String itemName = AMW_ItemList.getName(itemID);
			if (itemName.length() > 5) // Remove "item." from name
				itemName = itemName.substring(5);
			itemName = "Item|" + itemID + "|"
					+ AMW_ItemList.getImageIndex(itemID) + "|" + itemName + "|"
					+ numberOfItems;
			return itemName;
		} else if (itemID >= 0)
		{
			String blockName = AMW_BlockList.getName(itemID);
			if (blockName.length() > 5) // Remove "tile." from name
				blockName = blockName.substring(5);
			blockName = "Block|" + itemID + "|" + blockName + "|" + numberOfItems;
			return blockName;
		} else
		{
			return "";
		}
	}
}
