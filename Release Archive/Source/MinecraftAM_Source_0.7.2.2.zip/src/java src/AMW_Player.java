public class AMW_Player extends AMW_NamedEntity
{
	// Fixed 11
	public static final Class<gs> wrappedClass = gs.class;
	// Fixed 11
	public gs inst;
	// Fixed 11
	public AMW_Player(gs param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		// first String, not far at all down the page, should be 2 strings total, close together
		// Fixed 11
		return inst.l;
	}
}
