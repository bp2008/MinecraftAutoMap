public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 11
	public static final Class<ls> wrappedClass = ls.class;
	// Fixed 11
	public ls inst;
	// Fixed 11
	public AMW_NamedEntity(ls param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity")
			name = null;
		if (name == null || name.equals(""))
			// Fixed 11
			name = inst.j_(); // fully qualified name? Or perhaps sound file ID
		if (name == null || name.equals(""))
			// Fixed 11
			name = inst.O; // entity texture?
		if (name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
