import java.net.InetSocketAddress;

import net.minecraft.client.Minecraft;
import net.minecraft.src.TcpConnection;

public class AMW_Minecraft
{
	Minecraft inst;

	public AMW_Minecraft(Minecraft mc)
	{
		inst = mc;
	}

	public AMW_World getWorld()
	{
		// Fixed 17
		return new AMW_World(inst.theWorld);
	}

	public AMW_Player getPlayer()
	{
		// Fixed 17
		return new AMW_Player(inst.thePlayer);
	}

	public String getSMPHost()
	{
		// The following does NOT work:
		//
		// The server name and port is a string and an int, declared a dozen
		// lines or so after
		// MinecraftApplet. They are both set in a simple function about 50
		// lines down. The aforementioned function should have been called near
		// the string constant: "Post startup".
		//
		// The following DOES work:
		//
		// Get the Socket used for communication and pull the data out of it.
		//
		//
		// Near Bottom -- Just above main function
		// Fixed 17
//		Object playerNetClient = inst.getSendQueue();
//		// this is a NetClientHandler instance
//		if (playerNetClient == null)
//			return "unknown";
//		//
//		// Fixed 17
//		// This is src/minecraft/net/minecraft/src/NetClientHandler.java in the
//		// deobfuscated source.
//		// Find it in the obfuscated source. The string should be the obfuscated
//		// equivalent of the netManager object.
//		// MCP-FIX 20 - find NetClientHandler."netManager" -- find class with
//		// "Client"
//		Object networkManager = Utilities.GetPrivateField(playerNetClient, "g");
//		// this is a NetworkManager instance
//		if (networkManager == null)
//			return "unknown";
//		//
//		// Fixed 17
//		// MCP-FIX 20 - find the Socket in deobfuscated TcpConnection -- find
//		// obfuscated class with " read thread"
//		// The string is the obfuscated name of the Socket
//		Object oSocket = Utilities.GetPrivateField(networkManager, "i");
//		if (oSocket == null || !(oSocket instanceof Socket))
//			return "unknown";
//		Socket sock = (Socket) oSocket;
		
		//
		// THE ABOVE Double-commented code is not currently necessary.
		//
		InetSocketAddress sockAddress = (InetSocketAddress)inst.getSendQueue().getNetManager().getSocketAddress();
		String serverName = sockAddress.getHostName();
		int serverPort = sockAddress.getPort();
		return serverName + ":" + serverPort;
	}

	public boolean checkWorldChanged(Object inst2)
	{
		// Same object as in getWorld above
		// Fixed 17
		return inst2 != inst.theWorld;
	}

	public boolean isMultiplayer()
	{
		return inst.getSendQueue().getNetManager() instanceof TcpConnection;
	}
}
