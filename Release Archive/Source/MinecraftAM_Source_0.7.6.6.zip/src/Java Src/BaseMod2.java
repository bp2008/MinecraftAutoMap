//
//public class BaseMod
//{
//	public String Version(){return "";}
//}
