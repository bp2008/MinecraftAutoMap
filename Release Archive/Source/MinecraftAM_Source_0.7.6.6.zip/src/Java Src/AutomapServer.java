import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.brian.eventtcp.BitConverter;
import org.brian.eventtcp.EventTcpClient;
import org.brian.eventtcp.EventTcpClientListener;
import org.brian.eventtcp.EventTcpServer;

/**
 * 
 * @author Brian
 */
public class AutomapServer implements EventTcpClientListener, AM_WorldChangedListener
{
	private static int loggingLevel = 3;

	public static void LogL1(String message)
	{
		if (loggingLevel >= 1)
			logger.severe(message);
	}

	public static void LogL2(String message)
	{
		if (loggingLevel >= 2)
			logger.warning(message);
	}

	public static void LogL3(String message)
	{
		if (loggingLevel >= 3)
			logger.info(message);
	}

	public static void LogL4(String message)
	{
		if (loggingLevel >= 4)
			logger.fine(message);
	}

	public static void LogL5(String message)
	{
		if (loggingLevel >= 5)
			logger.finer(message);
	}

	public static void LogL6(String message)
	{
		if (loggingLevel >= 6)
			logger.finest(message);
	}

	// private static final int SHORT_BYTES = 2;
	private static final int INT_BYTES = 4;
	// private static final int LONG_BYTES = 8;
	private static final int FLOAT_BYTES = 4;
	private static final int DOUBLE_BYTES = 8;
	private static final byte GET_PLAYER_LOCATION = 0;
	private static final byte GET_WORLD_CHUNK = 1;
	private static final byte GET_WORLD_CHUNK_NOLIGHT = 2;
	// private static final byte GET_FULL_COLUMN = 2;
	private static final byte GET_WORLD_PATH = 20;
	private static final byte SET_PLAYER_LOCATION = 30;
	private static final byte CREATE_EXPLOSION = 40;
	private static final byte PERMISSION_CONFIRMATION = 50;
	private static final byte p_OreDetection = 1;
	private static final byte p_CaveMap = 1 << 1;
	private static final byte p_Players = 1 << 2;
	private static final byte p_HostileNPCs = 1 << 3;
	private static final byte p_PassiveNPCs = 1 << 4;
	private static final byte p_NeutralNPCs = 1 << 5;
	private static final byte p_Items = 1 << 6;
	private static final byte p_PowerToys = (byte) (1 << 7);
	private static int blockChunkUpdatesOnWorldChangeMs = 15000;
	private static boolean initialized = false;
	private static boolean initializing = false;
	private final static Object initLock = new Object();
	private static int port = 50191;
	// private static Logger logger = Logger.getLogger("MCCLIENT");
	private static EventTcpServer server = null;
	private boolean sendNewWorldFile = false;
	private long chunksAllowedAfter = System.currentTimeMillis();
	private static int errors = 0;
	private boolean sendRandomChunkData = false;
	public static Logger logger;
	private static FileHandler fh;
	private static AM_MCWorld theWorld;
	private static long worldLoadedAt = 0L;
	private static boolean chatFlagDetected = false;
	private static byte permissionLevel = 13;
	private static Object chatLineLast = null;
	private static boolean requestPermissionConfirmation = true;
	private static boolean permissionConfirmed = true;
	private static boolean isMultiplayer = true;
	private static AutomapServer asInstance = new AutomapServer();

	private AutomapServer()
	{
		try
		{
			fh = new FileHandler("AutoMapServer.log");
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger = Logger.getLogger("AutoMapServer");
			logger.addHandler(fh);
			logger.setLevel(Level.ALL);
			logger.info("Logger Initialized");
		}
		catch (Exception ex)
		{
			AMW_ScreenOut.DisplayMessage("Exception occurred while loading AutoMap logger");
		}
	}

	public static void initialize(AM_MCWorld worldparam) throws Exception
	{
		// I'll be damned if I am going to cause the game to crash here.
		theWorld = worldparam;
		theWorld.setWorldChangedListener(asInstance);
		asInstance.WorldChanged(theWorld.isMultiplayer());
		synchronized (initLock)
		{
			if (initialized || initializing)
				return;
			initializing = true;
		}
		LogL4("About to start EventTcpServer");
		server = new EventTcpServer(port, asInstance);
		LogL4("Started EventTcpServer - it did not cause an exception yet");
		synchronized (initLock)
		{
			initializing = false;
			initialized = true;
		}
		logger.info("Initialization complete on port " + port + ". Ready for AutoMap to connect.");
	}

	private void BlockChunkUpdates(int msTime)
	{
		LogL4("Chunk updates blocked for " + msTime + " ms.");
		chunksAllowedAfter = System.currentTimeMillis() + msTime;
	}

	public byte[] getWorldChunk(byte[] request)
	{
		try
		{
			if (System.currentTimeMillis() < chunksAllowedAfter || !permissionConfirmed)
				return new byte[0];
			if (request.length < (INT_BYTES * 6) + 1)
				return new byte[0];
			boolean noLight = request[0] == GET_WORLD_CHUNK_NOLIGHT;
			int x, y, z, dx, dy, dz, reqIdx = 1;
			try
			{
				x = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				y = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				z = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				dx = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				dy = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				dz = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
			}
			catch (Exception ex)
			{
				errors++;
				return new byte[0];
			}
			byte[] bytes = new byte[request.length + (dx * dy * dz * (noLight ? 2 : 3))];
			// Put the original request into the array at the beginning.
			this.InsertBytes(bytes, 0, request);
			Location Correct = Location.Translate(x, y, z);
			if (sendRandomChunkData)
			{
				Random r = new Random();
				for (int a = 0; a < dy; a++)
					for (int b = 0; b < dx; b++)
						for (int c = 0; c < dz; c++)
							bytes[reqIdx++] = (byte) r.nextInt(128);
			}
			else
			{
				// Add block IDs, METAs, light levels
				for (int a = 0; a < dy; a++)
					for (int b = 0; b < dx; b++)
						for (int c = 0; c < dz; c++)
						{
							int nx = Correct.x + b;
							int ny = Correct.y + a;
							int nz = Correct.z + c;
							bytes[reqIdx++] = theWorld.getBlockId(nx, ny, nz);
							bytes[reqIdx++] = theWorld.getBlockMeta(nx, ny, nz);
							if (!noLight)
								bytes[reqIdx++] = theWorld.getBlockLight(nx, ny, nz + 1);
							// InsertBytes(bytes, reqIdx,
							// BitConverter.GetBytes(theWorld
							// .getBlockDisplayLight(nx, nz, ny)));
							// reqIdx += FLOAT_BYTES;
						}
			}
			return bytes;
		}
		catch (Exception ex)
		{
			LogL1("getWorldChunk error: " + ex.toString());
			return new byte[0];
		}
	}

	/**
	 * Format: packet type, x, y, z, rotation, pitch, player name which uses
	 * types byte, double, double, double, float, float, char[]
	 * 
	 * @return
	 */
	public byte[] getEntityLocations()
	{
		try
		{
			Vector<AM_MCEntity> entities = theWorld.getEntities();
			int playercount = entities.size();
			if (!permissionConfirmed && playercount > 1)
				playercount = 1;
			byte[][] playerNames = new byte[playercount][];
			int playerNamesTotalSize = 0;
			for (int i = 0; i < playercount; i++)
			{
				playerNames[i] = BitConverter.GetBytes(entities.elementAt(i).name);
				playerNamesTotalSize += playerNames[i].length;
			}
			int basePlayerSize = 37;
			int byteCounter = 0;
			byte[] playerNameArray = BitConverter.GetBytes(theWorld.getMe().name);
			byte[] playerNameSize = BitConverter.GetBytes(playerNameArray.length);
			byte[] bytes = new byte[1 + INT_BYTES + playerNameArray.length
					+ (basePlayerSize * playercount) + playerNamesTotalSize];
			bytes[byteCounter++] = GET_PLAYER_LOCATION;
			InsertBytes(bytes, byteCounter, playerNameSize);
			byteCounter += INT_BYTES;
			InsertBytes(bytes, byteCounter, playerNameArray);
			byteCounter += playerNameArray.length;
			for (int i = 0; i < playercount; i++)
			{
				AM_MCEntity mcp = entities.elementAt(i);
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(-mcp.x)); // X
				byteCounter += DOUBLE_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.y)); // Y
				byteCounter += DOUBLE_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.z)); // Z
				byteCounter += DOUBLE_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.rotation)); // Rotation
				byteCounter += FLOAT_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.pitch)); // Pitch
				byteCounter += FLOAT_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(playerNames[i].length)); // Name
																								// Size
				byteCounter += INT_BYTES;
				InsertBytes(bytes, byteCounter, playerNames[i]); // Name
				byteCounter += playerNames[i].length;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.isNPC)); // isNPC
																					// flag
				byteCounter += 1;
			}
			LogL6("AutomapServer.getEntityLocations() returning byte array of size: "
					+ bytes.length + ".  There were " + playercount + " entities.");
			return bytes;
		}
		catch (Exception ex)
		{
			LogL1("AutomapServer.getEntityLocations() failed.  Exception message: " + ex);
		}
		return new byte[0];
	}

	private byte[] getFilePath()
	{
		LogL5("Reading File Path");
		byte[] fp;
		String worldInfo = theWorld.getWorldInfo();
		if (worldInfo == null || worldInfo.equals(""))
		{
			LogL1("Unable to get world info");
			return new byte[0];
		}
		else
			fp = BitConverter.GetBytes(worldInfo);
		byte[] bytes = new byte[fp.length + 1];
		bytes[0] = GET_WORLD_PATH;
		InsertBytes(bytes, 1, fp);
		return bytes;
	}

	private void SetPlayerLocation(byte[] request)
	{
		try
		{
			if (request.length < (DOUBLE_BYTES * 3) + 1)
				return;
			double x, y, z;
			int reqIdx = 1;
			x = BitConverter.ToDouble(request, reqIdx);
			reqIdx += DOUBLE_BYTES;
			y = BitConverter.ToDouble(request, reqIdx);
			reqIdx += DOUBLE_BYTES;
			z = BitConverter.ToDouble(request, reqIdx);
			reqIdx += DOUBLE_BYTES;
			// LocationDouble Correct = LocationDouble.Translate(x, y, z);
			theWorld.getMe().SetPosition(-x, y, z);
		}
		catch (Exception ex)
		{
			LogL1("SetPlayerLocation error: " + ex.toString());
		}
	}

	private void CreateExplosion(byte[] request)
	{
		try
		{
			if (request.length < (DOUBLE_BYTES * 3) + FLOAT_BYTES + 1)
				return;
			double x, y, z;
			float power;
			int reqIdx = 1;
			x = BitConverter.ToDouble(request, reqIdx);
			reqIdx += DOUBLE_BYTES;
			y = BitConverter.ToDouble(request, reqIdx);
			reqIdx += DOUBLE_BYTES;
			z = BitConverter.ToDouble(request, reqIdx);
			reqIdx += DOUBLE_BYTES;
			power = BitConverter.ToSingle(request, reqIdx);
			reqIdx += FLOAT_BYTES;
			// LocationDouble Correct = LocationDouble.Translate(x, y, z);
			theWorld.CreateExplosion(y, z, -x, power);
		}
		catch (Exception ex)
		{
			LogL1("SetPlayerLocation error: " + ex.toString());
		}
	}

	@Override
	public void messageReceived(byte[] message, EventTcpClient client)
	{
		try
		{
			LogL6("Message Received. Length: " + message.length + ", First byte: "
					+ (message.length > 0 ? String.valueOf((int) message[0]) : "--"));
			theWorld.CheckWorldChange();
			if (sendNewWorldFile)
			{
				client.sendMessage(this.getFilePath());
				sendNewWorldFile = false;
			}
			if (requestPermissionConfirmation)
			{
				LogL3("Requesting confirmation of permission level " + permissionLevel);
				client.sendMessage(new byte[] { PERMISSION_CONFIRMATION, 1, permissionLevel });
				requestPermissionConfirmation = false;
			}
			byte[] response = null;
			if (message.length <= 0)
			{
				errors++;
				return;
			}
			byte messageType = message[0];
			if (messageType == GET_PLAYER_LOCATION)
			{
				response = getEntityLocations();
				if (response.length == 0)
					return;
			}
			else if (messageType == GET_WORLD_CHUNK || messageType == GET_WORLD_CHUNK_NOLIGHT)
			{
				byte[] responseDupe = new byte[0];
				int tryCount = 0;
				int maxTries = 10;
				do
				{ // Integrity Check the result!
					if (tryCount++ >= maxTries)
					{
						logger.log(Level.SEVERE, "Failed to get a correctly formed chunk "
								+ maxTries
								+ " times in a row.  Most recent chunk data follows:\r\n"
								+ ByteArrayToCommaString(responseDupe) + "\r\n"
								+ ByteArrayToCommaString(response));
						return;
					}
					response = getWorldChunk(message);
					if (response.length == 0)
						return;
					responseDupe = getWorldChunk(message);
					if (responseDupe.length == 0)
						return;
				}
				while (!ArraysMatch(response, responseDupe));
			}
			else if (messageType == GET_WORLD_PATH)
			{
				LogL5("File Path Requested by AM Client");
				response = getFilePath();
			}
			else if (messageType == SET_PLAYER_LOCATION)
			{
				LogL5("SET_PLAYER_LOCATION Requested by AM Client");
				SetPlayerLocation(message);
				return;
			}
			else if (messageType == CREATE_EXPLOSION)
			{
				LogL5("CREATE_EXPLOSION Requested by AM Client");
				CreateExplosion(message);
				return;
			}
			else if (messageType == PERMISSION_CONFIRMATION)
			{
				permissionConfirmed = true;
				LogL3("Permission Level Confirmed.  Activating mod.");
				return;
			}
			if (response != null && response.length > 0)
			{
				if (!client.sendMessage(response))
				{
					client.Disconnect();
					LogL2("Disconnecting!");
				}
			}
			else
			{
				errors++;
				LogL2("Empty response at end of MessageReceived() function.  Error count is now "
						+ errors + ".");
			}
		}
		catch (Exception ex)
		{
			LogL1("AutomapServer.messageReceived() failed.  Exception message: " + ex);
			EventTcpServer.ReportException(ex, "Exception in message handler: ");
		}
	}

	@Override
	public void disconnected(EventTcpClient client)
	{
		server.removeClient(client);
		LogL2("AutoMap Client Disconnected!");
	}

	@Override
	public void connected(EventTcpClient client)
	{
		LogL3("AutoMap Client Connected!");
		SetPermissionsForNewWorld(false);
	}

	public void InsertBytes(byte[] destination, int destinationOffset, byte[] source)
	{
		if (destination.length - destinationOffset < source.length)
			return;
		for (int i = 0; i < source.length; i++, destinationOffset++)
			destination[destinationOffset] = source[i];
	}

	private String ByteArrayToCommaString(byte[] message)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < message.length; i++)
		{
			sb.append(message[i]);
			sb.append(',');
		}
		return sb.toString();
	}

	@SuppressWarnings("unused")
	private String ByteArrayToMultilineString(byte[] message)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < message.length; i++)
		{
			sb.append(message[i]);
			sb.append("\r\n");
		}
		return sb.toString();
	}

	private boolean ArraysMatch(byte[] response, byte[] responseDupe)
	{
		if (response.length != responseDupe.length)
			return false;
		for (int i = 0; i < response.length; i++)
			if (response[i] != responseDupe[i])
				return false;
		return true;
	}

	@SuppressWarnings("unused")
	private static boolean AccurateStringCompare(String one, String two)
	{
		if (one.length() != two.length())
			return false;
		for (int i = 0; i < one.length(); i++)
		{
			if (one.charAt(i) != two.charAt(i))
				return false;
		}
		return true;
	}

	@Override
	public void WorldChanged(boolean isMultiplayer)
	{
		LogL3("World Change Detected (" + (isMultiplayer ? "Multi Player)" : "Single Player)"));
		asInstance.BlockChunkUpdates(blockChunkUpdatesOnWorldChangeMs);
		asInstance.sendNewWorldFile = true;
		AutomapServer.isMultiplayer = isMultiplayer;
		SetPermissionsForNewWorld(true);
	}

	private void SetPermissionsForNewWorld(boolean isNewWorld)
	{
		if (isMultiplayer)
		{
			if (isNewWorld)
			{
				worldLoadedAt = System.currentTimeMillis();
				permissionLevel = (byte) 255;
				chatFlagDetected = false;
			}
			permissionConfirmed = false;
			requestPermissionConfirmation = true;
		}
		else
		{
			permissionLevel = 0;
			permissionConfirmed = true;
			requestPermissionConfirmation = true;
		}
	}

	public static void tick()
	{
		try
		{
			if (!chatFlagDetected && System.currentTimeMillis() < worldLoadedAt + 10000L)
			{
				@SuppressWarnings("rawtypes")
				List chatLineList = AMW_ScreenOut.GetChatLineList();
				@SuppressWarnings("rawtypes")
				Iterator chatIterator = chatLineList.iterator();
				Object chatItem;
				while (chatIterator.hasNext())
				{
					chatItem = chatIterator.next();
					if ((chatItem == null) || (chatLineLast == chatItem))
						break;
					Matcher localMatcher = Pattern.compile("�0�0((?:�[1-9a-d])+)�f�e").matcher(
							AMW_ScreenOut.GetChatString(chatItem));
					if (localMatcher.find())
					{
						permissionLevel = 0;
						chatFlagDetected = true;
						String match = localMatcher.group(1);
						if (match.contains("�1")) // Ore detection
							permissionLevel += p_OreDetection;
						if (match.contains("�2")) // Cave mapping
							permissionLevel += p_CaveMap;
						if (match.contains("�3")) // Player detection
							permissionLevel += p_Players;
						if (match.contains("�4")) // Hostile NPC detection
							permissionLevel += p_HostileNPCs;
						if (match.contains("�5")) // Passive NPC detection
							permissionLevel += p_PassiveNPCs;
						if (match.contains("�6")) // Neutral NPC detection
							permissionLevel += p_NeutralNPCs;
						if (match.contains("�7")) // Item detection
							permissionLevel += p_Items;
						if (match.contains("�8")) // Power Toys
							permissionLevel += p_PowerToys;
						LogL3("Server specifies permission level " + permissionLevel);
						permissionConfirmed = false;
						requestPermissionConfirmation = true;
						break;
					}
				}
				chatLineLast = chatLineList.isEmpty() ? null : chatLineList.get(0);
			}
			else if (!chatFlagDetected)
			{
				LogL3("Server does not specify a permission level. Granting full permissions.");
				chatLineLast = null;
				chatFlagDetected = true;
				permissionLevel = 0;
				permissionConfirmed = false;
				requestPermissionConfirmation = true;
			}
			else if (chatLineLast != null)
			{
				chatLineLast = null;
			}
		}
		catch (Exception ex)
		{
			LogL1("Error in AutoMapServer.tick(). Exception message: " + ex);
		}
	}
}

class Location
{
	int x, y, z;

	public Location(int x, int y, int z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static Location Translate(int x, int y, int z)
	{
		x = -x - 1;
		int tempx = y;
		y = x;
		x = tempx;
		return new Location(x, y, z);
	}
}

class LocationDouble
{
	double x, y, z;

	public LocationDouble(double x, double y, double z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static LocationDouble Translate(double x, double y, double z)
	{
		x = -x - 1;
		double tempx = y;
		y = x;
		x = tempx;
		return new LocationDouble(x, y, z);
	}
}
