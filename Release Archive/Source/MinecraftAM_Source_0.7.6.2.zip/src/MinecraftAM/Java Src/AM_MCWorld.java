import java.io.File;
// import java.lang.reflect.Field;
import java.util.List;
import java.util.Vector;

// import net.minecraft.client.Minecraft;

/*
 private long F = System.currentTimeMillis();
 protected int j = 40;
 public int k;
 public Random l = new Random();
 public int m;
 public int n;
 public int o;
 public boolean p = false;
 public final ou q;
 protected List r = new ArrayList();
 private bd G;
 public File s;
 public File t;   World Folder (the second File)
 public long u = 0L;
 private in H;
 public long v = 0L;
 public final String w;
 public boolean x;
 private ArrayList I = new ArrayList();
 */
/**
 * 
 * @author Brian
 */
public class AM_MCWorld
{
	private AMW_Minecraft game;
	private AM_WorldChangedListener wcl = null;

	public void setWorldChangedListener(AM_WorldChangedListener listener)
	{
		wcl = listener;
	}

	private void worldChanged()
	{
		if (wcl != null)
			wcl.WorldChanged(isMultiplayer());
	}

	public AM_MCWorld(AMW_Minecraft paramgame)
	{
		game = paramgame;
		lastWorld = getWorld();
	}

	// /////////////////////////////////

	private AMW_World lastWorld = null;

	private AMW_World getWorld()
	{
		if(lastWorld == null)
			lastWorld = game.getWorld();
		return lastWorld;
	}

	public void CheckWorldChange()
	{
		if (game.checkWorldChanged(lastWorld.inst))
		{
			lastWorld = game.getWorld();
			worldChanged();
		}
	}

	
	/**
	 * Returns a File object pointing at the loaded world directory.
	 * 
	 * @return
	 */
	public String getWorldInfo()
	{
		AMW_WorldInfo wInfo = getWorld().getWorldInfo();
		
		String worldName = wInfo.getName();

		String dimension = getWorld().getDimension();

		String spawnX = String.valueOf(wInfo.getSpawnX());
		String spawnY = String.valueOf(wInfo.getSpawnY());
		String spawnZ = String.valueOf(wInfo.getSpawnZ());

		// If this is multiplayer, that is all we need
		if (worldName.equals("MpServer"))
		{
			worldName = game.getSMPHost();
			return "multiplayer|" + dimension + "|" + worldName + "|" + spawnX
					+ "|" + spawnY + "|" + spawnZ;
		}

		// Get the worldDataLoader object
		AMW_WorldDataLoader worldDataLoader = getWorld().getWorldDataLoader();
		File worldFilePath = worldDataLoader.getWorldFilePath();
		
		// Got it! Return it.
		return worldFilePath.getAbsolutePath() + "|" + dimension + "|"
				+ worldName + "|" + spawnX + "|" + spawnY + "|" + spawnZ;
	}

	// world.e is something similar that seems to detect
	// torches or light or object rotation or something
	// and display them using the first few integers
	// (0-4?)
	public byte getBlockId(int x, int y, int z)
	{
		return getWorld().getBlockId(x, y, z);
	}
	public byte getBlockMeta(int x, int y, int z)
	{
		return getWorld().getBlockMeta(x, y, z);
	}
	// world.e is something similar that seems to detect
	// torches or light or object rotation or something
	// and display them using the first few integers
	// (0-4?)
	public byte getBlockLight(int x, int y, int z)
	{
		return getWorld().getBlockLight(x, y, z);
	}
	public AM_MCEntity getMe()
	{
		return new AM_MCEntity(/* Player Object */game.getPlayer());
	}
	
	public Vector<AM_MCEntity> getEntities()
	{
		try
		{
			Vector<AM_MCEntity> entities = new Vector<AM_MCEntity>();
			List<?> playerList = getWorld().GetPlayerList(); 
			for (int i = 0; i < playerList.size(); i++)
			{
				Object obj = playerList.get(i);
				if (AMW_Player.wrappedClass.isInstance(obj))
					entities.add(new AM_MCEntity(new AMW_Player(AMW_Player.wrappedClass.cast(obj))));
			}
			List<?> npcList = getWorld().GetNPCList();
			for (int i = 0; i < npcList.size(); i++)
			{
				Object obj = npcList.get(i);
				if (AMW_Player.wrappedClass.isInstance(obj))
					continue;
				else if (AMW_NamedEntity.wrappedClass.isInstance(obj))
					entities.add(new AM_MCEntity(new AMW_NamedEntity(AMW_NamedEntity.wrappedClass.cast(obj))));
				else if (AMW_Item.wrappedClass.isInstance(obj))
					entities.add(new AM_MCEntity(new AMW_Item(AMW_Item.wrappedClass.cast(obj))));
				else if (AMW_Entity.wrappedClass.isInstance(obj))
					entities.add(new AM_MCEntity(new AMW_Entity(AMW_Entity.wrappedClass.cast(obj))));
			}
			return entities;
		} catch (Exception ex)
		{
			AutomapServer.logger
					.severe("MCWorld.getEntities() failed.  Exception message: "
							+ ex);
		}
		return null;
	}
	
	public void CreateExplosion(double x, double y, double z, float power)
	{
		getWorld().CreateExplosion(x, y, z, power);
	}

	public boolean isMultiplayer()
	{
		return getWorld().getWorldInfo().getName().equals("MpServer");
	}
}
