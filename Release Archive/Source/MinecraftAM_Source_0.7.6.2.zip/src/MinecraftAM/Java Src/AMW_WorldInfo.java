public class AMW_WorldInfo
{
	// Find this class with "SizeOnDisk"
	// Fixed 17
	net.minecraft.src.WorldInfo inst;
	// Fixed 17
	public AMW_WorldInfo(net.minecraft.src.WorldInfo param)
	{
		inst = param;
	}
	public String getName()
	{
		// Fixed 17
		return inst.getWorldName();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Minecraft's Z
		// Fixed 17
		return inst.getSpawnZ() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Minecraft's X
		// Fixed 17
		return inst.getSpawnX();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Minecraft's Y
		// Fixed 17
		return inst.getSpawnY();
	}
}
