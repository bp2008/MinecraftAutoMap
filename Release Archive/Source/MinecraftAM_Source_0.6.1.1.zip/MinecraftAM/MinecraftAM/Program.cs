using System;

namespace MinecraftAM
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            using (Game1 game = new Game1())
            {
                try
                {
                    game.Run();
                }
                catch (Exception err)
                {
                    System.IO.File.WriteAllText("crashdump.txt", err.ToString());
                }
            }
        }
    }
}

