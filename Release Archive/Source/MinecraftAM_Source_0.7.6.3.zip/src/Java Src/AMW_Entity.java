public class AMW_Entity
{
	// Fixed 17
	public static final Class<net.minecraft.src.Entity> wrappedClass = net.minecraft.src.Entity.class;
	// Fixed 17
	public net.minecraft.src.Entity inst;
	// Fixed 17
	public AMW_Entity(net.minecraft.src.Entity param)
	{
		inst = param;
	}
	
	public String getName()
	{
		// Find the class by searching for "Creeper"
		// Fixed 17
		String name = net.minecraft.src.EntityList.getEntityString(inst);
		if (name == null || name.equals(""))
			name = "unknown_entity";
		return name;
	}
	
	public double getX()
	{
		// These 3 are down below in the SetPosition Function in decompiled source. 
		//    -- Not far down the page
		// Third double. (Minecraft's Z)
		// Fixed 17
		return inst.posZ;
	}

	public double getY()
	{
		// First double. (Minecraft's X)
		// Fixed 17
		return inst.posX;
	}

	public double getZ()
	{
		// Second double. (Minecraft's Y)
		// Fixed 17
		return inst.posY;
	}
	
	public void setPosition(double x, double y, double z)
	{
		// This function is called in the first Entity constructor.
		// This is also the function mentioned above in getX()'s comments.
		//
		// Fixed 17
		inst.setPosition(y,z,x);
		/* It looks kind of like this:
	public void d(double paramDouble1, double paramDouble2, double paramDouble3) {
    	this.aM = paramDouble1;
    	this.aN = paramDouble2;
    	this.aO = paramDouble3;
    	float f1 = this.bg / 2.0F;
    	float f2 = this.bh;
    	this.aW.c(paramDouble1 - f1, paramDouble2 - this.bf + this.bo, paramDouble3 - f1, paramDouble1 + f1, paramDouble2 - this.bf + this.bo + f2, paramDouble3 + f1);
  	}
		 */
	}

	public float getRotation(boolean useAlternateRotationValue)
	{
		// Fixed 17
		return useAlternateRotationValue ? inst.prevRotationYaw : inst.rotationYaw;
	}

	public float getPitch(boolean useAlternateRotationValue)
	{
		// Fixed 17
		return useAlternateRotationValue ? inst.prevRotationPitch : inst.rotationPitch;
	}
}
