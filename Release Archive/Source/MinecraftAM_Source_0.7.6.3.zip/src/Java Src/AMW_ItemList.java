
public class AMW_ItemList
{
	// Find class with "shovelIron"
	public static int getImageIndex(int itemID)
	{
		// first int after the items are declared. this one is declared final
		// Fixed 17
		return net.minecraft.src.Item.itemsList[itemID].getIconFromDamage(0);
	}
	public static String getName(int itemID)
	{
		// Near the bottom (sort of)
		// Fixed 17
		//
		String name = net.minecraft.src.Item.itemsList[itemID].getItemName();
		if(name == null || name.equals(""))
			name = "unknown_item";
		return name;
		// The following version supposedly gets a cleaner name but it doesn't really work:
//		String itemName = net.minecraft.src.Item.itemsList[itemID].getItemName();
//        if (itemName == null)
//        	itemName = "";
//        else
//        	itemName = net.minecraft.src.StatCollector.translateToLocal(itemName);
//		String itemNameNew = net.minecraft.src.StringTranslate.getInstance().translateNamedKey(itemName);
//		return itemNameNew;
	}
}
