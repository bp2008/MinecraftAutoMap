
public class AMW_BlockList
{
	// Find this class with "stonebrick"
	public static String getName(int itemID)
	{
		// Function can be found near the bottom.
		// Fixed 17
		String name = net.minecraft.src.Block.blocksList[itemID].getBlockName();
		if(name == null || name.equals(""))
			name = "unknown_block";
		return name;
		// The following supposedly returns a cleaner name but it doesn't really:
		//return net.minecraft.src.Block.blocksList[itemID].translateBlockName();
	}
}
