public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 10
	public static final Class<lo> wrappedClass = lo.class;
	// Fixed 10
	public lo inst;
	// Fixed 10
	public AMW_NamedEntity(lo param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity")
			name = null;
		if (name == null || name.equals(""))
			// Fixed 10
			name = inst.i_(); // fully qualified name?
		if (name == null || name.equals(""))
			// Fixed 10
			name = inst.O; // entity texture?
		if (name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
