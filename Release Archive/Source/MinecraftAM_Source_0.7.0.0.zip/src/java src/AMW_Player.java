public class AMW_Player extends AMW_NamedEntity
{
	// Fixed 10
	public static final Class<gq> wrappedClass = gq.class;
	// Fixed 10
	public gq inst;
	// Fixed 10
	public AMW_Player(gq param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		// first String, not far at all down the page, should be 2 strings total, close together
		// Fixed 10
		return inst.l;
	}
}
