/*
 * public abstract class lr
{
  private static int a = 0;

  public int am = a++;

  public double an = 1.0D;

  public boolean ao = false;
  public lr ap;
  public lr aq;
  public cw ar;
  public double as;
  public double at;
  public double au;
  public double av; Y
  public double aw; Z
  public double ax; X
  public double ay;
  public double az;
  public double aA;
  public float aB; Rotation
  public float aC; Pitch
  public float aD;
  public float aE;
  public final cn aF = cn.a(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
  public boolean aG = false;
  public boolean aH;
  public boolean aI;
  public boolean aJ = false;
 */

/**
 * 
 * @author Brian
 */
public class AM_MCEntity
{
	// String o = Player Name
	// double aH = Player x
	// double aF = Player y
	// double aG = Player z
	// float aL = Player Rotation
	// float aM = Player Pitch
	// //////// dn aB = world object;//////////
	// Player: fm
	// NamedEntity: jm
	// Entity: pb
	// Item: gb (has lots of field/function usage)
	// ItemList: fg
	// BlockList: ra
	// 
	//
	//
	String name = "";
	double x = 0;
	double y = 0;
	double z = 0;
	float rotation = 0;
	float pitch = 0;
	boolean isNPC = false;

	public AM_MCEntity(AMW_Player playerObj)
	{
		name = playerObj.getName();
		initLocation(playerObj);
	}

	public AM_MCEntity(AMW_NamedEntity namedEntity)
	{
		name = namedEntity.getName();
		isNPC = true;
		initLocation(namedEntity);
	}

	public AM_MCEntity(AMW_Entity entity)
	{
		name = entity.getName();
		isNPC = true;
		if (name.equals("Arrow"))
			initLocation(entity, false, true, 215);
		else if (name.equals("Snowball"))
			initLocation(entity, false, true, 0);
		else if (name.equals("Minecart") || name.equals("Boat"))
			initLocation(entity, false, false, 90);
		else
			initLocation(entity, false, false, 0);
	}

	public AM_MCEntity(AMW_Item item)
	{
		// Item has the strings "id", "Count" and "Damage" and can be found in
		// the entity listing class.
		name = "Unknown";
		try
		{
			String temp = item.getName();
			if(temp.equals(""))
				AutomapServer.LogL2("Bad item ID: " + item.getID());
			else
				name = temp;
			isNPC = true;
			initLocation(item);
		} catch (Exception ex)
		{
			AutomapServer.LogL2("Unable to handle item ID: " + item.getID());
		}
	}

	private void initLocation(AMW_Entity entity, boolean useAlternateRotationValue,
			boolean invertRotationY, int rotationModifier)
	{
		x = entity.getX();
		y = entity.getY();
		z = entity.getZ();
		rotation = entity.getRotation(useAlternateRotationValue);
		pitch = entity.getPitch(useAlternateRotationValue);
		rotation = rotation % 360 + rotationModifier;
		if (invertRotationY)
			rotation = 180 - rotation;
		// rotation = -1 * rotation;
	}

	private void initLocation(AMW_Entity entity, boolean useAlternateRotationValue,
			boolean invertRotationY)
	{
		initLocation(entity, useAlternateRotationValue, invertRotationY, 0);
	}

	private void initLocation(AMW_Entity entity, boolean useAlternateRotationValue)
	{
		initLocation(entity, useAlternateRotationValue, false);
	}

	private void initLocation(AMW_Entity entity)
	{
		initLocation(entity, false);
	}
}
