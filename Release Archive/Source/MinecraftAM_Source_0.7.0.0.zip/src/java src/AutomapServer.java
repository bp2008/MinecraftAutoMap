import java.util.Random;
import java.util.Vector;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.brian.eventtcp.BitConverter;
import org.brian.eventtcp.EventTcpClient;
import org.brian.eventtcp.EventTcpClientListener;
import org.brian.eventtcp.EventTcpServer;

/**
 * 
 * @author Brian
 */
public class AutomapServer implements EventTcpClientListener,
		AM_WorldChangedListener
{
	private static int loggingLevel = 4;

	public static void LogL1(String message)
	{
		if (loggingLevel >= 1)
			logger.severe(message);
	}

	public static void LogL2(String message)
	{
		if (loggingLevel >= 1)
			logger.warning(message);
	}

	public static void LogL3(String message)
	{
		if (loggingLevel >= 4)
			logger.info(message);
	}

	public static void LogL4(String message)
	{
		if (loggingLevel >= 4)
			logger.fine(message);
	}

	public static void LogL5(String message)
	{
		if (loggingLevel >= 5)
			logger.finer(message);
	}

	public static void LogL6(String message)
	{
		if (loggingLevel >= 6)
			logger.finest(message);
	}

	// private static final int SHORT_BYTES = 2;
	private static final int INT_BYTES = 4;
	// private static final int LONG_BYTES = 8;
	private static final int FLOAT_BYTES = 4;
	private static final int DOUBLE_BYTES = 8;
	private static final byte GET_PLAYER_LOCATION = 0;
	private static final byte GET_WORLD_CHUNK = 1;
	// private static final byte GET_FULL_COLUMN = 2;
	private static final byte GET_WORLD_PATH = 20;
	private static int blockChunkUpdatesOnWorldChangeMs = 10000;
	private static boolean initialized = false;
	private static boolean initializing = false;
	private final static Object initLock = new Object();
	private static int port = 50191;
	// private static Logger logger = Logger.getLogger("MCCLIENT");
	private static EventTcpServer server = null;
	private boolean sendNewWorldFile = false;
	private long chunksAllowedAfter = System.currentTimeMillis();
	private static int errors = 0;
	private boolean sendRandomChunkData = false;
	public static Logger logger = Logger.getLogger("AutoMapServer");
	private static FileHandler fh;
	private static AM_MCWorld theWorld;
	private static AutomapServer asInstance = new AutomapServer();

	private AutomapServer()
	{
	}

	public static void initialize(AM_MCWorld worldparam) throws Exception
	{
		// I'll be damned if I am going to cause the game to crash here.
		asInstance.WorldChanged();
		theWorld = worldparam;
		theWorld.setWorldChangedListener(asInstance);
		synchronized (initLock)
		{
			if (initialized || initializing)
				return;
			initializing = true;
		}
		try
		{
			fh = new FileHandler("AutoMapServer.log");
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger.addHandler(fh);
			logger.setLevel(Level.ALL);
			logger.info("Logger Initialized");
		} catch (Exception ex)
		{
			AMW_ScreenOut
					.DisplayMessage("Exception occurred while loading AutoMap logger");
		}
		LogL4("About to start EventTcpServer");
		server = new EventTcpServer(port, asInstance);
		LogL4("Started EventTcpServer - it did not cause an exception yet");
		synchronized (initLock)
		{
			initializing = false;
			initialized = true;
		}
		logger.info("Initialization complete on port " + port
				+ ". Ready for AutoMap to connect.");
	}

	private void BlockChunkUpdates(int msTime)
	{
		LogL4("Chunk updates blocked for " + msTime + " ms.");
		chunksAllowedAfter = System.currentTimeMillis() + msTime;
	}

	public byte[] getWorldChunk(byte[] request)
	{
		try
		{
			if (System.currentTimeMillis() < chunksAllowedAfter)
				return new byte[0];
			if (request.length < (INT_BYTES * 6) + 1)
				return new byte[0];
			int x, y, z, dx, dy, dz, reqIdx = 1;
			try
			{
				x = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				y = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				z = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				dx = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				dy = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
				dz = BitConverter.ToInt32(request, reqIdx);
				reqIdx += INT_BYTES;
			} catch (Exception ex)
			{
				errors++;
				return new byte[0];
			}
			byte[] bytes = new byte[request.length + (dx * dy * dz * 3)];
			// Put the original request into the array at the beginning.
			this.InsertBytes(bytes, 0, request);
			Location Correct = Location.Translate(x, y, z);
			if (sendRandomChunkData)
			{
				Random r = new Random();
				for (int a = 0; a < dy; a++)
					for (int b = 0; b < dx; b++)
						for (int c = 0; c < dz; c++)
							bytes[reqIdx++] = (byte) r.nextInt(128);
			} else
			{
				// Add block IDs, METAs, light levels
				for (int a = 0; a < dy; a++)
					for (int b = 0; b < dx; b++)
						for (int c = 0; c < dz; c++)
						{
							int nx = Correct.x + b;
							int ny = Correct.y + a;
							int nz = Correct.z + c;
							bytes[reqIdx++] = theWorld.getBlockId(nx, ny, nz);
							bytes[reqIdx++] = theWorld.getBlockMeta(nx, ny, nz);
							bytes[reqIdx++] = theWorld
									.getBlockLight(nx, ny, nz);
							// InsertBytes(bytes, reqIdx,
							// BitConverter.GetBytes(theWorld
							// .getBlockDisplayLight(nx, nz, ny)));
							// reqIdx += FLOAT_BYTES;
						}
			}
			return bytes;
		} catch (Exception ex)
		{
			LogL1("getWorldChunk error: " + ex.toString());
			return new byte[0];
		}
	}

	/**
	 * Format: packet type, x, y, z, rotation, pitch, player name which uses
	 * types byte, double, double, double, float, float, char[]
	 * 
	 * @return
	 */
	public byte[] getEntityLocations()
	{
		try
		{
			Vector<AM_MCEntity> entities = theWorld.getEntities();
			int playercount = entities.size();
			byte[][] playerNames = new byte[playercount][];
			int playerNamesTotalSize = 0;
			for (int i = 0; i < playercount; i++)
			{
				playerNames[i] = BitConverter
						.GetBytes(entities.elementAt(i).name);
				playerNamesTotalSize += playerNames[i].length;
			}
			int basePlayerSize = 37;
			int byteCounter = 0;
			byte[] playerNameArray = BitConverter
					.GetBytes(theWorld.getMe().name);
			byte[] playerNameSize = BitConverter
					.GetBytes(playerNameArray.length);
			byte[] bytes = new byte[1 + INT_BYTES + playerNameArray.length
					+ (basePlayerSize * playercount) + playerNamesTotalSize];
			bytes[byteCounter++] = GET_PLAYER_LOCATION;
			InsertBytes(bytes, byteCounter, playerNameSize);
			byteCounter += INT_BYTES;
			InsertBytes(bytes, byteCounter, playerNameArray);
			byteCounter += playerNameArray.length;
			for (int i = 0; i < playercount; i++)
			{
				AM_MCEntity mcp = entities.elementAt(i);
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(-mcp.x)); // X
				byteCounter += DOUBLE_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.y)); // Y
				byteCounter += DOUBLE_BYTES;
				InsertBytes(bytes, byteCounter, BitConverter.GetBytes(mcp.z)); // Z
				byteCounter += DOUBLE_BYTES;
				InsertBytes(bytes, byteCounter,
						BitConverter.GetBytes(mcp.rotation)); // Rotation
				byteCounter += FLOAT_BYTES;
				InsertBytes(bytes, byteCounter,
						BitConverter.GetBytes(mcp.pitch)); // Pitch
				byteCounter += FLOAT_BYTES;
				InsertBytes(bytes, byteCounter,
						BitConverter.GetBytes(playerNames[i].length)); // Name
																		// Size
				byteCounter += INT_BYTES;
				InsertBytes(bytes, byteCounter, playerNames[i]); // Name
				byteCounter += playerNames[i].length;
				InsertBytes(bytes, byteCounter,
						BitConverter.GetBytes(mcp.isNPC)); // isNPC flag
				byteCounter += 1;
			}
			LogL6("AutomapServer.getEntityLocations() returning byte array of size: "
					+ bytes.length
					+ ".  There were "
					+ playercount
					+ " entities.");
			return bytes;
		} catch (Exception ex)
		{
			LogL1("AutomapServer.getEntityLocations() failed.  Exception message: "
					+ ex.getMessage());
		}
		return new byte[0];
	}

	private byte[] getFilePath()
	{
		LogL5("Reading File Path");
		byte[] fp;
		String worldInfo = theWorld.getWorldInfo();
		if (worldInfo == null || worldInfo.equals(""))
		{
			LogL1("Unable to get world info");
			return new byte[0];
		} else
			fp = BitConverter.GetBytes(worldInfo);
		byte[] bytes = new byte[fp.length + 1];
		bytes[0] = GET_WORLD_PATH;
		InsertBytes(bytes, 1, fp);
		return bytes;
	}

	@Override
	public void messageReceived(byte[] message, EventTcpClient client)
	{
		try
		{
			LogL6("Message Received. Length: "
					+ message.length
					+ ", First byte: "
					+ (message.length > 0 ? String.valueOf((int) message[0])
							: "--"));
			theWorld.CheckWorldChange();
			if (sendNewWorldFile)
			{
				client.sendMessage(this.getFilePath());
				sendNewWorldFile = false;
			}
			byte[] response = null;
			if (message.length <= 0)
			{
				errors++;
				return;
			}
			byte messageType = message[0];
			if (messageType == GET_PLAYER_LOCATION)
				response = getEntityLocations();
			else if (messageType == GET_WORLD_CHUNK)
			{
				byte[] responseDupe = new byte[0];
				int tryCount = 0;
				int maxTries = 10;
				do
				{ // Integrity Check the result!
					if (tryCount++ >= maxTries)
					{
						logger.log(
								Level.SEVERE,
								"Failed to get a correctly formed chunk "
										+ maxTries
										+ " times in a row.  Most recent chunk data follows:\r\n"
										+ ByteArrayToCommaString(responseDupe)
										+ "\r\n"
										+ ByteArrayToCommaString(response));
						return;
					}
					response = getWorldChunk(message);
					if (response.length == 0)
						return;
					responseDupe = getWorldChunk(message);
					if (responseDupe.length == 0)
						return;
				} while (!ArraysMatch(response, responseDupe));
			} else if (messageType == GET_WORLD_PATH)
			{
				LogL5("File Path Requested by AM Client");
				response = getFilePath();
			}
			if (response != null && response.length > 0)
			{
				if (!client.sendMessage(response))
				{
					client.Disconnect();
					LogL2("Disconnecting!");
				}
			} else
			{
				errors++;
				LogL2("Empty response at end of MessageReceived() function.  Error count is now "
						+ errors + ".");
			}
		} catch (Exception ex)
		{
			LogL1("AutomapServer.messageReceived() failed.  Exception message: "
					+ ex.getMessage());
			EventTcpServer
					.ReportException(ex, "Exception in message handler: ");
		}
	}

	@Override
	public void disconnected(EventTcpClient client)
	{
		server.removeClient(client);
		LogL2("Disconnected!");
	}

	public void InsertBytes(byte[] destination, int destinationOffset,
			byte[] source)
	{
		if (destination.length - destinationOffset < source.length)
			return;
		for (int i = 0; i < source.length; i++, destinationOffset++)
			destination[destinationOffset] = source[i];
	}

	private String ByteArrayToCommaString(byte[] message)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < message.length; i++)
		{
			sb.append(message[i]);
			sb.append(',');
		}
		return sb.toString();
	}

	@SuppressWarnings("unused")
	private String ByteArrayToMultilineString(byte[] message)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < message.length; i++)
		{
			sb.append(message[i]);
			sb.append("\r\n");
		}
		return sb.toString();
	}

	private boolean ArraysMatch(byte[] response, byte[] responseDupe)
	{
		if (response.length != responseDupe.length)
			return false;
		for (int i = 0; i < response.length; i++)
			if (response[i] != responseDupe[i])
				return false;
		return true;
	}

	@SuppressWarnings("unused")
	private static boolean AccurateStringCompare(String one, String two)
	{
		if (one.length() != two.length())
			return false;
		for (int i = 0; i < one.length(); i++)
		{
			if (one.charAt(i) != two.charAt(i))
				return false;
		}
		return true;
	}

	@Override
	public void WorldChanged()
	{
		LogL4("World Change Detected");
		asInstance.BlockChunkUpdates(blockChunkUpdatesOnWorldChangeMs);
		asInstance.sendNewWorldFile = true;
	}
}

class Location
{
	int x, y, z;

	public Location(int x, int y, int z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static Location Translate(int x, int y, int z)
	{
		x = -x - 1;
		int tempx = y;
		y = x;
		x = tempx;
		return new Location(x, y, z);
	}
}
