public class AMW_Entity
{
	// Fixed 10
	public static final Class<si> wrappedClass = si.class;
	// Fixed 10
	public si inst;
	// Fixed 10
	public AMW_Entity(si param)
	{
		inst = param;
	}

	public String getName()
	{
		// Fixed 10
		String name = iz.b(inst);
		if (name == null || name.equals(""))
			name = "unknown_entity";
		return name;
	}
	
	public double getX()
	{
		// Fixed 10
		return inst.aO;
	}

	public double getY()
	{
		// Fixed 10
		return inst.aM;
	}

	public double getZ()
	{
		// Fixed 10
		return inst.aN;
	}

	public float getRotation(boolean useAlternateRotationValue)
	{
		// Fixed 10
		return useAlternateRotationValue ? inst.aU : inst.aS;
	}

	public float getPitch(boolean useAlternateRotationValue)
	{
		// Fixed 10
		return useAlternateRotationValue ? inst.aV : inst.aT;
	}
}
