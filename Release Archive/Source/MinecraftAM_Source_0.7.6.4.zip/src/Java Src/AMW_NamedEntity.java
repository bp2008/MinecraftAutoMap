public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 17
	public static final Class<net.minecraft.src.EntityLiving> wrappedClass = net.minecraft.src.EntityLiving.class;
	// Fixed 17
	public net.minecraft.src.EntityLiving inst;

	// Fixed 17
	public AMW_NamedEntity(net.minecraft.src.EntityLiving param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity")
			name = null;
		
		//
		// This calls a protected function and it doesn't seem to work with MCP.
		//
		
//		if (name == null || name.equals(""))
//			// Find with "damage.hurtflesh"
//			//
//			// Fixed 16
//			name = inst.getHurtSound(); // fully qualified name? Or perhaps sound file ID
		
		
		//
		// MCP doesn't me me access the protected field, so I have to use this public accessor.
		//
		if (name == null || name.equals(""))
			// Fixed 17
			name = inst.getTexture(); // entity texture? (String literal at the top of the file)
		
		if (name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
