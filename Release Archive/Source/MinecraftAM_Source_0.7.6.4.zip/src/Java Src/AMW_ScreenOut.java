import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiIngame;

public class AMW_ScreenOut
{
	private static Minecraft mc;
	private static GuiIngame mcGui;

	public static void Initialize(Minecraft parammc)
	{
		mc = parammc;
		// This is the same as the object used below in DisplayMessage
		// Fixed 17
		mcGui = mc.ingameGUI; // GuiIngame class
	}

	public static void DisplayMessage(String message)
	{
		// Scroll to bottom to find this function
		// Fixed 20
		mc.thePlayer.addChatMessage("�E" + message);
	}

	@SuppressWarnings("rawtypes")
	public static List GetChatLineList()
	{
		try
		{
			// Just fix the one string literal here, which is the List object at
			// the top of mcGui
			// Fixed 17
			//
			// OLD AND NOW UNNECESSARY FIRST THING:
			// Find deobf class: GuiIngame. Find obf class with
			// "Allocated memory". Look for instance of GuiNewChat. Find the
			// public accessor function and call it here on mcGui in TWO PLACES.
			// As of fix 20, this was named .func_73827_b(). As of fix 21, this
			// was named getChatGUI()
			//
			// MCP FIX 21
			// Find the equivalent to the GuiNewChat class in obfuscated code.
			// It can be found by following the "FIRST THING" steps above.
			// Open that class. The string is the obfuscated name of the
			// ChatLines list in the GuiNewChat class.
			Field privateFieldChatLineList = mcGui.getChatGUI().getClass().getDeclaredField("c");
			privateFieldChatLineList.setAccessible(true);
			Object cLL = privateFieldChatLineList.get(mcGui.getChatGUI());
			if (!(cLL instanceof List))
			{
				AutomapServer
						.LogL1("GetChatLineList() failed.  The Chat Line List field is not an instance of List.");
				return new ArrayList();
			}
			return (List) cLL;
		}
		catch (SecurityException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  SecurityException was thrown when trying to get the Chat Line List.");
			return new ArrayList();
		}
		catch (NoSuchFieldException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  The World Data Loader field did not exist inside the Chat Line List.");
			return new ArrayList();
		}
		catch (IllegalArgumentException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  IllegalArgumentException was thrown when trying to load the Chat Line List.");
			return new ArrayList();
		}
		catch (IllegalAccessException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  IllegalAccessException was thrown when trying to load the Chat Line List.");
			return new ArrayList();
		}
	}

	public static String GetChatString(Object chatLine)
	{
		// Search the mcGui file for "this.x" where x is the string literal
		// you just fixed above. In several places you will see it being
		// cast and you need to also cast it here to the same class.
		//
		// Then it is a trivial matter of opening said class and returning
		// the public String field.
		//
		// Fixed 17
		// MCP OLD FIX 21 - ensure that this points at the public accessor for
		// the correct String instance. There should only be one of these, so it
		// is easy. (In the ChatLine class).
		return ((net.minecraft.src.ChatLine) chatLine).getChatLineString();
	}
}
