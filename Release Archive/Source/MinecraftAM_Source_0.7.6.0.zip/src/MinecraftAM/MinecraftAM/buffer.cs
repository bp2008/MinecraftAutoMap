﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MinecraftAM
{
    public class tilebuffer
    {
        public MCTile[,] buffer;
        public IntVector2 topLeft;
    }
}
