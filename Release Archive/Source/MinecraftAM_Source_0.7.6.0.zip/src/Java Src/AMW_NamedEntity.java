public class AMW_NamedEntity extends AMW_Entity
{
	// Fixed 16
	public static final Class<acl> wrappedClass = acl.class;
	// Fixed 16
	public acl inst;

	// Fixed 16
	public AMW_NamedEntity(acl param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		String name = super.getName();
		if (name == "unknown_entity")
			name = null;
		if (name == null || name.equals(""))
			// Find with "damage.hurtflesh"
			//
			// Fixed 16
			name = inst.m(); // fully qualified name? Or perhaps sound file ID
		if (name == null || name.equals(""))
			// Fixed 16
			name = inst.bm; // entity texture? (String literal at the top of the
							// file)
		if (name == null || name.equals(""))
			name = "unknown_namedentity";
		return name;
	}
}
