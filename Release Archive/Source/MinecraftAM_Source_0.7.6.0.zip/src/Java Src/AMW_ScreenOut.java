import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;

public class AMW_ScreenOut
{
	private static Minecraft mc;
	private static Object mcGui;

	public static void Initialize(Minecraft parammc)
	{
		mc = parammc;
		// This is the same as the object used below in DisplayMessage
		// Fixed 16
		mcGui = mc.w;
	}

	public static void DisplayMessage(String message)
	{
		// Scroll to bottom to find this function
		// Fixed 16
		mc.w.a("�E" + message);
	}

	@SuppressWarnings("rawtypes")
	public static List GetChatLineList()
	{
		try
		{
			// Just fix the one string literal here, which is the List object at
			// the top of mcGui
			// Fixed 16
			Field privateFieldChatLineList = mcGui.getClass().getDeclaredField(
					"e");
			privateFieldChatLineList.setAccessible(true);
			Object cLL = privateFieldChatLineList.get(mcGui);
			if (!(cLL instanceof List))
			{
				AutomapServer
						.LogL1("GetChatLineList() failed.  The Chat Line List field is not an instance of List.");
				return new ArrayList();
			}
			return (List) cLL;
		} catch (SecurityException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  SecurityException was thrown when trying to get the Chat Line List.");
			return new ArrayList();
		} catch (NoSuchFieldException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  The World Data Loader field did not exist inside the Chat Line List.");
			return new ArrayList();
		} catch (IllegalArgumentException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  IllegalArgumentException was thrown when trying to load the Chat Line List.");
			return new ArrayList();
		} catch (IllegalAccessException e)
		{
			AutomapServer
					.LogL1("GetChatLineList() failed.  IllegalAccessException was thrown when trying to load the Chat Line List.");
			return new ArrayList();
		}
	}
	public static String GetChatString(Object chatLine)
	{
		// Search the mcGui file for "this.x" where x is the string literal 
		// you just fixed above.  In several places you will see it being 
		// cast and you need to also cast it here to the same class.
		//
		// Then it is a trivial matter of opening said class and returning 
		// the public String field.
		//
		// Fixed 16
		return ((nq)chatLine).a;
	}
}
