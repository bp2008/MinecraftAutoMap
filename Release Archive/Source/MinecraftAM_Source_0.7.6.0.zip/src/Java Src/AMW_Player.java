public class AMW_Player extends AMW_NamedEntity
{
	// Find with "http://s3.amazonaws.com/MinecraftCloaks/"
	// Fixed 16
	public static final Class<yr> wrappedClass = yr.class;
	// Fixed 16
	public yr inst;

	// Fixed 16
	public AMW_Player(yr param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		// first String, not far at all down the page, should be 2 strings
		// total, close together
		// Fixed 16
		return inst.aA;
	}
}
