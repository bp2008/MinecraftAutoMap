import java.net.Socket;

import net.minecraft.client.Minecraft;

public class AMW_Minecraft
{
	Minecraft inst;

	public AMW_Minecraft(Minecraft mc)
	{
		inst = mc;
	}

	public AMW_World getWorld()
	{
		// Fixed 16
		return new AMW_World(inst.f);
	}

	public AMW_Player getPlayer()
	{
		// Fixed 16
		return new AMW_Player(inst.h);
	}

	public String getSMPHost()
	{
		// The following does NOT work:
		//
		// The server name and port is a string and an int, declared a dozen
		// lines or so after
		// MinecraftApplet. They are both set in a simple function about 50
		// lines down. The aforementioned function should have been called near
		// the string constant: "Post startup".
		//
		// The following DOES work:
		//
		// Get the Socket used for communication and pull the data out of it.
		//
		//
		// Near Bottom -- Just above main function
		// Fixed 16
		Object playerNetClient = inst.q();
		if (playerNetClient == null)
			return "unknown";
		//
		// Fixed 16
		Object networkManager = Utilities.GetPrivateField(playerNetClient, "g");
		if (networkManager == null)
			return "unknown";
		//
		// Fixed 16
		Object oSocket = Utilities.GetPrivateField(networkManager, "h");
		if (oSocket == null || !(oSocket instanceof Socket))
			return "unknown";
		Socket sock = (Socket) oSocket;
		String serverName = sock.getInetAddress().getHostName();
		int serverPort = sock.getPort();
		return serverName + ":" + serverPort;
	}

	public boolean checkWorldChanged(Object inst2)
	{
		// Same object as in getWorld above
		// Fixed 16
		return inst2 != inst.f;
	}
}
