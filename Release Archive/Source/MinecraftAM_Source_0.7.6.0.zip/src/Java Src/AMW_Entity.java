public class AMW_Entity
{
	// Fixed 16
	public static final Class<nk> wrappedClass = nk.class;
	// Fixed 16
	public nk inst;
	// Fixed 16
	public AMW_Entity(nk param)
	{
		inst = param;
	}
	
	public String getName()
	{
		// Find the class by searching for "Creeper"
		// Fixed 16
		String name = aaj.b(inst);
		if (name == null || name.equals(""))
			name = "unknown_entity";
		return name;
	}
	
	public double getX()
	{
		// These 3 are down below in the SetPosition Function in decompiled source. 
		//    -- Not far down the page
		// Third double.
		// Fixed 16
		return inst.q;
	}

	public double getY()
	{
		// First double.
		// Fixed 16
		return inst.o;
	}

	public double getZ()
	{
		// Second double.
		// Fixed 16
		return inst.p;
	}
	
	public void setPosition(double x, double y, double z)
	{
		// This function is called in the first Entity constructor.
		// This is also the function mentioned above in getX()'s comments.
		//
		// Fixed 16
		inst.d(y,z,x);
		/* It looks kind of like this:
	public void d(double paramDouble1, double paramDouble2, double paramDouble3) {
    	this.aM = paramDouble1;
    	this.aN = paramDouble2;
    	this.aO = paramDouble3;
    	float f1 = this.bg / 2.0F;
    	float f2 = this.bh;
    	this.aW.c(paramDouble1 - f1, paramDouble2 - this.bf + this.bo, paramDouble3 - f1, paramDouble1 + f1, paramDouble2 - this.bf + this.bo + f2, paramDouble3 + f1);
  	}
		 */
	}

	public float getRotation(boolean useAlternateRotationValue)
	{
		// Fixed 16
		return useAlternateRotationValue ? inst.w : inst.u;
	}

	public float getPitch(boolean useAlternateRotationValue)
	{
		// Fixed 16
		return useAlternateRotationValue ? inst.x : inst.v;
	}
}
