
public class AMW_ItemList
{
	// Find class with "shovelIron"
	public static int getImageIndex(int itemID)
	{
		// first int after the items are declared. this one is declared final
		// Fixed 16
		return ym.e[itemID].bQ;
	}
	public static String getName(int itemID)
	{
		// Near the bottom (sort of)
		// Fixed 16
		return ym.e[itemID].e();
	}
}
