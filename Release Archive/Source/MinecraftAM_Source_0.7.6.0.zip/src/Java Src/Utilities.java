import java.lang.reflect.Field;

public class Utilities
{
	public static String GetPrivateStringField(Object parent, String fieldName)
	{
		try
		{
			Object obj = GetPrivateField(parent, fieldName);
			return (String) obj;
		} catch (Exception e)
		{
			String functionName = "GetPrivateStringField(" + parent + ", \""
					+ fieldName + "\") (" + parent.getClass().toString() + ")";
			AutomapServer.LogL1(functionName
					+ " failed.  obj is not the expected type.");
		}
		return "";
	}

	public static int GetPrivateIntField(Object parent, String fieldName)
	{
		try
		{
			Object obj = GetPrivateField(parent, fieldName);
			return ((Integer) obj).intValue();
		} catch (Exception e)
		{
			String functionName = "GetPrivateStringField(" + parent + ", \""
					+ fieldName + "\") (" + parent.getClass().toString() + ")";
			AutomapServer.LogL1(functionName
					+ " failed.  obj is not the expected type.");
		}
		return 0;
	}

	public static Object GetPrivateField(Object parent, String fieldName)
	{
		String functionName = "GetPrivateField(" + parent + ", \"" + fieldName
				+ "\") (" + parent.getClass().toString() + ")";
		try
		{
			Field privateField = parent.getClass().getDeclaredField(fieldName);
			privateField.setAccessible(true);
			Object obj = privateField.get(parent);
			return obj;
		} catch (SecurityException e)
		{
			AutomapServer
					.LogL1(functionName
							+ " failed.  SecurityException was thrown when trying to the the field.");
		} catch (NoSuchFieldException e)
		{
			AutomapServer.LogL1(functionName
					+ " failed.  The field did not exist inside the object.");
		} catch (IllegalArgumentException e)
		{
			AutomapServer
					.LogL1(functionName
							+ " failed.  IllegalArgumentException was thrown when trying to load the field.");
		} catch (IllegalAccessException e)
		{
			AutomapServer
					.LogL1(functionName
							+ " failed.  IllegalAccessException was thrown when trying to load the field.");
		} catch (Exception e)
		{
			AutomapServer
					.LogL1(functionName
							+ " failed.  Exception was thrown when trying to load the field. "
							+ e.getMessage());
		}
		return null;
	}
}
