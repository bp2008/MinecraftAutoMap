import java.util.List;

public class AMW_World
{
	// Fixed 16
	wz inst;

	// Fixed 16
	public AMW_World(wz world)
	{
		inst = world;
	}

	public AMW_WorldInfo getWorldInfo()
	{
		// the function below -- world.w() -- gets a dy which contains the text "RandomSeed", "SpawnX",
		// "LastPlayed", "SizeOnDisk"
		//
		// Pretty close to the bottom
		//
		// Fixed 16
		return new AMW_WorldInfo(inst.B());
	}

	public AMW_WorldDataLoader getWorldDataLoader()
	{
		// This parameter previously required Java Reflection, but now I found a public accessor function!
		// Fix WorldDataLoader first so you know the class name to replace here.  Be sure to fix the accessor function name, too!
		//
		// Fixed 16		
		return new AMW_WorldDataLoader((ed)inst.A());
		
		/*
		// ek is a WorldDataLoader which comes from world.p (a protected
		// variable accessed via reflection)
		//
		// Fix WorldDataLoader first so you know the class name to replace here.
		// Fixed 16
		
		ed worldDataLoader = null;
		try
		{
			return new AMW_WorldDataLoader((ed)inst.A());
			// Fixed 14
			Field privateFieldWorldDataLoader = inst.getClass()
					.getDeclaredField("B");
			privateFieldWorldDataLoader.setAccessible(true);
			Object wDL = privateFieldWorldDataLoader.get(inst);
			// The class name is the same as worldDataLoader above
			// Fixed 16
			if (!(wDL instanceof ed))
			{
				AutomapServer
						.LogL1("getWorldInfo() failed.  The World Data Loader field is not an instance of the correct class.");
				return null;
			}
			// The class name is the same as worldDataLoader above
			// Fixed 16
			worldDataLoader = (ed) wDL;
		} catch (SecurityException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  SecurityException was thrown when trying to the the World Data Loader.");
			return null;
		} catch (NoSuchFieldException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  The World Data Loader field did not exist inside the World object.");
			return null;
		} catch (IllegalArgumentException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  IllegalArgumentException was thrown when trying to load the World Data Loader.");
			return null;
		} catch (IllegalAccessException e)
		{
			AutomapServer
					.LogL1("getWorldInfo() failed.  IllegalAccessException was thrown when trying to load the World Data Loader.");
			return null;
		}
		return new AMW_WorldDataLoader(worldDataLoader); // new
															// AMW_WorldDataLoader((ek)
															// inst.p);
		*/
	}

	// World has a public final variable shortly after the Random which is
	// sent to a function in another class that contains the text "DIM-1".
	// This lets us detect whether or not the dimension is Nether because
	// the one in the world info object only tells us what the dimension was
	// when the world loaded from the menu.
	//
	// UPDATE:  This public final variable contains an integer which is the dimension number.
	public String getDimension()
	{
		// Previously:  uw is something that world.o can be. extends vr
		// Now: inst has a field which has an int field which contains the dimension number
		//
		// Fixed 16
		return String.valueOf(inst.t.g);
	}

	public byte getBlockId(int x, int y, int z)
	{
		// Find with:
		// if ((paramInt1 < -30000000) || (paramInt3 < -30000000) || (paramInt1 >= 30000000) |
		// Fixed 16
		return (byte) inst.a(x, z, y);
	}

	public byte getBlockMeta(int x, int y, int z)
	{
		// Find with:
		// if ((paramInt1 < -30000000) || (paramInt3 < -30000000) || (paramInt1 >= 30000000) |
		// this one has &= 15 in it twice
		// Fixed 16
		return (byte) inst.e(x, z, y);
	}

	public byte getBlockLight(int x, int y, int z)
	{
		// Find the function below it with:
		// if ((paramInt1 < -30000000) || (paramInt3 < -30000000) || (paramInt1 >= 30000000) |
		// The function we are looking for is the one ABOVE that calls
		// the one below it, passing in true for the 4th argument
		// Fixed 16
		return (byte) inst.o(x, z, y);
	}

	/**
	 * The NPC list also has players in it.
	 */
	public List<?> GetPlayerList()
	{
		// Second to last public list? (Players).  NPC list also has players in it.
		//
		// Fixed 16
		return inst.d;
	}

	/**
	 * Also contains players.
	 */
	public List<?> GetNPCList()
	{
		// First public list
		//
		// Fixed 16
		return inst.b;
	}
	public void CreateExplosion(double x, double y, double z, float power)
	{
		// This function can be found with the regex:
		//  \w+\([^ ]+ [^,]+, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat\)
		//
		// it is 2 functions, one is an overload which passes in false. they 
		// both return an object.  We want the one without a boolean param, obviously.
		//
		// Fixed 16
		inst.a(null, x, y, z, power);
	}
}

// THE COMMENT BELOW IS OUTDATED - IT REMAINS HERE AS A GUIDE FOR WHAT
// NOT TO DO
// This function used to be able to just return getWorld().t;
// But the world class no longer has a simple File pointer.
// The method I have devised for getting a File reference to the world's
// folder is this:
// 1. Get access to the "saves" directory via Minecraft's static method
// that returns a File reference to the .minecraft directory.
// 2. Minecraft has a public accessor that returns a MCRegion Loader
// (called worldInspector here) class instance. This can create for us a
// List of objects that map world names and world save folder names
// together.
// 3. Get the list that matches world names and save folder names.
// (this is called worldInfo here)
// 4. Get the name of the current world from the current world object.
// 5. Compare the name of the current world with the names in worldInfo.
// 6. If there is a match, return a File reference using the matched
// path. If there is no match, return reference to saves folder and
// report the error.
// /////
// This method now returns a String containing the full path, a pipe,
// the dimension number, another pipe, and the world name.
// /////////
// world.w() is a public accessor for world.q, which has world info.