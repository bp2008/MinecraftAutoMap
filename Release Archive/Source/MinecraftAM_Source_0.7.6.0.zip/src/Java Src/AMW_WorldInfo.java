public class AMW_WorldInfo
{
	// Find this class with "SizeOnDisk"
	// Fixed 16
	wm inst;
	// Fixed 16
	public AMW_WorldInfo(wm param)
	{
		inst = param;
	}
	public String getName()
	{
		// Fixed 16
		return inst.j();
	}
	// This is likely inaccurate.
	public int getSpawnX()
	{
		// Fixed 16
		return inst.e() * -1;
	}
	// This is likely inaccurate.
	public int getSpawnY()
	{
		// Fixed 16
		return inst.c();
	}
	// This is likely inaccurate.
	public int getSpawnZ()
	{
		// Fixed 16
		return inst.d();
	}
}
