public class AMW_Player extends AMW_NamedEntity
{
	// Find with "http://s3.amazonaws.com/MinecraftCloaks/"
	// Fixed 17
	public static final Class<net.minecraft.src.EntityPlayer> wrappedClass = net.minecraft.src.EntityPlayer.class;
	// Fixed 17
	public net.minecraft.src.EntityPlayer inst;

	// Fixed 17
	public AMW_Player(net.minecraft.src.EntityPlayer param)
	{
		super(param);
		inst = param;
	}

	@Override
	public String getName()
	{
		// first String, not far at all down the page, should be 2 strings
		// total, close together
		// Fixed 17
		return inst.username;
	}
}
