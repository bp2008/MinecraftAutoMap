//import net.minecraft.client.Minecraft;
//
////import java.lang.reflect.Field;
//
//public class AutomapLoader
//{
//	private static Minecraft instance = null;
//
//	//private static Object loadLock = new Object();
//	private static boolean isLoaded = false;
//
//	public static void LoadAM(Minecraft mc)
//	{
//		if (instance == null)
//		{
//			instance = mc;
//			// instance = getMinecraftInstance();
//		}
//		if (instance.e != null && !isLoaded)
//			// synchronized (loadLock)
//			// {
//			if (!isLoaded)
//			{
//				isLoaded = true;
//				mod_automap.alternateStart = true;
//				new mod_automap().OnTickInGame(instance);
//			}
//		// }
//	}
//
//	// private static Minecraft getMinecraftInstance()
//	// {
//	// if (instance == null)
//	// {
//	// try
//	// {
//	// ThreadGroup group = Thread.currentThread().getThreadGroup();
//	// int count = group.activeCount();
//	// Thread[] threads = new Thread[count];
//	// group.enumerate(threads);
//	// for (int i = 0; i < threads.length; i++)
//	// if (threads[i].getName().equals("Minecraft main thread"))
//	// {
//	// instance = (Minecraft) getPrivateValue(Thread.class,
//	// threads[i], "target");
//	// break;
//	// }
//	// } catch (SecurityException e)
//	// {
//	// throw new RuntimeException(e);
//	// } catch (NoSuchFieldException e)
//	// {
//	// throw new RuntimeException(e);
//	// }
//	// }
//	// return instance;
//	// }
//	//
//	// @SuppressWarnings("unchecked")
//	// private static <T, E> T getPrivateValue(Class<? super E> instanceclass,
//	// E instance, String field) throws IllegalArgumentException,
//	// SecurityException, NoSuchFieldException
//	// {
//	// try
//	// {
//	// Field f = instanceclass.getDeclaredField(field);
//	// f.setAccessible(true);
//	// return (T) f.get(instance);
//	// } catch (IllegalAccessException e)
//	// {
//	// // An impossible error has occurred!
//	// }
//	// return null;
//	// }
//}
